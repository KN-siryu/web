<?php

namespace App\Providers;

use App\Models\Setting;
use Illuminate\Support\Facades\View as ViewFacade;
use Illuminate\Support\ServiceProvider;
use Illuminate\View\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        ViewFacade::composer([
            'layouts.*',
            'auth.login',
            'home',
            'profile.*',
            'berita.*',
            'kontak.index',
            'ppdb.*',
            'galeri.index',
            'staf.index',
            'ekskul.index',
        ], function (View $view): void {
            $request = request();

            if (! $request->attributes->has('siteSettings')) {
                $request->attributes->set('siteSettings', Setting::pluck('value', 'key')->all());
            }

            $view->with('siteSettings', $request->attributes->get('siteSettings'));
        });
    }
}
