<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, string $role): Response
    {
        if (! auth()->check() || ! in_array(auth()->user()->role, explode(',', $role))) {
            abort(403, 'Akses Ditolak. Anda tidak memiliki izin yang sesuai.');
        }

        return $next($request);
    }
}
