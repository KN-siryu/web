<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class CheckModulePermission
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next, ?string $module = null): Response
    {
        $user = auth()->user();

        Log::info('CheckModulePermission: User', ['user_id' => $user?->id, 'role' => $user?->role]);

        if (! $user || $user->role !== 'guru') {
            Log::info('CheckModulePermission: Not guru, passing through');

            return $next($request);
        }

        $module = $module ?? $this->getModuleFromRoute($request);

        Log::info('CheckModulePermission: Module detected', ['module' => $module, 'route' => $request->route()->getName()]);

        if (! $module) {
            Log::info('CheckModulePermission: No module, passing through');

            return $next($request);
        }

        $activeRequests = $user->activePermissionRequests()
            ->where('module', $module)
            ->values();

        if ($activeRequests->isEmpty()) {
            $anyApproved = $user->permissionRequests()
                ->where('module', $module)
                ->where('status', 'approved')
                ->exists();

            Log::info('CheckModulePermission: Module denied', ['user_id' => $user->id, 'module' => $module, 'anyApproved' => $anyApproved]);

            if ($anyApproved) {
                abort(403, 'Izin akses untuk modul ini sudah kedaluwarsa atau belum aktif. Silakan ajukan perpanjangan izin.');
            }

            abort(403, 'Anda tidak memiliki izin akses untuk modul ini. Silakan ajukan izin akses terlebih dahulu.');
        }

        $action = User::actionForRoute($request->route()?->getName());

        if ($action) {
            $allowed = $activeRequests->contains(
                fn ($permission) => in_array($action, $user->approvedActionsFor($permission), true)
            );

            if (! $allowed) {
                Log::info('CheckModulePermission: Action denied', ['user_id' => $user->id, 'module' => $module, 'action' => $action]);

                abort(403, 'Anda tidak memiliki izin untuk aksi ini pada modul tersebut. Silakan ajukan izin akses dengan tipe yang sesuai.');
            }
        }

        return $next($request);
    }

    private function getModuleFromRoute(Request $request): ?string
    {
        $routeName = $request->route()->getName();

        $moduleMap = [
            'guru.berita' => 'berita',
            'guru.galeri' => 'galeri',
            'guru.ekskul' => 'ekskul',
            'guru.staf' => 'staf',
            'guru.fasilitas' => 'fasilitas',
            'guru.pendaftar' => 'pendaftar',
            'guru.pesan' => 'pesan',
        ];

        foreach ($moduleMap as $routePrefix => $module) {
            if (str_starts_with($routeName, $routePrefix)) {
                return $module;
            }
        }

        return null;
    }
}
