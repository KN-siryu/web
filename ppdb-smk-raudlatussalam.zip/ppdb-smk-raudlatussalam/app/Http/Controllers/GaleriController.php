<?php

namespace App\Http\Controllers;

use App\Models\Galeri;
use Illuminate\Http\Request;

class GaleriController extends Controller
{
    public function index(Request $request)
    {
        $kategori = $request->input('kategori');

        $galeris = Galeri::when($kategori, function ($query) use ($kategori) {
            $query->where('kategori', $kategori);
        })->latest()->paginate(12);

        // Ambil semua kategori unik untuk filter
        $kategoris = Galeri::select('kategori')->distinct()->pluck('kategori');

        return view('galeri.index', compact('galeris', 'kategori', 'kategoris'));
    }
}
