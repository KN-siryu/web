<?php

namespace App\Http\Controllers;

use App\Models\PermissionRequest;
use App\Models\User;
use App\Notifications\NewPermissionRequest;
use App\Notifications\PermissionRequestStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PermissionRequestController extends Controller
{
    public function create()
    {
        $modules = [
            'berita' => 'Berita & Artikel',
            'galeri' => 'Galeri Foto',
            'ekskul' => 'Ekstrakurikuler',
            'staf' => 'Staf Pengajar',
            'fasilitas' => 'Fasilitas',
            'pendaftar' => 'Pendaftar PPDB',
        ];

        $actionTypes = [
            'create' => 'Tambah Data',
            'edit' => 'Edit Data',
            'delete' => 'Hapus Data',
            'all' => 'Semua (Tambah, Edit, Hapus)',
        ];

        $existingRequests = PermissionRequest::where('user_id', Auth::id())
            ->where('status', 'pending')
            ->get();

        $selectedModule = in_array(request('module'), array_keys($modules), true)
            ? request('module')
            : array_key_first($modules);

        return view('guru.izin-akses.create', compact('modules', 'actionTypes', 'existingRequests', 'selectedModule'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'module' => 'required|in:berita,galeri,ekskul,staf,fasilitas,pendaftar',
            'action_type' => 'required|in:create,edit,delete,all',
            'start_at' => 'required|date',
            'end_at' => 'required|date|after:start_at',
            'reason' => 'required|string|min:10|max:500',
        ]);

        $existing = PermissionRequest::where('user_id', Auth::id())
            ->where('module', $request->module)
            ->where('status', 'pending')
            ->first();

        if ($existing) {
            return back()->withErrors(['module' => 'Anda sudah memiliki permintaan izin untuk modul ini yang masih menunggu persetujuan.']);
        }

        $permissionRequest = PermissionRequest::create([
            'user_id' => Auth::id(),
            'module' => $request->module,
            'action_type' => $request->action_type,
            'start_at' => $request->start_at,
            'end_at' => $request->end_at,
            'reason' => $request->reason,
            'status' => 'pending',
        ]);

        // Notify all admins
        User::where('role', 'admin')->get()->each(function ($admin) use ($permissionRequest) {
            $admin->notify(new NewPermissionRequest($permissionRequest));
        });

        return redirect()->route('guru.izin-akses.show', $permissionRequest)
            ->with('success', 'Permintaan izin akses telah dikirim dan menunggu persetujuan admin.');
    }

    public function show(PermissionRequest $permissionRequest)
    {
        if (Auth::id() !== $permissionRequest->user_id && Auth::user()->role !== 'admin') {
            abort(403);
        }

        return view('guru.izin-akses.show', compact('permissionRequest'));
    }

    public function adminIndex()
    {
        $requests = PermissionRequest::with('user', 'approver')
            ->latest()
            ->paginate(10);

        return view('admin.izin-akses.index', compact('requests'));
    }

    public function adminApprove(PermissionRequest $permissionRequest, Request $request)
    {
        if (Auth::user()->role !== 'admin') {
            abort(403);
        }

        $validated = $request->validate([
            'start_at' => 'nullable|date',
            'end_at' => 'nullable|date|after_or_equal:start_at',
            'admin_note' => 'nullable|string|max:1000',
        ]);

        $permissionRequest->update([
            'status' => 'approved',
            'approved_by' => Auth::id(),
            'start_at' => $validated['start_at'] ?? $permissionRequest->start_at,
            'end_at' => $validated['end_at'] ?? $permissionRequest->end_at,
            'admin_note' => $request->input('admin_note'),
        ]);

        $permissionRequest->user->notify(new PermissionRequestStatus($permissionRequest, 'approved'));

        return redirect()->route('admin.izin-akses.index')
            ->with('success', 'Permintaan izin akses telah disetujui.');
    }

    public function adminReject(PermissionRequest $permissionRequest)
    {
        if (Auth::user()->role !== 'admin') {
            abort(403);
        }

        $permissionRequest->update([
            'status' => 'rejected',
            'approved_by' => Auth::id(),
            'admin_note' => request('admin_note'),
        ]);

        $permissionRequest->user->notify(new PermissionRequestStatus($permissionRequest, 'rejected'));

        return redirect()->route('admin.izin-akses.index')
            ->with('success', 'Permintaan izin akses telah ditolak.');
    }

    public function adminRevoke(PermissionRequest $permissionRequest)
    {
        if (Auth::user()->role !== 'admin') {
            abort(403);
        }

        $permissionRequest->update([
            'status' => 'revoked',
            'approved_by' => Auth::id(),
            'admin_note' => request('admin_note') ?: 'Izin dihentikan oleh admin.',
        ]);

        $permissionRequest->user->notify(new PermissionRequestStatus($permissionRequest, 'revoked'));

        return redirect()->route('admin.izin-akses.index')
            ->with('success', 'Izin akses guru berhasil dihentikan.');
    }
}
