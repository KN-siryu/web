<?php

namespace App\Http\Controllers;

use App\Models\Ekskul;

class EkskulController extends Controller
{
    public function index()
    {
        $ekskuls = Ekskul::orderBy('nama', 'asc')->get();

        return view('ekskul.index', compact('ekskuls'));
    }
}
