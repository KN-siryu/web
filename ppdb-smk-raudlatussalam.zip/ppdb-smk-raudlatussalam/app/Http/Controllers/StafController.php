<?php

namespace App\Http\Controllers;

use App\Models\Staf;
use Illuminate\Http\Request;

class StafController extends Controller
{
    public function index(Request $request)
    {
        $kategori = $request->input('kategori', 'all');

        $stafs = Staf::query()
            ->when($kategori !== 'all', function ($query) use ($kategori) {
                $query->where(function ($subQuery) use ($kategori) {
                    $subQuery->where('kategori', $kategori)
                        ->orWhere('jabatan', $kategori);
                });
            })
            ->orderByRaw("CASE WHEN kategori = 'Kepala Sekolah' THEN 0 WHEN kategori = 'Pengajar' THEN 1 WHEN kategori = 'Tenaga Kependidikan' THEN 2 ELSE 3 END")
            ->orderBy('nama', 'asc')
            ->get();

        return view('staf.index', compact('stafs', 'kategori'));
    }
}
