<?php

namespace App\Http\Controllers;

use App\Models\Pendaftar;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PpdbController extends Controller
{
    public function index()
    {
        return view('ppdb.index');
    }

    public function store(Request $request)
    {
        // Validasi data utama
        $validated = $request->validate([
            'jenis_pendaftaran' => 'required|in:Baru,Pindahan',
            'jalur_pendaftaran' => 'required|in:Umum,Prestasi',
            'nama_lengkap' => 'required|string|max:255',
            'nisn' => 'nullable|string|max:20',
            'nik' => 'nullable|string|max:20',
            'jenis_kelamin' => 'required|in:L,P',
            'tempat_lahir' => 'nullable|string|max:100',
            'tanggal_lahir' => 'nullable|date',
            'agama' => 'nullable|string|max:50',
            'alamat' => 'nullable|string|max:500',
            'asal_sekolah' => 'nullable|string|max:255',
            'nama_ayah' => 'nullable|string|max:255',
            'pekerjaan_ayah' => 'nullable|string|max:255',
            'telepon_ayah' => 'nullable|string|max:20',
            'nama_ibu' => 'nullable|string|max:255',
            'pekerjaan_ibu' => 'nullable|string|max:255',
            'telepon_ibu' => 'nullable|string|max:20',
            'nama_wali' => 'required|string|max:255',
            'telepon_wali' => 'required|string|max:20',
            'email_wali' => 'required|email|max:255',
            'alamat_wali' => 'required|string|max:500',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'kk' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'akta' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'ijazah' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $kodePendaftaran = 'PPDB-'.now()->year.'-'.Str::upper(Str::random(8));

        // Upload Dokumen
        $dokumen = ['foto', 'kk', 'akta', 'ijazah'];
        $pathData = [];
        foreach ($dokumen as $doc) {
            if ($request->hasFile($doc)) {
                $pathData['path_'.$doc] = $request->file($doc)->store('ppdb/'.$doc, 'public');
            }
        }

        // Simpan ke database
        $pendaftar = Pendaftar::create(array_merge($validated, [
            'kode_pendaftaran' => $kodePendaftaran,
        ], $pathData));

        // Redirect ke halaman sukses dengan kode pendaftaran
        return redirect()->route('ppdb.success', $pendaftar->kode_pendaftaran);
    }

    public function success($kode)
    {
        $pendaftar = Pendaftar::where('kode_pendaftaran', $kode)->firstOrFail();

        return view('ppdb.success', compact('pendaftar'));
    }

    public function cetak($kode)
    {
        $pendaftar = Pendaftar::where('kode_pendaftaran', $kode)->firstOrFail();

        return view('ppdb.cetak', compact('pendaftar'));
    }
}
