<?php

namespace App\Http\Controllers;

abstract class Controller
{
    /**
     * Prefix for the current user's content-management routes.
     */
    protected function indexRoute(string $module): string
    {
        return (auth()->user()?->role === 'guru' ? 'guru.' : 'admin.').$module.'.index';
    }
}
