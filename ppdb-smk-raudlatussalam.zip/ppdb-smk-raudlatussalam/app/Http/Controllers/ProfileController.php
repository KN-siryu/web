<?php

namespace App\Http\Controllers;

use App\Models\Fasilitas;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function profil(): View
    {
        return view('profile.profil-sekolah');
    }

    public function visiMisi(): View
    {
        return view('profile.visi-misi');
    }

    public function sejarah(): View
    {
        return view('profile.sejarah');
    }

    public function fasilitas(): View
    {
        $fasilitas = Fasilitas::orderBy('urutan')->orderBy('nama')->get();

        return view('profile.fasilitas', compact('fasilitas'));
    }
}
