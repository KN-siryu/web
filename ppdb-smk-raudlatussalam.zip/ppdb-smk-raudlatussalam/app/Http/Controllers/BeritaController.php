<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use Illuminate\Http\Request;

class BeritaController extends Controller
{
    public function index(Request $request)
    {
        $kategori = $request->input('kategori');

        $beritas = Berita::when($kategori, function ($query) use ($kategori) {
            $query->where('kategori', $kategori);
        })->latest()->paginate(6);

        return view('berita.index', compact('beritas', 'kategori'));
    }

    public function show(Berita $beritum)
    {
        $berita = $beritum;
        $beritaTerbaru = Berita::where('id', '!=', $berita->id)->latest()->take(5)->get();

        return view('berita.show', compact('berita', 'beritaTerbaru'));
    }
}
