<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use App\Models\Ekskul;
use App\Models\Galeri;
use App\Models\Pendaftar;
use App\Models\Staf;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function index(): View
    {
        $beritas = Berita::latest()->take(3)->get();
        $kepalaSekolah = Staf::where('kategori', 'Kepala Sekolah')->first();
        $stafs = Staf::where('kategori', 'Pengajar')->orderBy('nama')->take(8)->get();
        $ekskuls = Ekskul::orderBy('nama')->take(6)->get();
        $galeris = Galeri::latest()->take(4)->get();
        $heroPhoto = $galeris->first();

        $statistics = [
            ['count' => Staf::count(), 'label' => 'Guru & Staf'],
            ['count' => Pendaftar::count(), 'label' => 'Pendaftar PPDB'],
            ['count' => Galeri::count(), 'label' => 'Foto Kegiatan'],
            ['count' => Ekskul::count(), 'label' => 'Ekstrakurikuler'],
        ];

        return view('home', compact(
            'beritas',
            'kepalaSekolah',
            'stafs',
            'ekskuls',
            'galeris',
            'heroPhoto',
            'statistics',
        ));
    }
}
