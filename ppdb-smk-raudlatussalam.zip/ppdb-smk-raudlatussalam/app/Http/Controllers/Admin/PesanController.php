<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pesan;
use Illuminate\Http\Request;

class PesanController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pesanBaru = Pesan::where('status', 'baru')->count();

        $pesans = Pesan::when($search, function ($query) use ($search) {
            $query->where('nama', 'like', "%$search%")
                ->orWhere('subjek', 'like', "%$search%")
                ->orWhere('email', 'like', "%$search%");
        })->latest()->paginate(10);

        return view('admin.pesan.index', compact('pesans', 'pesanBaru'));
    }

    public function show(Pesan $pesan)
    {
        // Tandai sebagai sudah dibaca saat dibuka
        if ($pesan->status == 'baru') {
            $pesan->update(['status' => 'dibaca']);
        }

        return view('admin.pesan.show', compact('pesan'));
    }

    public function destroy(Pesan $pesan)
    {
        $pesan->delete();

        return redirect()->route($this->indexRoute('pesan'))->with('success', 'Pesan berhasil dihapus.');
    }
}
