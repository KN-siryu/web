<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use RuntimeException;

class SettingController extends Controller
{
    public function index(): View
    {
        $settings = Setting::pluck('value', 'key')->toArray();

        return view('admin.pengaturan.index', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'nama_sekolah' => ['nullable', 'string', 'max:255'],
            'telepon' => ['nullable', 'string', 'max:50'],
            'email' => ['nullable', 'email', 'max:255'],
            'alamat' => ['nullable', 'string', 'max:1000'],
            'kepala_sekolah' => ['nullable', 'string', 'max:255'],
            'sambutan' => ['nullable', 'string', 'max:5000'],
            'visi' => ['nullable', 'string', 'max:5000'],
            'misi' => ['nullable', 'string', 'max:5000'],
            'sejarah' => ['nullable', 'string', 'max:10000'],
            'cta_judul' => ['nullable', 'string', 'max:255'],
            'cta_deskripsi' => ['nullable', 'string', 'max:1000'],
            'cta_teks_tombol' => ['nullable', 'string', 'max:100'],
            'cta_link' => ['nullable', 'string', 'max:1000'],
            'logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'favicon' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:1024'],
            'hero_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'foto_kepala_sekolah' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ]);

        unset($data['logo'], $data['favicon'], $data['hero_image'], $data['foto_kepala_sekolah']);

        foreach ($data as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }

        foreach (['logo', 'favicon', 'hero_image', 'foto_kepala_sekolah'] as $imageSetting) {
            if (! $request->hasFile($imageSetting)) {
                continue;
            }

            $newPath = $request->file($imageSetting)->storePublicly('site', 'public');

            if (! is_string($newPath)) {
                throw new RuntimeException("Gagal menyimpan {$imageSetting} website.");
            }

            $oldPath = Setting::get($imageSetting);

            Setting::updateOrCreate(
                ['key' => $imageSetting],
                ['value' => $newPath]
            );

            if ($oldPath && $oldPath !== $newPath && ! Storage::disk('public')->delete($oldPath)) {
                Log::warning('Gagal menghapus file pengaturan website yang lama.', [
                    'setting' => $imageSetting,
                    'path' => $oldPath,
                ]);
            }
        }

        return redirect()->route('admin.pengaturan.index')->with('success', 'Pengaturan berhasil disimpan.');
    }
}
