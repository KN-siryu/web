<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Staf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class StafController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $stafs = Staf::when($search, function ($query) use ($search) {
            $query->where('nama', 'like', "%$search%")
                ->orWhere('jabatan', 'like', "%$search%");
        })->latest()->paginate(10);

        return view('admin.staf.index', compact('stafs'));
    }

    public function create()
    {
        return view('admin.staf.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'nip' => 'nullable|string|max:255',
            'jabatan' => 'required|string|max:255',
            'mata_pelajaran' => 'nullable|string|max:255',
            'pendidikan' => 'nullable|string|max:255',
            'kategori' => 'required|in:Kepala Sekolah,Pengajar,Tenaga Kependidikan',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $fotoPath = null;
        if ($request->hasFile('foto')) {
            $fotoPath = $request->file('foto')->store('staf', 'public');
        }

        Staf::create([
            'nama' => $request->nama,
            'nip' => $request->nip,
            'jabatan' => $request->jabatan,
            'mata_pelajaran' => $request->mata_pelajaran,
            'pendidikan' => $request->pendidikan,
            'kategori' => $request->kategori,
            'foto' => $fotoPath,
        ]);

        return redirect()->route($this->indexRoute('staf'))->with('success', 'Data staf berhasil ditambahkan.');
    }

    public function edit(Staf $staf)
    {
        return view('admin.staf.edit', compact('staf'));
    }

    public function update(Request $request, Staf $staf)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'nip' => 'nullable|string|max:255',
            'jabatan' => 'required|string|max:255',
            'mata_pelajaran' => 'nullable|string|max:255',
            'pendidikan' => 'nullable|string|max:255',
            'kategori' => 'required|in:Kepala Sekolah,Pengajar,Tenaga Kependidikan',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $fotoPath = $staf->foto;
        if ($request->hasFile('foto')) {
            if ($staf->foto) {
                Storage::disk('public')->delete($staf->foto);
            }
            $fotoPath = $request->file('foto')->store('staf', 'public');
        }

        $staf->update([
            'nama' => $request->nama,
            'nip' => $request->nip,
            'jabatan' => $request->jabatan,
            'mata_pelajaran' => $request->mata_pelajaran,
            'pendidikan' => $request->pendidikan,
            'kategori' => $request->kategori,
            'foto' => $fotoPath,
        ]);

        return redirect()->route($this->indexRoute('staf'))->with('success', 'Data staf berhasil diperbarui.');
    }

    public function destroy(Staf $staf)
    {
        if ($staf->foto) {
            Storage::disk('public')->delete($staf->foto);
        }
        $staf->delete();

        return redirect()->route($this->indexRoute('staf'))->with('success', 'Data staf berhasil dihapus.');
    }
}
