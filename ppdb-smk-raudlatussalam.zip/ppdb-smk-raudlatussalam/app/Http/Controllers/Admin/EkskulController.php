<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ekskul;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class EkskulController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $ekskuls = Ekskul::when($search, function ($query) use ($search) {
            $query->where('nama', 'like', "%$search%");
        })->latest()->paginate(10);

        return view('admin.ekskul.index', compact('ekskuls'));
    }

    public function create()
    {
        return view('admin.ekskul.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'deskripsi' => 'nullable|string',
            'pembina' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'warna' => 'required|string|max:255',
        ]);

        Ekskul::create([
            'nama' => $request->nama,
            'slug' => Str::slug($request->nama),
            'deskripsi' => $request->deskripsi,
            'pembina' => $request->pembina,
            'icon' => $request->icon ?? '🏆',
            'warna' => $request->warna,
        ]);

        return redirect()->route($this->indexRoute('ekskul'))->with('success', 'Data ekskul berhasil ditambahkan.');
    }

    public function edit(Ekskul $ekskul)
    {
        return view('admin.ekskul.edit', compact('ekskul'));
    }

    public function update(Request $request, Ekskul $ekskul)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'deskripsi' => 'nullable|string',
            'pembina' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'warna' => 'required|string|max:255',
        ]);

        $ekskul->update([
            'nama' => $request->nama,
            'slug' => Str::slug($request->nama),
            'deskripsi' => $request->deskripsi,
            'pembina' => $request->pembina,
            'icon' => $request->icon ?? '🏆',
            'warna' => $request->warna,
        ]);

        return redirect()->route($this->indexRoute('ekskul'))->with('success', 'Data ekskul berhasil diperbarui.');
    }

    public function destroy(Ekskul $ekskul)
    {
        $ekskul->delete();

        return redirect()->route($this->indexRoute('ekskul'))->with('success', 'Data ekskul berhasil dihapus.');
    }
}
