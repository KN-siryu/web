<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pendaftar;
use Illuminate\Http\Request;

class PendaftarController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $status = $request->input('status', 'all');

        $pendaftars = Pendaftar::when($search, function ($query) use ($search) {
            $query->where('nama_lengkap', 'like', "%$search%")
                ->orWhere('kode_pendaftaran', 'like', "%$search%");
        })->when($status != 'all', function ($query) use ($status) {
            $query->where('status', $status);
        })->latest()->paginate(10);

        $totalPending = Pendaftar::where('status', 'Pending')->count();
        $totalDiterima = Pendaftar::where('status', 'Diterima')->count();
        $totalDitolak = Pendaftar::where('status', 'Ditolak')->count();

        return view('admin.pendaftar.index', compact('pendaftars', 'status', 'totalPending', 'totalDiterima', 'totalDitolak'));
    }

    public function show(Pendaftar $pendaftar)
    {
        return view('admin.pendaftar.show', compact('pendaftar'));
    }

    public function updateStatus(Request $request, Pendaftar $pendaftar)
    {
        $request->validate([
            'status' => 'required|in:Pending,Diterima,Ditolak',
        ]);

        $pendaftar->update(['status' => $request->status]);

        return back()->with('success', 'Status pendaftar berhasil diperbarui menjadi '.$request->status);
    }
}
