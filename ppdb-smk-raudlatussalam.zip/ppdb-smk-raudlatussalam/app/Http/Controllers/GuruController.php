<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use App\Models\Ekskul;
use App\Models\Pendaftar;
use App\Models\Staf;

class GuruController extends Controller
{
    public function dashboard()
    {
        $totalPendaftar = Pendaftar::count();
        $totalPendaftarDiterima = Pendaftar::where('status', 'Diterima')->count();
        $totalPendaftarPending = Pendaftar::where('status', 'Pending')->count();
        $totalPendaftarDitolak = Pendaftar::where('status', 'Ditolak')->count();
        $recentBeritas = Berita::latest()->take(5)->get();
        $stafCount = Staf::count();
        $ekskulCount = Ekskul::count();

        return view('guru.dashboard', compact(
            'totalPendaftar', 'totalPendaftarDiterima', 'totalPendaftarPending', 'totalPendaftarDitolak',
            'recentBeritas', 'stafCount', 'ekskulCount'
        ));
    }
}
