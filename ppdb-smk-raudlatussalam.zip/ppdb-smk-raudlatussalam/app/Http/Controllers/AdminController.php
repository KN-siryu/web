<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use App\Models\Ekskul;
use App\Models\Galeri;
use App\Models\Pesan;
use App\Models\Staf;

class AdminController extends Controller
{
    public function dashboard()
    {
        $totalBerita = Berita::count();
        $totalGaleri = Galeri::count();
        $totalStaf = Staf::count();
        $totalEkskul = Ekskul::count();
        $pesanBaru = Pesan::where('status', 'baru')->count();
        $recentBeritas = Berita::latest()->take(5)->get();
        $recentPesan = Pesan::latest()->take(5)->get();

        return view('admin.dashboard', compact(
            'totalBerita', 'totalGaleri', 'totalStaf', 'totalEkskul',
            'pesanBaru', 'recentBeritas', 'recentPesan'
        ));
    }
}
