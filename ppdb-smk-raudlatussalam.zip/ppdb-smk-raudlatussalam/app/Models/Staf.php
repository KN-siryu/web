<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Staf extends Model
{
    protected $table = 'stafs';

    protected $fillable = [
        'nama', 'nip', 'jabatan', 'mata_pelajaran', 'pendidikan', 'foto', 'kategori',
    ];

    public function getFotoUrlAttribute(): ?string
    {
        if (! $this->foto) {
            return null;
        }

        return Str::startsWith($this->foto, ['http://', 'https://'])
            ? $this->foto
            : Storage::disk('public')->url($this->foto);
    }
}
