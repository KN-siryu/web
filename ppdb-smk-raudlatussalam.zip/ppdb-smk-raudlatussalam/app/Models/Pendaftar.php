<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pendaftar extends Model
{
    protected $table = 'pendaftars';

    protected $fillable = [
        'kode_pendaftaran', 'nama_lengkap', 'nisn', 'nik', 'jenis_kelamin',
        'tempat_lahir', 'tanggal_lahir', 'agama', 'alamat', 'asal_sekolah',
        'nama_ayah', 'pekerjaan_ayah', 'telepon_ayah',
        'nama_ibu', 'pekerjaan_ibu', 'telepon_ibu',
        'nama_wali', 'telepon_wali', 'email_wali', 'alamat_wali',
        'jenis_pendaftaran', 'jalur_pendaftaran',
        'path_foto', 'path_kk', 'path_akta', 'path_ijazah',
        'status',
    ];
}
