<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Berita extends Model
{
    protected $table = 'beritas';

    protected $fillable = [
        'judul', 'slug', 'konten', 'gambar', 'penulis', 'kategori',
    ];

    // Otomatis buat slug saat membuat berita
    protected static function boot()
    {
        parent::boot();
        static::creating(function ($berita) {
            $berita->slug = Str::slug($berita->judul).'-'.Str::random(5);
        });
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}
