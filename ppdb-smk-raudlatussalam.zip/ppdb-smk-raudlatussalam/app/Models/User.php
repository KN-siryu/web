<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable(['name', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'foto',
    ];

    /**
     * Get all permission requests for this user.
     */
    public function permissionRequests(): HasMany
    {
        return $this->hasMany(PermissionRequest::class);
    }

    /**
     * Active (approved and within window) permission requests for this user.
     */
    public function activePermissionRequests(): Collection
    {
        return $this->permissionRequests()
            ->where('status', 'approved')
            ->get()
            ->filter(fn (PermissionRequest $request) => $request->isWithinWindow())
            ->values();
    }

    /**
     * Get the module names this user is currently allowed to access.
     *
     * @return array<int, string>
     */
    public function approvedModules(): array
    {
        if ($this->role !== 'guru') {
            return [];
        }

        return $this->activePermissionRequests()
            ->pluck('module')
            ->unique()
            ->values()
            ->all();
    }

    /**
     * Get the action types this user is currently allowed for in a module.
     *
     * @return array<int, string>
     */
    public function approvedActions(string $module): array
    {
        if ($this->role !== 'guru') {
            return ['create', 'edit', 'delete'];
        }

        $actions = $this->activePermissionRequests()
            ->where('module', $module)
            ->pluck('action_type')
            ->all();

        if (in_array('all', $actions, true)) {
            return ['create', 'edit', 'delete'];
        }

        return array_values(array_intersect(['create', 'edit', 'delete'], $actions));
    }

    /**
     * Action types granted by a single permission request.
     *
     * @return array<int, string>
     */
    public function approvedActionsFor(PermissionRequest $request): array
    {
        if ($request->action_type === 'all') {
            return ['create', 'edit', 'delete'];
        }

        return array_values(array_intersect(['create', 'edit', 'delete'], [$request->action_type]));
    }

    /**
     * Determine whether this user may access the given module.
     */
    public function canAccessModule(string $module): bool
    {
        if ($this->role !== 'guru') {
            return true;
        }

        return in_array($module, $this->approvedModules(), true);
    }

    /**
     * Map an action type to the route-name suffixes that represent it.
     *
     * @return array<string, array<int, string>>
     */
    public static function actionRouteMap(): array
    {
        return [
            'create' => ['create', 'store'],
            'edit' => ['edit', 'update', 'status'],
            'delete' => ['destroy'],
        ];
    }

    /**
     * Resolve the action type for a route name, or null when read-only.
     */
    public static function actionForRoute(?string $routeName): ?string
    {
        if (! $routeName) {
            return null;
        }

        foreach (self::actionRouteMap() as $action => $suffixes) {
            foreach ($suffixes as $suffix) {
                if (str_contains($routeName, '.'.$suffix)) {
                    return $action;
                }
            }
        }

        return null;
    }

    /**
     * Determine whether this user may perform an action in a module.
     */
    public function canDo(string $action, string $module): bool
    {
        if ($this->role !== 'guru') {
            return true;
        }

        if (! $this->canAccessModule($module)) {
            return false;
        }

        return in_array($action, $this->approvedActions($module), true);
    }
}
