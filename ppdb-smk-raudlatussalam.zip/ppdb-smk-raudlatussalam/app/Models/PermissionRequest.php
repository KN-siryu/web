<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PermissionRequest extends Model
{
    protected $table = 'permission_requests';

    protected $fillable = [
        'user_id', 'module', 'action_type', 'start_at', 'end_at', 'reason', 'status', 'admin_note', 'approved_by',
    ];

    protected $casts = [
        'status' => 'string',
        'start_at' => 'datetime',
        'end_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function approver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }

    /**
     * Determine whether the request is active (approved and within its window).
     */
    public function isActive(): bool
    {
        return $this->status === 'approved' && $this->isWithinWindow();
    }

    /**
     * Determine whether the request is within its active window.
     */
    public function isWithinWindow(): bool
    {
        if ($this->status !== 'approved') {
            return false;
        }

        $now = now();

        if ($this->start_at && $now->lt($this->start_at)) {
            return false;
        }

        if ($this->end_at && $now->gt($this->end_at)) {
            return false;
        }

        return true;
    }

    /**
     * Human-readable window label for the request.
     */
    public function windowLabel(): string
    {
        if (! $this->start_at && ! $this->end_at) {
            return 'Tanpa batas waktu';
        }

        return ($this->start_at?->format('d M Y H:i') ?? 'Sekarang')
            .' s/d '.($this->end_at?->format('d M Y H:i') ?? 'Tanpa batas');
    }
}
