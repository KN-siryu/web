<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Galeri extends Model
{
    protected $table = 'galeris';

    protected $fillable = [
        'judul', 'deskripsi', 'foto', 'kategori',
    ];

    public function getFotoUrlAttribute(): ?string
    {
        if (! $this->foto) {
            return null;
        }

        return Str::startsWith($this->foto, ['http://', 'https://'])
            ? $this->foto
            : Storage::disk('public')->url($this->foto);
    }
}
