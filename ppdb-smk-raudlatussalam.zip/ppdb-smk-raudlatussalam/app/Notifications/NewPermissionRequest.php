<?php

namespace App\Notifications;

use App\Models\PermissionRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class NewPermissionRequest extends Notification
{
    use Queueable;

    public function __construct(
        public PermissionRequest $permissionRequest
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        $moduleLabels = [
            'berita' => 'Berita & Artikel',
            'galeri' => 'Galeri Foto',
            'ekskul' => 'Ekstrakurikuler',
            'staf' => 'Staf Pengajar',
            'fasilitas' => 'Fasilitas',
            'pendaftar' => 'Pendaftar PPDB',
        ];

        $actionLabels = [
            'create' => 'Tambah Data',
            'edit' => 'Edit Data',
            'delete' => 'Hapus Data',
            'all' => 'Semua (Tambah, Edit, Hapus)',
        ];

        return [
            'title' => 'Permintaan Izin Akses Baru',
            'message' => "<strong>{$this->permissionRequest->user->name}</strong> mengajukan izin akses untuk modul <strong>{$moduleLabels[$this->permissionRequest->module]}</strong> dengan tipe <strong>{$actionLabels[$this->permissionRequest->action_type]}</strong>. Diajukan berlaku: <strong>{$this->permissionRequest->windowLabel()}</strong>.",
            'permission_request_id' => $this->permissionRequest->id,
            'status' => 'pending',
        ];
    }
}
