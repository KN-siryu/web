<?php

namespace App\Notifications;

use App\Models\PermissionRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class PermissionRequestStatus extends Notification
{
    use Queueable;

    public function __construct(
        public PermissionRequest $permissionRequest,
        public string $status
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        $moduleLabels = [
            'berita' => 'Berita & Artikel',
            'galeri' => 'Galeri Foto',
            'ekskul' => 'Ekstrakurikuler',
            'staf' => 'Staf Pengajar',
            'fasilitas' => 'Fasilitas',
            'pendaftar' => 'Pendaftar PPDB',
        ];

        $actionLabels = [
            'create' => 'Tambah Data',
            'edit' => 'Edit Data',
            'delete' => 'Hapus Data',
            'all' => 'Semua (Tambah, Edit, Hapus)',
        ];

        $isApproved = $this->status === 'approved';
        $isRevoked = $this->status === 'revoked';

        return [
            'title' => match ($this->status) {
                'approved' => 'Izin Akses Disetujui',
                'revoked' => 'Izin Akses Dihentikan',
                default => 'Izin Akses Ditolak',
            },
            'message' => match (true) {
                $isApproved => "Permintaan izin akses Anda untuk modul <strong>{$moduleLabels[$this->permissionRequest->module]}</strong> dengan tipe <strong>{$actionLabels[$this->permissionRequest->action_type]}</strong> telah <strong>DISETUJUI</strong>. Berlaku: <strong>{$this->permissionRequest->windowLabel()}</strong>.",
                $isRevoked => "Izin akses Anda untuk modul <strong>{$moduleLabels[$this->permissionRequest->module]}</strong> dengan tipe <strong>{$actionLabels[$this->permissionRequest->action_type]}</strong> telah <strong>DIHENTIKAN</strong> oleh admin. Akses ke modul tersebut sekarang dinonaktifkan. ".($this->permissionRequest->admin_note ? "Catatan: {$this->permissionRequest->admin_note}" : ''),
                default => "Permintaan izin akses Anda untuk modul <strong>{$moduleLabels[$this->permissionRequest->module]}</strong> dengan tipe <strong>{$actionLabels[$this->permissionRequest->action_type]}</strong> telah <strong>DITOLAK</strong>. ".($this->permissionRequest->admin_note ? "Alasan: {$this->permissionRequest->admin_note}" : ''),
            },
            'permission_request_id' => $this->permissionRequest->id,
            'status' => $this->status,
        ];
    }
}
