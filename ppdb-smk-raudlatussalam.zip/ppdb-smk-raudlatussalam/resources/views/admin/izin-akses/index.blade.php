@extends('layouts.admin')

@section('title', 'Manajemen Izin Akses Guru - Admin')
@section('header_title', 'Izin Akses Guru')

@section('content')
<div class="max-w-7xl mx-auto">
    <div class="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div class="animate-fade-in-up">
            <h3 class="flex items-center gap-2 text-xl font-bold text-slate-900">
                <span class="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 018.618 3.078A6.002 6.002 0 0022 5.396v.001A6.002 6.002 0 0120.803 12c0 1.363-.475 2.61-1.218 3.556m-5.945-3.556a6.002 6.002 0 01-1.218-3.556c0-.772.132-1.523.38-2.22m-2.645 7.743c.636.412 1.293.79 1.977 1.097 1.328.616 2.784.91 4.302.91 1.518 0 2.974-.294 4.302-.91.684-.307 1.341-.685 1.977-1.097m-9.743-1.097c.636-.412 1.293-.79 1.977-1.097 1.328-.616 2.784-.91 4.302-.91 1.518 0 2.974.294 4.302.91.684.307 1.341.685 1.977 1.097"></path></svg>
                </span>
                Manajemen Izin Akses
            </h3>
            <p class="mt-1 text-sm text-slate-600">Tinjau, atur masa berlaku, lalu setujui atau tolak permintaan izin akses dari guru.</p>
        </div>
        <div class="flex flex-wrap gap-2 animate-fade-in-up delay-1">
            @php
                $pendingCount = $requests->getCollection()->where('status', 'pending')->count();
                $activeCount = $requests->getCollection()->filter(fn ($r) => $r->status === 'approved' && $r->isWithinWindow())->count();
            @endphp
            <span class="inline-flex items-center gap-2 rounded-full bg-amber-100 px-3 py-1.5 text-xs font-semibold text-amber-700">
                <span class="h-2 w-2 animate-pulse rounded-full bg-amber-500"></span>
                {{ $pendingCount }} Menunggu
            </span>
            <span class="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-semibold text-emerald-700">
                <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                {{ $activeCount }} Aktif
            </span>
        </div>
    </div>

    <div class="grid gap-4 md:hidden">
        @forelse($requests as $req)
            @php
                $moduleLabels = ['berita' => 'Berita & Artikel', 'galeri' => 'Galeri Foto', 'ekskul' => 'Ekstrakurikuler', 'staf' => 'Staf Pengajar', 'fasilitas' => 'Fasilitas', 'pendaftar' => 'Pendaftar PPDB', 'pesan' => 'Pesan Masuk'];
                $actionLabels = ['create' => 'Tambah Data', 'edit' => 'Edit Data', 'delete' => 'Hapus Data', 'all' => 'Semua Akses'];
                $active = $req->status === 'approved' && $req->isWithinWindow();
                $expired = $req->status === 'approved' && ! $req->isWithinWindow();
            @endphp
            <div class="animate-fade-in-up rounded-2xl border border-slate-100 bg-white p-4 shadow-sm transition hover:shadow-md">
                <div class="flex items-start justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-sm font-bold text-emerald-700">
                            {{ strtoupper(substr($req->user->name, 0, 1)) }}
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-slate-900">{{ $req->user->name }}</p>
                            <p class="text-xs text-slate-500">{{ $moduleLabels[$req->module] ?? $req->module }}</p>
                        </div>
                    </div>
                    @if($req->status === 'pending')
                        <span class="shrink-0 rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-semibold text-amber-700">Pending</span>
                    @elseif($req->status === 'approved' && $active)
                        <span class="shrink-0 rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-semibold text-emerald-700">Aktif</span>
                    @elseif($req->status === 'approved' && $expired)
                        <span class="shrink-0 rounded-full bg-slate-200 px-2.5 py-1 text-[11px] font-semibold text-slate-600">Kedaluwarsa</span>
                    @elseif($req->status === 'revoked')
                        <span class="shrink-0 rounded-full bg-slate-200 px-2.5 py-1 text-[11px] font-semibold text-slate-600">Dihentikan</span>
                    @else
                        <span class="shrink-0 rounded-full bg-red-100 px-2.5 py-1 text-[11px] font-semibold text-red-700">Ditolak</span>
                    @endif
                </div>
                <dl class="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div class="rounded-lg bg-slate-50 p-2">
                        <dt class="text-slate-500">Tipe Akses</dt>
                        <dd class="font-semibold text-slate-800">{{ $actionLabels[$req->action_type] ?? $req->action_type }}</dd>
                    </div>
                    <div class="rounded-lg bg-slate-50 p-2">
                        <dt class="text-slate-500">Diajukan</dt>
                        <dd class="font-semibold text-slate-800">{{ $req->created_at->format('d M Y H:i') }}</dd>
                    </div>
                    <div class="col-span-2 rounded-lg bg-slate-50 p-2">
                        <dt class="text-slate-500">Masa Berlaku</dt>
                        <dd class="font-semibold text-slate-800">{{ $req->windowLabel() }}</dd>
                    </div>
                </dl>
                @if($req->status === 'pending')
                    <div class="mt-3 flex gap-2">
                        <button type="button" @click="$dispatch('open-approve', { id: {{ $req->id }} })"
                                class="flex-1 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-emerald-700">Atur & Setujui</button>
                        <form method="POST" action="{{ route('admin.izin-akses.reject', $req) }}" class="flex-1">
                            @csrf @method('PUT')
                            <input type="hidden" name="admin_note" value="Ditolak oleh admin">
                            <button type="submit" class="w-full rounded-xl bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 transition hover:bg-red-100">Tolak</button>
                        </form>
                    </div>
                @elseif($req->status === 'approved')
                    <form method="POST" action="{{ route('admin.izin-akses.revoke', $req) }}" class="mt-3"
                          onsubmit="return confirm('Hentikan izin akses guru ini? Akses ke modul akan langsung dinonaktifkan.')">
                        @csrf @method('PUT')
                        <input type="hidden" name="admin_note" value="Izin dihentikan oleh admin.">
                        <button type="submit" class="w-full rounded-xl bg-red-50 px-3 py-2 text-xs font-semibold text-red-600 transition hover:bg-red-100">
                            Hentikan Izin
                        </button>
                    </form>
                @endif
            </div>
        @empty
            <p class="rounded-2xl border border-slate-100 bg-white p-8 text-center text-sm text-slate-500">Tidak ada permintaan izin akses.</p>
        @endforelse
    </div>

    <div class="hidden overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm md:block">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Guru</th>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Modul</th>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Tipe Akses</th>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Masa Berlaku</th>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Alasan</th>
                        <th class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-500">Status</th>
                        <th class="px-6 py-4 text-right text-xs font-medium uppercase tracking-wider text-slate-500">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 bg-white">
                    @forelse($requests as $req)
                        @php
                            $moduleLabels = ['berita' => 'Berita & Artikel', 'galeri' => 'Galeri Foto', 'ekskul' => 'Ekstrakurikuler', 'staf' => 'Staf Pengajar', 'fasilitas' => 'Fasilitas', 'pendaftar' => 'Pendaftar PPDB', 'pesan' => 'Pesan Masuk'];
                            $actionLabels = ['create' => 'Tambah Data', 'edit' => 'Edit Data', 'delete' => 'Hapus Data', 'all' => 'Semua Akses'];
                            $active = $req->status === 'approved' && $req->isWithinWindow();
                            $expired = $req->status === 'approved' && ! $req->isWithinWindow();
                        @endphp
                        <tr class="transition hover:bg-slate-50/60">
                            <td class="whitespace-nowrap px-6 py-4">
                                <div class="flex items-center">
                                    <div class="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700">
                                        {{ strtoupper(substr($req->user->name, 0, 1)) }}
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium text-slate-900">{{ $req->user->name }}</p>
                                        <p class="text-xs text-slate-500">{{ $req->user->email }}</p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <p class="text-sm capitalize text-slate-900">{{ $moduleLabels[$req->module] ?? $req->module }}</p>
                            </td>
                            <td class="px-6 py-4">
                                <span class="text-sm capitalize text-slate-600">{{ $actionLabels[$req->action_type] ?? $req->action_type }}</span>
                            </td>
                            <td class="px-6 py-4">
                                <p class="text-sm text-slate-700">{{ $req->windowLabel() }}</p>
                                @if($req->status === 'approved')
                                    @if($active)
                                        <span class="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                                            <span class="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500"></span> Aktif
                                        </span>
                                    @elseif($expired)
                                        <span class="mt-1 inline-flex text-[11px] font-semibold text-slate-500">Kedaluwarsa</span>
                                    @endif
                                @endif
                            </td>
                            <td class="px-6 py-4">
                                <p class="max-w-xs truncate text-sm text-slate-600" title="{{ $req->reason }}">{{ $req->reason }}</p>
                            </td>
                            <td class="whitespace-nowrap px-6 py-4">
                                @if($req->status === 'pending')
                                    <span class="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">Pending</span>
                                @elseif($req->status === 'approved')
                                    <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">Disetujui</span>
                                @elseif($req->status === 'revoked')
                                    <span class="rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold text-slate-600">Dihentikan</span>
                                @else
                                    <span class="rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-700">Ditolak</span>
                                @endif
                            </td>
                            <td class="whitespace-nowrap px-6 py-4 text-right">
                                @if($req->status === 'pending')
                                    <button type="button" @click="$dispatch('open-approve', { id: {{ $req->id }} })"
                                            class="mr-2 inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white transition hover:-translate-y-0.5 hover:bg-emerald-700">
                                        Atur & Setujui
                                    </button>
                                    <form method="POST" action="{{ route('admin.izin-akses.reject', $req) }}" class="inline">
                                        @csrf @method('PUT')
                                        <input type="hidden" name="admin_note" value="Ditolak oleh admin">
                                        <button type="submit" class="rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-red-700">Tolak</button>
                                    </form>
                                @elseif($req->status === 'approved')
                                    <form method="POST" action="{{ route('admin.izin-akses.revoke', $req) }}" class="inline"
                                          onsubmit="return confirm('Hentikan izin akses guru ini? Akses ke modul akan langsung dinonaktifkan.')">
                                        @csrf @method('PUT')
                                        <input type="hidden" name="admin_note" value="Izin dihentikan oleh admin.">
                                        <button type="submit" class="inline-flex items-center gap-1 rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 transition hover:bg-red-100">
                                            <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
                                            Hentikan Izin
                                        </button>
                                    </form>
                                @else
                                    <span class="text-xs text-slate-500">Diproses</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-10 text-center text-slate-500">Tidak ada permintaan izin akses.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="border-t border-slate-100 px-6 py-4">
            {{ $requests->links() }}
        </div>
    </div>
</div>

@foreach($requests as $req)
    @if($req->status === 'pending')
        <div x-data="approveModal({{ $req->id }}, '{{ \Illuminate\Support\Carbon::parse($req->start_at ?? now())->format('Y-m-d\TH:i') }}', '{{ \Illuminate\Support\Carbon::parse($req->end_at ?? now()->addDays(7))->format('Y-m-d\TH:i') }}')"
             x-on:open-approve.window="if ($event.detail.id === {{ $req->id }}) { open = true }"
             x-show="open" x-cloak
             class="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4"
             role="dialog" aria-modal="true">
            <div class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" @click="open = false"
                 x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"></div>

            <div class="relative z-10 w-full max-w-lg overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl"
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-6 sm:scale-95"
                 x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100">
                <div class="flex items-center justify-between bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-4">
                    <div class="flex items-center gap-3">
                        <span class="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/15 text-white ring-1 ring-white/30">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        </span>
                        <div>
                            <h4 class="text-base font-bold text-white">Atur Masa Berlaku Izin</h4>
                            <p class="text-xs text-emerald-50">{{ $req->user->name }} · {{ $req->module }}</p>
                        </div>
                    </div>
                    <button type="button" @click="open = false" class="rounded-lg p-1.5 text-emerald-50 transition hover:bg-white/15">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                <form method="POST" action="{{ route('admin.izin-akses.approve', $req) }}" class="space-y-5 p-6">
                    @csrf @method('PUT')

                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                            <label class="mb-2 block text-sm font-medium text-slate-700">Mulai Berlaku *</label>
                            <input type="datetime-local" name="start_at" x-model="startAt" @change="syncMin()"
                                   class="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500">
                        </div>
                        <div>
                            <label class="mb-2 block text-sm font-medium text-slate-700">Berakhir *</label>
                            <input type="datetime-local" name="end_at" x-model="endAt" :min="startAt"
                                   class="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500">
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-2">
                        <span class="text-xs font-medium text-slate-500">Durasi cepat:</span>
                        @foreach(['1' => '1 Hari', '3' => '3 Hari', '7' => '1 Minggu', '30' => '30 Hari'] as $days => $label)
                            <button type="button" @click="setDuration({{ $days }})"
                                    class="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 transition hover:bg-emerald-100 hover:text-emerald-700">
                                + {{ $label }}
                            </button>
                        @endforeach
                    </div>

                    <div class="rounded-2xl border border-emerald-100 bg-gradient-to-br from-emerald-50 to-teal-50 p-4">
                        <p class="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            Ringkasan
                        </p>
                        <div class="grid grid-cols-2 gap-3 text-sm">
                            <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                                <p class="text-[11px] uppercase text-slate-500">Mulai</p>
                                <p class="mt-0.5 font-semibold text-slate-800" x-text="fmt(startAt)"></p>
                            </div>
                            <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                                <p class="text-[11px] uppercase text-slate-500">Berakhir</p>
                                <p class="mt-0.5 font-semibold text-slate-800" x-text="fmt(endAt)"></p>
                            </div>
                        </div>
                        <p class="mt-3 flex items-center gap-2 text-xs text-emerald-700">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            Total durasi: <span class="font-semibold" x-text="duration()"></span>
                        </p>
                    </div>

                    <div>
                        <label class="mb-2 block text-sm font-medium text-slate-700">Catatan Admin (opsional)</label>
                        <textarea name="admin_note" rows="2"
                                  class="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                                  placeholder="Contoh: Disetujui untuk keperluan input data semester ganjil."></textarea>
                    </div>

                    <div class="flex flex-col-reverse gap-3 pt-1 sm:flex-row sm:justify-end">
                        <button type="button" @click="open = false"
                                class="rounded-xl bg-slate-100 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200">Batal</button>
                        <button type="submit"
                                class="group inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-200 transition hover:-translate-y-0.5 hover:bg-emerald-700">
                            <svg class="h-5 w-5 transition-transform group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            Setujui dengan Masa Ini
                        </button>
                    </div>
                </form>
            </div>
        </div>
    @endif
@endforeach

@push('scripts')
<script>
    function approveModal(id, start, end) {
        return {
            id,
            open: false,
            startAt: start,
            endAt: end,

            syncMin() {
                if (this.endAt && this.startAt && new Date(this.endAt) < new Date(this.startAt)) {
                    this.endAt = this.startAt;
                }
            },

            setDuration(days) {
                if (! this.startAt) {
                    return;
                }
                const d = new Date(this.startAt);
                d.setDate(d.getDate() + days);
                const pad = (n) => String(n).padStart(2, '0');
                this.endAt = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
            },

            fmt(value) {
                if (! value) {
                    return '-';
                }
                const d = new Date(value);
                if (isNaN(d)) {
                    return '-';
                }
                return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
            },

            duration() {
                if (! this.startAt || ! this.endAt) {
                    return '-';
                }
                const ms = new Date(this.endAt) - new Date(this.startAt);
                if (isNaN(ms) || ms <= 0) {
                    return '-';
                }
                const minutes = Math.floor(ms / 60000);
                const days = Math.floor(minutes / 1440);
                const hours = Math.floor((minutes % 1440) / 60);
                const mins = minutes % 60;
                const parts = [];
                if (days) { parts.push(days + ' hari'); }
                if (hours) { parts.push(hours + ' jam'); }
                if (mins && ! days) { parts.push(mins + ' menit'); }
                return parts.join(' ') || '< 1 menit';
            },
        };
    }
</script>
@endpush
@endsection