@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'fasilitas');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'fasilitas');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'fasilitas');
@endphp

@section('title', 'Kelola Fasilitas')
@section('header_title', 'Kelola Fasilitas Sekolah')

@section('content')
<div class="space-y-6">
    @if(session('success'))
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl">{{ session('success') }}</div>
    @endif

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari fasilitas..." value="{{ request('search') }}" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            @if($canCreate)
            <a href="{{ route($prefix.'fasilitas.create') }}" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Fasilitas
            </a>
            @endif
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Icon</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Deskripsi</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Urutan</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    @forelse($fasilitas as $item)
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4">
                            <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-xl text-emerald-700">{{ $item->icon ?: '✓' }}</span>
                        </td>
                        <td class="px-6 py-4 text-sm font-medium text-slate-900">{{ $item->nama }}</td>
                        <td class="px-6 py-4 text-sm text-slate-600 max-w-md">{{ Str::limit($item->deskripsi ?? 'Tidak ada deskripsi', 90) }}</td>
                        <td class="px-6 py-4 text-sm text-slate-600">{{ $item->urutan }}</td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="{{ route('profil.fasilitas') }}" target="_blank" class="text-slate-500 hover:text-emerald-600 font-medium">Lihat</a>
                            @if($canEdit)
                            <a href="{{ route($prefix.'fasilitas.edit', $item) }}" class="text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            @endif
                            @if($canDelete)
                            <form action="{{ route($prefix.'fasilitas.destroy', $item) }}" method="POST" class="inline-block" onsubmit="return confirm('Hapus fasilitas ini?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="5" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada data fasilitas.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="px-6 py-4 border-t border-slate-100">{{ $fasilitas->links() }}</div>
    </div>
</div>
@endsection
