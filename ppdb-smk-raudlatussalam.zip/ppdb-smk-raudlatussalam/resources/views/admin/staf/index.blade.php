@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'staf');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'staf');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'staf');
@endphp

@section('title', 'Kelola Staf')
@section('header_title', 'Kelola Staf Pengajar')

@section('content')
<div class="space-y-6">
    @if(session('success'))
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl">{{ session('success') }}</div>
    @endif

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari nama staf..." value="{{ request('search') }}" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            @if($canCreate)
            <a href="{{ route($prefix.'staf.create') }}" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Staf
            </a>
            @endif
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama Staf</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Jabatan</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Kategori</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    @forelse($stafs as $staf)
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <img src="{{ $staf->foto ? asset('storage/' . $staf->foto) : 'https://ui-avatars.com/api/?name='.urlencode($staf->nama).'&background=f1f5f9&color=0f172a' }}" class="w-10 h-10 rounded-full object-cover">
                                <div>
                                    <p class="text-sm font-medium text-slate-900">{{ $staf->nama }}</p>
                                    <p class="text-xs text-slate-400">{{ $staf->nip ? 'NIP: '.$staf->nip : 'Tanpa NIP' }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <p class="text-sm text-slate-600">{{ $staf->jabatan }}</p>
                            @if($staf->mata_pelajaran)
                            <p class="text-xs text-slate-400">{{ $staf->mata_pelajaran }}</p>
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg 
                                {{ $staf->kategori == 'Kepala Sekolah' ? 'bg-emerald-50 text-emerald-600' : '' }}
                                {{ $staf->kategori == 'Pengajar' ? 'bg-blue-50 text-blue-600' : '' }}
                                {{ $staf->kategori == 'Tenaga Kependidikan' ? 'bg-purple-50 text-purple-600' : '' }}
                            ">{{ $staf->kategori }}</span>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            @if($canEdit)
                            <a href="{{ route($prefix.'staf.edit', $staf) }}" class="text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            @endif
                            @if($canDelete)
                            <form action="{{ route($prefix.'staf.destroy', $staf) }}" method="POST" class="inline-block" onsubmit="return confirm('Hapus data staf ini?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada data staf.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100">{{ $stafs->links() }}</div>
    </div>
</div>
@endsection