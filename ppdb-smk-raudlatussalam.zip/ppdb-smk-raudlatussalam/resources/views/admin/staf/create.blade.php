@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
@endphp

@section('title', 'Tambah Staf')
@section('header_title', 'Tambah Data Staf Baru')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="{{ route($prefix.'staf.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            
            @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
                </ul>
            </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Lengkap *</label>
                    <input type="text" name="nama" value="{{ old('nama') }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">NIP (Opsional)</label>
                    <input type="text" name="nip" value="{{ old('nip') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Jabatan *</label>
                    <input type="text" name="jabatan" value="{{ old('jabatan') }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: Guru Produktif">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Kategori *</label>
                    <select name="kategori" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                        <option value="Pengajar" {{ old('kategori') == 'Pengajar' ? 'selected' : '' }}>Guru Pengajar</option>
                        <option value="Kepala Sekolah" {{ old('kategori') == 'Kepala Sekolah' ? 'selected' : '' }}>Kepala Sekolah</option>
                        <option value="Tenaga Kependidikan" {{ old('kategori') == 'Tenaga Kependidikan' ? 'selected' : '' }}>Tenaga Kependidikan</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Mata Pelajaran (Opsional)</label>
                    <input type="text" name="mata_pelajaran" value="{{ old('mata_pelajaran') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Pendidikan (Opsional)</label>
                    <input type="text" name="pendidikan" value="{{ old('pendidikan') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: S1 Teknik Informatika">
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Foto Staf (Opsional)</label>
                <input type="file" name="foto" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="{{ route($prefix.'staf.index') }}" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Simpan Staf</button>
            </div>
        </form>
    </div>
</div>
@endsection