@extends('layouts.admin')

@section('title', 'Dashboard Admin')
@section('header_title', 'Dashboard')

@section('content')
@php
    $pesanBaruCount = $pesanBaru;
    $pendingPendaftar = \App\Models\Pendaftar::where('status', 'Pending')->count();
@endphp
<div class="space-y-6">
    {{-- Hero --}}
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-700 p-6 shadow-lg shadow-emerald-200/60 sm:p-8 animate-fade-in-up">
        <div class="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/10 blur-2xl"></div>
        <div class="pointer-events-none absolute -bottom-20 left-10 h-48 w-48 rounded-full bg-emerald-300/20 blur-3xl"></div>
        <div class="relative flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
            <div>
                <p class="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-emerald-100">
                    <span class="inline-block h-2 w-2 animate-pulse rounded-full bg-emerald-300"></span>
                    Dashboard Admin
                </p>
                <h2 class="mt-2 text-2xl font-extrabold text-white sm:text-3xl">
                    Assalamu'alaikum, {{ auth()->user()->name }} 👋
                </h2>
                <p class="mt-1 max-w-xl text-sm text-emerald-50">
                    Selamat datang di panel administrasi. Kelola konten website sekolah dengan mudah dan pantau aktivitas terbaru.
                </p>
            </div>
            <div class="flex shrink-0 flex-wrap gap-3">
                <a href="{{ route('admin.berita.create') }}"
                   class="group inline-flex items-center gap-2 rounded-2xl bg-white/15 px-4 py-3 text-sm font-semibold text-white ring-1 ring-white/30 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/25">
                    <svg class="h-5 w-5 transition-transform duration-300 group-hover:rotate-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                    Tambah Berita
                </a>
                <a href="{{ route('admin.pendaftar.index') }}"
                   class="group inline-flex items-center gap-2 rounded-2xl bg-white/15 px-4 py-3 text-sm font-semibold text-white ring-1 ring-white/30 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/25">
                    <svg class="h-5 w-5 transition-transform duration-300 group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                    </svg>
                    Pendaftar
                    @if($pendingPendaftar > 0)
                        <span class="ml-1 rounded-full bg-red-500 px-2 py-0.5 text-[11px] font-bold text-white">{{ $pendingPendaftar }}</span>
                    @endif
                </a>
            </div>
        </div>
    </div>

    {{-- Stat cards --}}
    <div class="grid grid-cols-2 gap-4 lg:grid-cols-5">
        @php
            $cards = [
                ['label' => 'Total Berita', 'value' => $totalBerita, 'icon' => 'M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z', 'tint' => 'from-emerald-500 to-teal-600', 'ring' => 'ring-emerald-100'],
                ['label' => 'Total Galeri', 'value' => $totalGaleri, 'icon' => 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z', 'tint' => 'from-sky-500 to-blue-600', 'ring' => 'ring-sky-100'],
                ['label' => 'Total Staf', 'value' => $totalStaf, 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 004 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z', 'tint' => 'from-violet-500 to-purple-600', 'ring' => 'ring-violet-100'],
                ['label' => 'Total Ekskul', 'value' => $totalEkskul, 'icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z', 'tint' => 'from-amber-500 to-orange-600', 'ring' => 'ring-amber-100'],
                ['label' => 'Pesan Baru', 'value' => $pesanBaruCount, 'icon' => 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z', 'tint' => 'from-rose-500 to-red-600', 'ring' => 'ring-rose-100'],
            ];
        @endphp
        @foreach($cards as $i => $card)
            <div class="group relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg animate-fade-in-up delay-{{ $i + 1 }}">
                <div class="absolute inset-x-0 top-0 h-1 bg-gradient-to-r {{ $card['tint'] }}"></div>
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-slate-500">{{ $card['label'] }}</p>
                        <p class="mt-1 text-3xl font-extrabold text-slate-900">{{ $card['value'] }}</p>
                    </div>
                    <span class="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br {{ $card['tint'] }} text-white shadow-md transition-transform duration-300 group-hover:scale-110">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $card['icon'] }}"></path>
                        </svg>
                    </span>
                </div>
            </div>
        @endforeach
    </div>

    {{-- Quick actions --}}
    <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm animate-fade-in-up delay-3">
        <h3 class="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-900">
            <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h7z"></path></svg>
            </span>
            Aksi Cepat
        </h3>
        <div class="grid grid-cols-2 gap-3 md:grid-cols-4">
            @foreach([
                ['route' => 'admin.berita.create', 'label' => 'Tambah Berita', 'icon' => 'M12 4v16m8-8H4'],
                ['route' => 'admin.galeri.create', 'label' => 'Tambah Foto', 'icon' => 'M12 4v16m8-8H4'],
                ['route' => 'admin.staf.create', 'label' => 'Tambah Staf', 'icon' => 'M12 4v16m8-8H4'],
                ['route' => 'admin.pesan.index', 'label' => 'Lihat Pesan', 'icon' => 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
            ] as $action)
                <a href="{{ route($action['route']) }}"
                   class="group flex flex-col items-center justify-center gap-2 rounded-xl border border-slate-100 bg-slate-50 p-5 text-xs font-semibold text-slate-600 transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700">
                    <svg class="h-6 w-6 text-slate-400 transition group-hover:scale-110 group-hover:text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="{{ $action['icon'] }}"></path>
                    </svg>
                    {{ $action['label'] }}
                </a>
            @endforeach
        </div>
    </div>

    {{-- Recent activity --}}
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-md animate-fade-in-up delay-2">
            <div class="mb-4 flex items-center justify-between">
                <h3 class="flex items-center gap-2 text-sm font-semibold text-slate-900">
                    <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path></svg>
                    </span>
                    Berita Terbaru
                </h3>
                <a href="{{ route('admin.berita.index') }}" class="text-xs font-semibold text-emerald-600 transition hover:text-emerald-800">Lihat Semua →</a>
            </div>
            <div class="divide-y divide-slate-50">
                @forelse($recentBeritas as $berita)
                    <div class="flex items-start gap-3 py-3">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path></svg>
                        </div>
                        <div class="min-w-0 flex-1">
                            <p class="truncate text-sm font-semibold text-slate-900">{{ $berita->judul }}</p>
                            <p class="mt-0.5 text-xs text-slate-500">{{ $berita->created_at->format('d M Y') }} · {{ $berita->kategori }}</p>
                        </div>
                    </div>
                @empty
                    <p class="py-6 text-center text-sm text-slate-400">Belum ada berita.</p>
                @endforelse
            </div>
        </div>

        <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-md animate-fade-in-up delay-4">
            <div class="mb-4 flex items-center justify-between">
                <h3 class="flex items-center gap-2 text-sm font-semibold text-slate-900">
                    <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-sky-100 text-sky-700">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    </span>
                    Pesan Masuk Terbaru
                </h3>
                <a href="{{ route('admin.pesan.index') }}" class="text-xs font-semibold text-emerald-600 transition hover:text-emerald-800">Lihat Semua →</a>
            </div>
            <div class="divide-y divide-slate-50">
                @forelse($recentPesan as $pesan)
                    <a href="{{ route('admin.pesan.show', $pesan) }}" class="flex items-start gap-3 rounded-lg py-3 transition hover:bg-slate-50">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-sky-50 text-sky-600">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                        </div>
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center justify-between gap-2">
                                <p class="truncate text-sm font-semibold text-slate-900">{{ $pesan->nama }}</p>
                                @if($pesan->status == 'baru')
                                    <span class="h-2 w-2 shrink-0 animate-pulse rounded-full bg-red-500"></span>
                                @endif
                            </div>
                            <p class="mt-0.5 truncate text-xs text-slate-500">{{ $pesan->subjek }}</p>
                        </div>
                    </a>
                @empty
                    <p class="py-6 text-center text-sm text-slate-400">Belum ada pesan masuk.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection