@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'pesan');
@endphp

@section('title', 'Pesan Masuk')
@section('header_title', 'Pesan & Saran Masuk')

@section('content')
<div class="space-y-6">
    @if(session('success'))
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl">{{ session('success') }}</div>
    @endif

    <!-- Info Pesan Baru -->
    @if($pesanBaru > 0)
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center">
        <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
        </div>
        <div>
            <p class="text-sm font-semibold text-blue-900">Ada {{ $pesanBaru }} pesan baru yang belum dibaca!</p>
            <p class="text-xs text-blue-700 mt-0.5">Klik pada pesan untuk membaca detailnya.</p>
        </div>
    </div>
    @endif

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari pesan..." value="{{ request('search') }}" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <span class="text-sm text-slate-500">Total: {{ $pesans->total() }} pesan</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Pengirim</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Subjek</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    @forelse($pesans as $pesan)
                    <tr class="hover:bg-slate-50 {{ $pesan->status == 'baru' ? 'bg-blue-50/30' : '' }}">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center text-xs font-bold text-slate-600 uppercase">
                                    {{ substr($pesan->nama, 0, 1) }}
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-slate-900">{{ $pesan->nama }}</p>
                                    <p class="text-xs text-slate-400">{{ $pesan->email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600 max-w-xs truncate">{{ $pesan->subjek }}</td>
                        <td class="px-6 py-4 text-sm text-slate-500">{{ $pesan->created_at->format('d M Y, H:i') }}</td>
                        <td class="px-6 py-4">
                            @if($pesan->status == 'baru')
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-red-50 text-red-600">Baru</span>
                            @else
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-slate-100 text-slate-500">Dibaca</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="{{ route($prefix.'pesan.show', $pesan) }}" class="text-slate-500 hover:text-emerald-600 font-medium">Baca</a>
                            @if($canDelete)
                            <form action="{{ route($prefix.'pesan.destroy', $pesan) }}" method="POST" class="inline-block" onsubmit="return confirm('Hapus pesan ini?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="5" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada pesan masuk.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100">{{ $pesans->links() }}</div>
    </div>
</div>
@endsection