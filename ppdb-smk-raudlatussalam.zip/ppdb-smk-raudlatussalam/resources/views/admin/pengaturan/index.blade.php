@extends('layouts.admin')

@section('title', 'Pengaturan Website')
@section('header_title', 'Pengaturan Website')

@section('content')
<div class="max-w-3xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        
        @if(session('success'))
        <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-sm">
            {{ session('success') }}
        </div>
        @endif

        <form action="{{ route('admin.pengaturan.update') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            
            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Nama Sekolah</label>
                <input type="text" name="nama_sekolah" value="{{ old('nama_sekolah', $settings['nama_sekolah'] ?? '') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Telepon</label>
                    <input type="text" name="telepon" value="{{ old('telepon', $settings['telepon'] ?? '') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Email</label>
                    <input type="email" name="email" value="{{ old('email', $settings['email'] ?? '') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Alamat</label>
                <textarea name="alamat" rows="2" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('alamat', $settings['alamat'] ?? '') }}</textarea>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Nama Kepala Sekolah</label>
                <input type="text" name="kepala_sekolah" value="{{ old('kepala_sekolah', $settings['kepala_sekolah'] ?? '') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
            </div>

            <div>
                <h2 class="text-sm font-bold text-slate-800 mb-4">Foto Profil Kepala Sekolah</h2>
                @if(!empty($settings['foto_kepala_sekolah']))
                <img src="{{ asset('storage/'.$settings['foto_kepala_sekolah']) }}" alt="Foto profil kepala sekolah saat ini" class="mb-4 h-28 w-28 rounded-2xl border border-slate-200 object-cover">
                @endif
                <label for="foto_kepala_sekolah" class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Unggah Foto Profil</label>
                <input type="file" id="foto_kepala_sekolah" name="foto_kepala_sekolah" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p class="text-xs text-slate-400 mt-2">Foto profil pada bagian sambutan di beranda. Format JPG, PNG, atau WEBP, maksimal 2 MB.</p>
                @error('foto_kepala_sekolah')
                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Teks Sambutan Kepala Sekolah</label>
                <textarea name="sambutan" rows="5" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('sambutan', $settings['sambutan'] ?? '') }}</textarea>
            </div>

            <div class="border-t border-slate-100 pt-6">
                <h2 class="text-sm font-bold text-slate-800 mb-4">Visi & Misi</h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Visi</label>
                        <textarea name="visi" rows="3" placeholder="Membangun generasi yang berakhlak mulia, cerdas, dan terampil" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('visi', $settings['visi'] ?? '') }}</textarea>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Misi (satu poin per baris)</label>
                        <textarea name="misi" rows="5" placeholder="Mengembangkan karakter berakhlak mulia&#10;Meningkatkan kompetensi ilmu dan keterampilan&#10;Membentuk siswa yang bermanfaat bagi masyarakat" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('misi', $settings['misi'] ?? '') }}</textarea>
                    </div>
                </div>
            </div>

            <div class="border-t border-slate-100 pt-6">
                <h2 class="text-sm font-bold text-slate-800 mb-4">Sejarah Singkat</h2>
                <textarea name="sejarah" rows="6" placeholder="Teks sejarah sekolah..." class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('sejarah', $settings['sejarah'] ?? '') }}</textarea>
            </div>

            <div class="border-t border-slate-100 pt-6">
                <h2 class="text-sm font-bold text-slate-800 mb-4">Logo Website</h2>
                @if(!empty($settings['logo']))
                <img src="{{ asset('storage/'.$settings['logo']) }}" alt="Logo website saat ini" class="w-20 h-20 object-contain rounded-xl border border-slate-200 p-2 mb-4">
                @endif
                <label for="logo" class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Unggah Logo Utama</label>
                <input type="file" id="logo" name="logo" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p class="text-xs text-slate-400 mt-2">Ditampilkan pada navbar, footer, dan panel admin. Format JPG, PNG, atau WEBP, maksimal 2 MB.</p>
                @error('logo')
                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <h2 class="text-sm font-bold text-slate-800 mb-4">Ikon Tab Browser</h2>
                @if(!empty($settings['favicon']))
                <img src="{{ asset('storage/'.$settings['favicon']) }}" alt="Ikon tab browser saat ini" class="w-12 h-12 object-contain rounded-xl border border-slate-200 p-2 mb-4">
                @endif
                <label for="favicon" class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Unggah Favicon</label>
                <input type="file" id="favicon" name="favicon" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p class="text-xs text-slate-400 mt-2">Ikon kecil yang muncul di tab browser. Format JPG, PNG, atau WEBP, maksimal 1 MB.</p>
                @error('favicon')
                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                @enderror
            </div>

            <div class="border-t border-slate-100 pt-6">
                <h2 class="text-sm font-bold text-slate-800 mb-4">Gambar Banner Beranda</h2>
                @if(!empty($settings['hero_image']))
                <img src="{{ asset('storage/'.$settings['hero_image']) }}" alt="Gambar banner beranda saat ini" class="mb-4 aspect-[16/6] w-full rounded-xl border border-slate-200 object-cover">
                @endif
                <label for="hero_image" class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Unggah Gambar Banner</label>
                <input type="file" id="hero_image" name="hero_image" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p class="text-xs text-slate-400 mt-2">Ditampilkan sebagai latar banner utama beranda dengan animasi zoom perlahan. Format JPG, PNG, atau WEBP, maksimal 5 MB.</p>
                @error('hero_image')
                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                @enderror
            </div>

            <div class="border-t border-slate-100 pt-6">
                <h2 class="text-sm font-bold text-slate-800 mb-4">Ajakan Pendaftaran (Call To Action)</h2>
                <p class="text-xs text-slate-400 mb-4">Teks pada kotak ajakan di bagian bawah beranda. Kosongkan untuk memakai teks bawaan.</p>

                <div class="space-y-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Judul Ajakan</label>
                        <input type="text" name="cta_judul" value="{{ old('cta_judul', $settings['cta_judul'] ?? '') }}" placeholder="Siap memulai perjalanan belajarmu?" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Deskripsi Ajakan</label>
                        <textarea name="cta_deskripsi" rows="2" placeholder="Kenali sekolah kami dan dapatkan informasi pendaftaran peserta didik baru." class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">{{ old('cta_deskripsi', $settings['cta_deskripsi'] ?? '') }}</textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Teks Tombol</label>
                            <input type="text" name="cta_teks_tombol" value="{{ old('cta_teks_tombol', $settings['cta_teks_tombol'] ?? '') }}" placeholder="Informasi PPDB" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Tautan Tombol</label>
                            <input type="text" name="cta_link" value="{{ old('cta_link', $settings['cta_link'] ?? '') }}" placeholder="/ppdb atau https://..." class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                        </div>
                    </div>
                    <p class="text-xs text-slate-400">Kosongkan tautan untuk memakai halaman Pendaftaran PPDB bawaan.</p>
                </div>
            </div>

            <div class="flex justify-end pt-4">
                <button type="submit" class="px-6 py-3 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">
                    Simpan Pengaturan
                </button>
            </div>
        </form>
    </div>
</div>
@endsection