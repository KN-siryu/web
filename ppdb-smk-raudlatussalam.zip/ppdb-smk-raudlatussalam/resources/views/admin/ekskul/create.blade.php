@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
@endphp

@section('title', 'Tambah Ekskul')
@section('header_title', 'Tambah Ekstrakurikuler Baru')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="{{ route($prefix.'ekskul.store') }}" method="POST" class="space-y-6">
            @csrf
            
            @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
                </ul>
            </div>
            @endif

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Ekskul *</label>
                <input type="text" name="nama" value="{{ old('nama') }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: Futsal">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Pembina (Opsional)</label>
                <input type="text" name="pembina" value="{{ old('pembina') }}" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Icon (Emoji) *</label>
                    <input type="text" name="icon" value="{{ old('icon', '🏆') }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: ⚽">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Warna Tema *</label>
                    <select name="warna" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                        <option value="emerald" {{ old('warna') == 'emerald' ? 'selected' : '' }}>Emerald (Hijau)</option>
                        <option value="blue" {{ old('warna') == 'blue' ? 'selected' : '' }}>Blue (Biru)</option>
                        <option value="orange" {{ old('warna') == 'orange' ? 'selected' : '' }}>Orange (Jingga)</option>
                        <option value="red" {{ old('warna') == 'red' ? 'selected' : '' }}>Red (Merah)</option>
                        <option value="purple" {{ old('warna') == 'purple' ? 'selected' : '' }}>Purple (Ungu)</option>
                        <option value="yellow" {{ old('warna') == 'yellow' ? 'selected' : '' }}>Yellow (Kuning)</option>
                        <option value="cyan" {{ old('warna') == 'cyan' ? 'selected' : '' }}>Cyan (Cyan)</option>
                        <option value="slate" {{ old('warna') == 'slate' ? 'selected' : '' }}>Slate (Abu)</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Deskripsi (Opsional)</label>
                <textarea name="deskripsi" rows="4" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none" placeholder="Deskripsi singkat ekskul">{{ old('deskripsi') }}</textarea>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="{{ route($prefix.'ekskul.index') }}" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Simpan Ekskul</button>
            </div>
        </form>
    </div>
</div>
@endsection