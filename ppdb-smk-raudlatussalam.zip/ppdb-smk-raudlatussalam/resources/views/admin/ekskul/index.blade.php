@extends('layouts.admin')

@php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'ekskul');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'ekskul');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'ekskul');
@endphp

@section('title', 'Kelola Ekskul')
@section('header_title', 'Kelola Ekstrakurikuler')

@section('content')
<div class="space-y-6">
    @if(session('success'))
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl">{{ session('success') }}</div>
    @endif

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari ekskul..." value="{{ request('search') }}" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            @if($canCreate)
            <a href="{{ route($prefix.'ekskul.create') }}" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Ekskul
            </a>
            @endif
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama Ekskul</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Pembina</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Warna</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    @forelse($ekskuls as $ekskul)
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl flex items-center justify-center text-xl 
                                    {{ $ekskul->warna == 'emerald' ? 'bg-emerald-50' : '' }}
                                    {{ $ekskul->warna == 'blue' ? 'bg-blue-50' : '' }}
                                    {{ $ekskul->warna == 'orange' ? 'bg-orange-50' : '' }}
                                    {{ $ekskul->warna == 'red' ? 'bg-red-50' : '' }}
                                    {{ $ekskul->warna == 'purple' ? 'bg-purple-50' : '' }}
                                    {{ $ekskul->warna == 'yellow' ? 'bg-yellow-50' : '' }}
                                    {{ $ekskul->warna == 'cyan' ? 'bg-cyan-50' : '' }}
                                    {{ $ekskul->warna == 'slate' ? 'bg-slate-100' : '' }}
                                ">{{ $ekskul->icon }}</div>
                                <p class="text-sm font-medium text-slate-900">{{ $ekskul->nama }}</p>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600">{{ $ekskul->pembina ?? '-' }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg capitalize bg-slate-100 text-slate-600">{{ $ekskul->warna }}</span>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            @if($canEdit)
                            <a href="{{ route($prefix.'ekskul.edit', $ekskul) }}" class="text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            @endif
                            @if($canDelete)
                            <form action="{{ route($prefix.'ekskul.destroy', $ekskul) }}" method="POST" class="inline-block" onsubmit="return confirm('Hapus data ekskul ini?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada data ekskul.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100">{{ $ekskuls->links() }}</div>
    </div>
</div>
@endsection