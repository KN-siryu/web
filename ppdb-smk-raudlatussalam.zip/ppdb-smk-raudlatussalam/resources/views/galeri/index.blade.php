@extends('layouts.public')

@section('title', 'Galeri Foto')

@section('content')
<!-- Page Header -->
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h1 class="reveal text-4xl font-extrabold">Galeri Foto</h1>
        <p class="reveal text-emerald-100 mt-2" style="--reveal-delay: 120ms">Dokumentasi kegiatan SMK Raudlatussalam</p>
    </div>
</section>

<!-- Content -->
<section class="py-16">
    <div class="max-w-7xl mx-auto px-4">
        
        <!-- Filter Kategori -->
        <div class="reveal flex flex-wrap gap-2 mb-10 justify-center">
            <a href="{{ route('galeri.index') }}" class="px-4 py-2 text-sm font-medium rounded-lg transition-colors {{ !$kategori ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50' }}">Semua</a>
            @foreach($kategoris as $kat)
            <a href="{{ route('galeri.index', ['kategori' => $kat]) }}" class="px-4 py-2 text-sm font-medium rounded-lg transition-colors {{ $kategori == $kat ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50' }}">{{ $kat }}</a>
            @endforeach
        </div>

        <!-- Grid Galeri -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            @forelse($galeris as $galeri)
            <div class="reveal group relative overflow-hidden rounded-2xl shadow-sm border border-slate-100 cursor-pointer transition duration-300 hover:-translate-y-1 hover:shadow-xl" 
                 style="--reveal-delay: {{ $loop->index * 70 }}ms"
                 x-data="{ open: false }" 
                 @click="open = true">
                
                <!-- Foto -->
                <div class="aspect-square overflow-hidden">
                    <img src="{{ $galeri->foto_url }}" alt="{{ $galeri->judul }}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                </div>
                
                <!-- Overlay -->
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                    <div>
                        <span class="inline-block px-2 py-0.5 bg-emerald-600 text-white text-xs font-semibold rounded mb-2">{{ $galeri->kategori }}</span>
                        <h3 class="text-white font-bold text-sm">{{ $galeri->judul }}</h3>
                    </div>
                </div>

                <!-- Lightbox Modal -->
                <div x-show="open" x-cloak @click="open = false" @keydown.escape.window="open = false" class="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4">
                    <div class="max-w-4xl w-full" @click.stop>
                        <div class="relative">
                            <button @click="open = false" class="absolute -top-10 right-0 text-white hover:text-emerald-400">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                            <img src="{{ $galeri->foto_url }}" alt="{{ $galeri->judul }}" class="w-full max-h-[70vh] object-contain rounded-lg">
                            <div class="bg-white p-6 rounded-b-lg">
                                <span class="inline-block px-2 py-1 bg-emerald-50 text-emerald-600 text-xs font-semibold rounded mb-2">{{ $galeri->kategori }}</span>
                                <h3 class="text-xl font-bold text-slate-900 mb-2">{{ $galeri->judul }}</h3>
                                <p class="text-slate-600 text-sm">{{ $galeri->deskripsi }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="col-span-full text-center py-16">
                <svg class="w-16 h-16 text-slate-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                <p class="text-slate-500">Belum ada foto tersedia.</p>
            </div>
            @endforelse
        </div>

        <!-- Pagination -->
        @if($galeris->hasPages())
        <div class="mt-10">
            {{ $galeris->links() }}
        </div>
        @endif
    </div>
</section>
@endsection