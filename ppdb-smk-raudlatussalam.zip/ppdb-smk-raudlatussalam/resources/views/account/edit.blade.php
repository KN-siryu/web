@extends('layouts.admin')

@section('title', 'Pengaturan Akun')
@section('header_title', 'Ubah Profil Akun Saya')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="{{ route('account.update') }}" method="POST" class="space-y-6">
            @csrf
            @method('PUT')

            @if(session('success'))
                <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl">{{ session('success') }}</div>
            @endif

            @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
                </ul>
            </div>
            @endif

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Lengkap *</label>
                <input type="text" name="name" value="{{ old('name', $user->name) }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Email *</label>
                <input type="email" name="email" value="{{ old('email', $user->email) }}" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Password Saat Ini *</label>
                <input type="password" name="current_password" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Masukkan password saat ini untuk konfirmasi">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Password Baru (kosongkan jika tidak diubah)</label>
                <input type="password" name="password" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Minimal 8 karakter jika diubah">
                <p class="text-[11px] text-slate-400 mt-1">Biarkan kosong jika tidak ingin mengubah password</p>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Konfirmasi Password Baru</label>
                <input type="password" name="password_confirmation" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Masukkan ulang password baru">
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="{{ route('home') }}" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>
@endsection
