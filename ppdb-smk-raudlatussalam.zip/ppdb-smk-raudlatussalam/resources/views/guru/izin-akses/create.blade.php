@extends('layouts.admin')

@section('title', 'Izin Akses - Dashboard Guru')
@section('header_title', 'Izin Akses')

@section('content')
<div class="max-w-3xl mx-auto" x-data="izinForm()">
    @if(session('success'))
        <div class="mb-6 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 shadow-sm animate-[slideIn_.4s_ease-out]">
            <svg class="mt-0.5 h-5 w-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <span>{{ session('success') }}</span>
        </div>
    @endif

    @if($errors->any())
        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 shadow-sm animate-[shake_.4s_ease-in]">
            <p class="mb-1 font-semibold">Periksa kembali isian Anda:</p>
            <ul class="list-inside list-disc space-y-1">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm transition-shadow hover:shadow-md">
        <div class="relative overflow-hidden bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-600 px-6 py-7 sm:px-8">
            <div class="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl"></div>
            <div class="pointer-events-none absolute -bottom-12 left-6 h-32 w-32 rounded-full bg-emerald-300/20 blur-2xl"></div>
            <h3 class="relative flex items-center gap-3 text-lg font-bold text-white sm:text-xl">
                <span class="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/30 transition-transform duration-300 hover:scale-105">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h7z"></path>
                    </svg>
                </span>
                Ajukan Izin Akses
            </h3>
            <p class="relative mt-2 max-w-xl text-sm text-emerald-50">
                Ajukan permintaan izin akses ke admin untuk menambah, mengedit, atau menghapus data pada modul tertentu
                lengkap dengan <span class="font-semibold text-white">batas waktu</span> mulai dan berakhir.
            </p>
        </div>

        <form method="POST" action="{{ route('guru.izin-akses.store') }}" class="space-y-6 p-6 sm:p-8">
            @csrf

            <div>
                <label class="mb-2 block text-sm font-medium text-slate-700">Modul *</label>
                <select name="module" id="module" class="w-full appearance-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500">
                    @foreach($modules as $key => $label)
                        <option value="{{ $key }}" @selected(old('module', $selectedModule) === $key)>{{ $label }}</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="mb-2 block text-sm font-medium text-slate-700">Tipe Akses *</label>
                <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
                    @foreach($actionTypes as $key => $label)
                        <label class="group relative flex cursor-pointer flex-col items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-3 text-center transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-300 hover:bg-emerald-50/50 has-[:checked]:border-emerald-500 has-[:checked]:bg-emerald-50 has-[:checked]:shadow-sm">
                            <input type="radio" name="action_type" value="{{ $key }}" class="sr-only" @checked(old('action_type') === $key)>
                            <span class="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-emerald-600 ring-1 ring-slate-200 transition-transform duration-200 group-hover:scale-110">
                                @if($key === 'create')
                                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                                @elseif($key === 'edit')
                                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                @elseif($key === 'delete')
                                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                @else
                                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                @endif
                            </span>
                            <span class="text-xs font-semibold text-slate-700">{{ $label }}</span>
                        </label>
                    @endforeach
                </div>
            </div>

            <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div>
                    <label for="start_at" class="mb-2 block text-sm font-medium text-slate-700">Mulai Berlaku *</label>
                    <input type="datetime-local" name="start_at" id="start_at" x-model="startAt" @change="syncEndMin()"
                           value="{{ old('start_at', now()->format('Y-m-d\TH:i')) }}"
                           class="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500">
                    <p class="mt-1 text-xs text-slate-500">Waktu izin mulai berlaku.</p>
                </div>
                <div>
                    <label for="end_at" class="mb-2 block text-sm font-medium text-slate-700">Berakhir *</label>
                    <input type="datetime-local" name="end_at" id="end_at" x-model="endAt" :min="endMin"
                           value="{{ old('end_at', now()->addDays(7)->format('Y-m-d\TH:i')) }}"
                           class="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500">
                    <p class="mt-1 text-xs text-slate-500">Waktu izin berakhir.</p>
                </div>
            </div>

            <div>
                <label for="reason" class="mb-2 block text-sm font-medium text-slate-700">Alasan *</label>
                <textarea name="reason" id="reason" rows="4" x-model="reason" maxlength="500"
                          class="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                          placeholder="Jelaskan mengapa Anda perlu akses untuk melakukan perubahan data pada modul ini..."></textarea>
                <div class="mt-1 flex items-center justify-between text-xs text-slate-500">
                    <span>Minimal 10 karakter.</span>
                    <span x-text="reason.length + ' / 500'"></span>
                </div>
            </div>

            {{-- Live summary preview --}}
            <div class="rounded-2xl border border-emerald-100 bg-gradient-to-br from-emerald-50 to-teal-50 p-4 transition-all sm:p-5"
                 x-show="summary.valid" x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 translate-y-2" x-transition:enter-end="opacity-100 translate-y-0">
                <p class="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Ringkasan Pengajuan
                </p>
                <div class="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                    <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                        <p class="text-[11px] uppercase text-slate-500">Modul</p>
                        <p class="mt-0.5 font-semibold capitalize text-slate-800" x-text="summary.module"></p>
                    </div>
                    <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                        <p class="text-[11px] uppercase text-slate-500">Tipe</p>
                        <p class="mt-0.5 font-semibold text-slate-800" x-text="summary.action"></p>
                    </div>
                    <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                        <p class="text-[11px] uppercase text-slate-500">Mulai</p>
                        <p class="mt-0.5 font-semibold text-slate-800" x-text="summary.start"></p>
                    </div>
                    <div class="rounded-xl bg-white/70 p-3 ring-1 ring-emerald-100">
                        <p class="text-[11px] uppercase text-slate-500">Berakhir</p>
                        <p class="mt-0.5 font-semibold text-slate-800" x-text="summary.end"></p>
                    </div>
                </div>
                <p class="mt-3 flex items-center gap-2 text-xs text-emerald-700">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Durasi: <span class="font-semibold" x-text="summary.duration"></span>
                </p>
            </div>

            @if($existingRequests->count() > 0)
                <div class="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
                    <p class="mb-2 font-semibold">Permintaan yang masih menunggu:</p>
                    <ul class="list-inside list-disc space-y-1">
                        @foreach($existingRequests as $req)
                            <li>{{ $req->module }} ({{ $req->action_type }}) — {{ $req->windowLabel() }}</li>
                        @endforeach
                    </ul>
                    <p class="mt-2 text-xs text-amber-600">Anda tidak dapat mengajukan permintaan baru untuk modul yang masih menunggu persetujuan.</p>
                </div>
            @else
                <button type="submit"
                        class="group relative w-full overflow-hidden rounded-xl bg-emerald-600 px-6 py-3.5 font-semibold text-white shadow-lg shadow-emerald-200 transition-all duration-200 hover:-translate-y-0.5 hover:bg-emerald-700 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2">
                    <span class="relative flex items-center justify-center gap-2">
                        <svg class="h-5 w-5 transition-transform duration-300 group-hover:-rotate-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h7z"></path>
                        </svg>
                        Ajukan Permintaan Izin
                    </span>
                </button>
            @endif
        </form>
    </div>
</div>

@push('scripts')
<script>
    function izinForm() {
        return {
            startAt: document.getElementById('start_at')?.value ?? '',
            endAt: document.getElementById('end_at')?.value ?? '',
            endMin: '',
            reason: document.getElementById('reason')?.value ?? '',
            summary: { valid: false, module: '', action: '', start: '', end: '', duration: '' },

            syncEndMin() {
                this.endMin = this.startAt;
                if (this.endAt && this.startAt && new Date(this.endAt) < new Date(this.startAt)) {
                    this.endAt = this.startAt;
                }
            },

            fmt(value) {
                if (! value) {
                    return '-';
                }
                const d = new Date(value);
                if (isNaN(d)) {
                    return '-';
                }
                return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
            },

            humanDuration(start, end) {
                if (! start || ! end) {
                    return '-';
                }
                const ms = new Date(end) - new Date(start);
                if (isNaN(ms) || ms <= 0) {
                    return '-';
                }
                const minutes = Math.floor(ms / 60000);
                const days = Math.floor(minutes / 1440);
                const hours = Math.floor((minutes % 1440) / 60);
                const mins = minutes % 60;
                const parts = [];
                if (days) { parts.push(days + ' hari'); }
                if (hours) { parts.push(hours + ' jam'); }
                if (mins && ! days) { parts.push(mins + ' menit'); }
                return parts.join(' ') || '< 1 menit';
            },

            update() {
                const startEl = document.getElementById('start_at');
                const endEl = document.getElementById('end_at');
                const moduleEl = document.getElementById('module');
                const actionEl = document.querySelector('input[name="action_type"]:checked');

                this.startAt = startEl?.value ?? '';
                this.endAt = endEl?.value ?? '';

                const moduleLabels = @json($modules ?? []);
                const actionLabels = @json($actionTypes ?? []);

                this.summary = {
                    valid: Boolean(this.startAt && this.endAt),
                    module: moduleLabels[moduleEl?.value] ?? '-',
                    action: actionLabels[actionEl?.value] ?? '-',
                    start: this.fmt(this.startAt),
                    end: this.fmt(this.endAt),
                    duration: this.humanDuration(this.startAt, this.endAt),
                };
            },

            init() {
                this.syncEndMin();
                this.update();
                ['start_at', 'end_at', 'module'].forEach((id) => {
                    const el = document.getElementById(id);
                    if (el) {
                        el.addEventListener('change', () => { this.syncEndMin(); this.update(); });
                        el.addEventListener('input', () => { this.syncEndMin(); this.update(); });
                    }
                });
                document.querySelectorAll('input[name="action_type"]').forEach((el) => {
                    el.addEventListener('change', () => this.update());
                });
                const reasonEl = document.getElementById('reason');
                if (reasonEl) {
                    reasonEl.addEventListener('input', () => { this.reason = reasonEl.value; });
                }
            },
        };
    }
</script>
@endpush
@endsection