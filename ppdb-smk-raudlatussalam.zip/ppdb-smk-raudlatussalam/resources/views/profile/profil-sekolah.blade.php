@extends('layouts.public')

@section('title', 'Profil Sekolah')

@section('content')
<section class="relative isolate overflow-hidden bg-emerald-950 text-white py-20">
    @if(!empty($siteSettings['hero_image']))
    <img src="{{ asset('storage/'.$siteSettings['hero_image']) }}" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-40" loading="lazy">
    @endif
    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/40"></div>
    <div class="float-slow absolute -left-16 top-10 -z-10 h-64 w-64 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="float-slower absolute right-10 top-20 -z-10 hidden h-40 w-40 rounded-full bg-emerald-300/20 blur-2xl lg:block"></div>
    <div class="mx-auto max-w-7xl px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Tentang Kami</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">{{ $siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam' }}</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms">Budi Pekerti - Ilmu - Amal</p>
    </div>
</section>

<section class="py-16">
    <div class="max-w-6xl mx-auto px-4 grid gap-8 lg:grid-cols-3">
        <div class="reveal lg:col-span-1">
            <div class="sticky top-24 rounded-3xl border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5">
                @php
                    $fotoKepsek = !empty($siteSettings['foto_kepala_sekolah']) ? asset('storage/'.$siteSettings['foto_kepala_sekolah']) : null;
                @endphp
                @if($fotoKepsek)
                <img src="{{ $fotoKepsek }}" alt="Foto {{ $siteSettings['kepala_sekolah'] ?? 'Kepala Sekolah' }}" class="mx-auto h-44 w-44 rounded-2xl object-cover ring-4 ring-emerald-50 shadow-md">
                @else
                <div class="mx-auto flex h-44 w-44 items-center justify-center rounded-2xl bg-emerald-100 text-6xl font-extrabold text-emerald-700 ring-4 ring-emerald-50">
                    {{ mb_substr($siteSettings['kepala_sekolah'] ?? 'K', 0, 1) }}
                </div>
                @endif
                <h2 class="mt-5 text-center text-xl font-extrabold text-slate-900">{{ $siteSettings['kepala_sekolah'] ?? '-' }}</h2>
                <p class="mt-1 text-center text-sm font-semibold text-emerald-700">Kepala Sekolah</p>
                <div class="mt-6 space-y-3 text-sm text-slate-600">
                    <div class="flex items-start gap-3">
                        <span class="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        </span>
                        <span>{{ $siteSettings['alamat'] ?? '-' }}</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        </span>
                        <span>{{ $siteSettings['telepon'] ?? '-' }}</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                        </span>
                        <span>{{ $siteSettings['email'] ?? '-' }}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="reveal-left lg:col-span-2 space-y-6">
            <div class="rounded-3xl border border-slate-100 bg-white p-8 md:p-10 shadow-sm">
                <h2 class="text-2xl font-extrabold text-slate-900 mb-4">Profil Sekolah</h2>
                <p class="text-slate-600 leading-relaxed">Membangun generasi yang berakhlak mulia, cerdas, dan terampil dalam mempersiapkan masa depan yang gemilang.</p>

                <dl class="mt-8 grid gap-4 sm:grid-cols-2">
                    <div class="rounded-2xl bg-gradient-to-br from-emerald-50 to-slate-50 p-5 ring-1 ring-slate-100">
                        <dt class="text-xs uppercase tracking-wider font-bold text-slate-400">Kepala Sekolah</dt>
                        <dd class="mt-2 text-slate-800 font-semibold">{{ $siteSettings['kepala_sekolah'] ?? '-' }}</dd>
                    </div>
                    <div class="rounded-2xl bg-gradient-to-br from-emerald-50 to-slate-50 p-5 ring-1 ring-slate-100">
                        <dt class="text-xs uppercase tracking-wider font-bold text-slate-400">Alamat</dt>
                        <dd class="mt-2 text-slate-800">{{ $siteSettings['alamat'] ?? '-' }}</dd>
                    </div>
                </dl>
            </div>

            <div x-data="{ open: false }" class="reveal-right rounded-3xl border border-slate-100 bg-gradient-to-br from-emerald-700 to-emerald-900 p-8 md:p-10 text-white shadow-lg">
                <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-200">Sambutan</span>
                <h3 class="mt-2 text-2xl font-extrabold">Kepala Sekolah</h3>
                <p class="mt-4 leading-7 text-emerald-50/90 line-clamp-4">{{ $siteSettings['sambutan'] ?? 'Selamat datang di website resmi sekolah kami.' }}</p>
                <button type="button" @click="open = true" class="mt-6 inline-flex items-center gap-2 font-bold text-white hover:gap-3 transition-all">
                    Baca selengkapnya <span aria-hidden="true">→</span>
                </button>

                <div x-show="open" x-cloak @keydown.escape.window="open = false" class="fixed inset-0 z-[100] flex items-center justify-center p-4" style="display: none;">
                    <div class="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" @click="open = false"></div>
                    <div class="relative z-10 w-full max-w-2xl rounded-3xl bg-white/70 p-8 text-slate-800 shadow-2xl backdrop-blur-xl border border-white/40" @click.stop>
                        <div class="flex items-start justify-between gap-4">
                            <div>
                                <span class="text-xs font-bold uppercase tracking-wider text-emerald-600">Sambutan</span>
                                <h3 class="mt-1 text-2xl font-extrabold text-slate-900">Kepala Sekolah</h3>
                            </div>
                            <button type="button" @click="open = false" class="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200" aria-label="Tutup">
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                            </button>
                        </div>
                        <p class="mt-5 leading-7 text-slate-600 whitespace-pre-line">{{ $siteSettings['sambutan'] ?? 'Selamat datang di website resmi sekolah kami.' }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
