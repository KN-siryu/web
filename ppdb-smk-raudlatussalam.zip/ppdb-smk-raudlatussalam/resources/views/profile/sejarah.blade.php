@extends('layouts.public')

@section('title', 'Sejarah Singkat')

@section('content')
<section class="relative isolate overflow-hidden bg-emerald-950 text-white py-20">
    @if(!empty($siteSettings['hero_image']))
    <img src="{{ asset('storage/'.$siteSettings['hero_image']) }}" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-30" loading="lazy">
    @endif
    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/40"></div>
    <div class="float-slow absolute -left-16 top-10 -z-10 h-64 w-64 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="mx-auto max-w-7xl px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Tentang Kami</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">Sejarah Singkat</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms">{{ $siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam' }}</p>
    </div>
</section>

<section class="py-16">
    <div class="mx-auto max-w-5xl px-4">
        <div class="reveal grid gap-8 lg:grid-cols-5 lg:items-start">
            <div class="lg:col-span-2">
                @if(!empty($siteSettings['hero_image']))
                <div class="reveal-zoom overflow-hidden rounded-3xl shadow-xl ring-1 ring-slate-100">
                    <img src="{{ asset('storage/'.$siteSettings['hero_image']) }}" alt="Gedung sekolah" class="aspect-[4/5] w-full object-cover transition duration-700 hover:scale-105">
                </div>
                @endif
            </div>
            <div class="reveal-left space-y-6 lg:col-span-3">
                <article class="rounded-3xl border border-slate-100 bg-white p-8 md:p-10 shadow-sm">
                    <h2 class="text-2xl font-extrabold text-slate-900 mb-4">Perjalanan Sekolah</h2>
                    <p class="text-slate-600 leading-relaxed">{{ ($siteSettings['sejarah'] ?? '') ?: 'SMK Raudlatussalam hadir untuk mendukung pendidikan kejuruan yang memadukan budi pekerti, ilmu, dan amal. Sekolah terus berupaya membekali peserta didik dengan pengetahuan, keterampilan, dan nilai-nilai yang berguna bagi masa depan mereka.' }}</p>
                    <p class="text-slate-600 leading-relaxed mt-4">Informasi mengenai tahun pendirian dan perkembangan sekolah dapat diperoleh melalui <a href="{{ route('kontak.index') }}" class="font-semibold text-emerald-700 hover:text-emerald-800">halaman kontak</a>.</p>
                </article>

                <div class="grid gap-4 sm:grid-cols-3">
                    <div class="rounded-2xl bg-gradient-to-br from-emerald-50 to-white p-5 ring-1 ring-slate-100">
                        <p class="text-3xl font-extrabold text-emerald-800">Budi</p>
                        <p class="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Pekerti</p>
                    </div>
                    <div class="rounded-2xl bg-gradient-to-br from-emerald-50 to-white p-5 ring-1 ring-slate-100">
                        <p class="text-3xl font-extrabold text-emerald-800">Ilmu</p>
                        <p class="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Pengetahuan</p>
                    </div>
                    <div class="rounded-2xl bg-gradient-to-br from-emerald-50 to-white p-5 ring-1 ring-slate-100">
                        <p class="text-3xl font-extrabold text-emerald-800">Amal</p>
                        <p class="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Karya Nyata</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
