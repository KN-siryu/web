@extends('layouts.public')

@section('title', $kategori ? $kategori : 'Berita & Artikel')

@section('content')
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Informasi Terkini</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">Berita & Artikel</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms">Informasi dan kegiatan {{ $siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam' }}</p>
    </div>
</section>

<section class="py-16 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4">
        <nav class="reveal flex flex-wrap gap-2 justify-center mb-10" aria-label="Filter kategori berita">
            <a href="{{ route('berita.index') }}" class="px-4 py-2 text-sm font-semibold rounded-lg {{ !$kategori ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50' }}">Semua</a>
            @foreach(['Berita', 'Pengumuman', 'Agenda', 'Prestasi'] as $category)
            <a href="{{ route('berita.index', ['kategori' => $category]) }}" class="px-4 py-2 text-sm font-semibold rounded-lg {{ $kategori === $category ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50' }}">{{ $category }}</a>
            @endforeach
        </nav>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($beritas as $berita)
            <article class="reveal group bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-xl" style="--reveal-delay: {{ $loop->index * 90 }}ms">
                <a href="{{ route('berita.show', $berita) }}" class="block aspect-video bg-emerald-50 overflow-hidden">
                    @if($berita->gambar)
                    <img src="{{ asset('storage/'.$berita->gambar) }}" alt="{{ $berita->judul }}" class="w-full h-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
                    @else
                    <div class="w-full h-full flex items-center justify-center text-emerald-700 font-semibold">Berita {{ $berita->kategori }}</div>
                    @endif
                </a>
                <div class="p-6">
                    <div class="flex gap-2 text-xs text-slate-500 mb-3">
                        <span class="font-semibold text-emerald-700">{{ $berita->kategori }}</span>
                        <span aria-hidden="true">·</span>
                        <time datetime="{{ $berita->created_at->toDateString() }}">{{ $berita->created_at->format('d M Y') }}</time>
                    </div>
                    <h2 class="text-lg font-bold text-slate-900">
                        <a href="{{ route('berita.show', $berita) }}" class="hover:text-emerald-700">{{ $berita->judul }}</a>
                    </h2>
                    <p class="text-sm text-slate-600 mt-3">{{ \Illuminate\Support\Str::limit(strip_tags($berita->konten), 150) }}</p>
                    <a href="{{ route('berita.show', $berita) }}" class="inline-block text-sm font-semibold text-emerald-700 mt-4">Baca selengkapnya</a>
                </div>
            </article>
            @empty
            <p class="sm:col-span-2 lg:col-span-3 text-center text-slate-500 py-16">Belum ada berita untuk kategori ini.</p>
            @endforelse
        </div>

        @if($beritas->hasPages())
        <div class="mt-10">{{ $beritas->withQueryString()->links() }}</div>
        @endif
    </div>
</section>
@endsection
