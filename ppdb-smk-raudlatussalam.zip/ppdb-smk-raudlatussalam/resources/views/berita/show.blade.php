@extends('layouts.public')

@section('title', $berita->judul)

@section('content')
<section class="bg-emerald-700 text-white py-12">
    <div class="max-w-5xl mx-auto px-4">
        <a href="{{ route('berita.index') }}" class="reveal text-sm text-emerald-100 hover:text-white">← Kembali ke berita</a>
        <p class="reveal text-emerald-100 font-semibold mt-6" style="--reveal-delay: 100ms">{{ $berita->kategori }}</p>
        <h1 class="reveal text-3xl md:text-4xl font-extrabold mt-2" style="--reveal-delay: 180ms">{{ $berita->judul }}</h1>
        <p class="reveal text-sm text-emerald-100 mt-4" style="--reveal-delay: 260ms">Oleh {{ $berita->penulis }} · {{ $berita->created_at->format('d M Y') }}</p>
    </div>
</section>

<section class="py-12">
    <div class="max-w-5xl mx-auto px-4 grid lg:grid-cols-3 gap-10">
        <article class="reveal lg:col-span-2">
            @if($berita->gambar)
            <div class="reveal-zoom mb-8 overflow-hidden rounded-2xl">
                <img src="{{ asset('storage/'.$berita->gambar) }}" alt="{{ $berita->judul }}" class="w-full max-h-[28rem] object-cover transition duration-700 hover:scale-105">
            </div>
            @endif
            <div class="text-slate-700 leading-8 whitespace-pre-line">{{ $berita->konten }}</div>
        </article>

        <aside class="reveal-right">
            <h2 class="text-lg font-bold text-slate-900 mb-4">Berita lainnya</h2>
            <div class="space-y-4">
                @forelse($beritaTerbaru as $beritaLain)
                <a href="{{ route('berita.show', $beritaLain) }}" class="block p-4 bg-slate-50 rounded-xl transition hover:-translate-y-0.5 hover:bg-emerald-50 hover:shadow-md">
                    <span class="text-xs font-semibold text-emerald-700">{{ $beritaLain->kategori }}</span>
                    <h3 class="font-semibold text-slate-900 mt-1">{{ $beritaLain->judul }}</h3>
                    <time datetime="{{ $beritaLain->created_at->toDateString() }}" class="text-xs text-slate-500 mt-2 block">{{ $beritaLain->created_at->format('d M Y') }}</time>
                </a>
                @empty
                <p class="text-sm text-slate-500">Belum ada berita lainnya.</p>
                @endforelse
            </div>
        </aside>
    </div>
</section>
@endsection
