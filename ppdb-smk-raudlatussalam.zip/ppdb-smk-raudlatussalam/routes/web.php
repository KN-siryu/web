<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\Admin\BeritaController as AdminBeritaController;
use App\Http\Controllers\Admin\EkskulController as AdminEkskulController;
use App\Http\Controllers\Admin\FasilitasController as AdminFasilitasController;
use App\Http\Controllers\Admin\GaleriController as AdminGaleriController;
use App\Http\Controllers\Admin\PendaftarController as AdminPendaftarController;
use App\Http\Controllers\Admin\PesanController as AdminPesanController;
use App\Http\Controllers\Admin\SettingController as AdminSettingController;
use App\Http\Controllers\Admin\StafController as AdminStafController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\BeritaController;
use App\Http\Controllers\EkskulController;
use App\Http\Controllers\GaleriController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KontakController;
use App\Http\Controllers\PermissionRequestController;
use App\Http\Controllers\PpdbController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\StafController;
use App\Models\Notification;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// === PUBLIC ROUTES (Website Depan) ===
Route::get('/', [HomeController::class, 'index'])->name('home');

// Profile Pages
Route::get('/profil-sekolah', [ProfileController::class, 'profil'])->name('profil.sekolah');
Route::get('/visi-misi', [ProfileController::class, 'visiMisi'])->name('profil.visi-misi');
Route::get('/sejarah', [ProfileController::class, 'sejarah'])->name('profil.sejarah');
Route::get('/fasilitas', [ProfileController::class, 'fasilitas'])->name('profil.fasilitas');

// Berita (Public)
Route::get('/berita', [BeritaController::class, 'index'])->name('berita.index');
Route::get('/berita/{beritum}', [BeritaController::class, 'show'])->name('berita.show');

// Galeri (Public)
Route::get('/galeri', [GaleriController::class, 'index'])->name('galeri.index');

// Staf & Ekskul (Public)
Route::get('/staf-pengajar', [StafController::class, 'index'])->name('staf.index');
Route::get('/ekstrakurikuler', [EkskulController::class, 'index'])->name('ekskul.index');

// Kontak (Public)
Route::get('/kontak', [KontakController::class, 'index'])->name('kontak.index');
Route::post('/kontak', [KontakController::class, 'store'])->name('kontak.store');

// === AUTH ROUTES (Login Admin) ===
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'login'])->name('login.store');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/akun', [AccountController::class, 'edit'])->name('account.edit');
    Route::put('/akun', [AccountController::class, 'update'])->name('account.update');
    Route::post('/notifications/mark-as-read', function () {
        auth()->user()->unreadNotifications->markAsRead();

        return back();
    })->name('notifications.markAsRead');
    Route::post('/notifications/{notification}/mark-as-read', function (Notification $notification) {
        if ($notification->notifiable_id === auth()->id()) {
            $notification->markAsRead();
        }

        return response()->json(['success' => true]);
    })->name('notifications.markAsReadSingle');
});

// PPDB Online
Route::get('/ppdb', [PpdbController::class, 'index'])->name('ppdb.index');
Route::post('/ppdb', [PpdbController::class, 'store'])->name('ppdb.store');
Route::get('/ppdb/success/{kode}', [PpdbController::class, 'success'])->name('ppdb.success');
Route::get('/ppdb/cetak/{kode}', [PpdbController::class, 'cetak'])->name('ppdb.cetak');

// === ADMIN ROUTES (Dashboard Backend) ===
Route::middleware(['auth', 'role:admin,panitia'])->prefix('admin')->group(function () {

    // Dashboard
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');

    // Manajemen Berita
    Route::get('/berita', [AdminBeritaController::class, 'index'])->name('admin.berita.index');
    Route::get('/berita/create', [AdminBeritaController::class, 'create'])->name('admin.berita.create');
    Route::post('/berita', [AdminBeritaController::class, 'store'])->name('admin.berita.store');
    Route::get('/berita/{beritum}/edit', [AdminBeritaController::class, 'edit'])->name('admin.berita.edit');
    Route::put('/berita/{beritum}', [AdminBeritaController::class, 'update'])->name('admin.berita.update');
    Route::delete('/berita/{beritum}', [AdminBeritaController::class, 'destroy'])->name('admin.berita.destroy');

    // Manajemen Galeri
    Route::get('/galeri', [AdminGaleriController::class, 'index'])->name('admin.galeri.index');
    Route::get('/galeri/create', [AdminGaleriController::class, 'create'])->name('admin.galeri.create');
    Route::post('/galeri', [AdminGaleriController::class, 'store'])->name('admin.galeri.store');
    Route::get('/galeri/{galeri}/edit', [AdminGaleriController::class, 'edit'])->name('admin.galeri.edit');
    Route::put('/galeri/{galeri}', [AdminGaleriController::class, 'update'])->name('admin.galeri.update');
    Route::delete('/galeri/{galeri}', [AdminGaleriController::class, 'destroy'])->name('admin.galeri.destroy');

    // manajemen Staf
    Route::get('/staf', [AdminStafController::class, 'index'])->name('admin.staf.index');
    Route::get('/staf/create', [AdminStafController::class, 'create'])->name('admin.staf.create');
    Route::post('/staf', [AdminStafController::class, 'store'])->name('admin.staf.store');
    Route::get('/staf/{staf}/edit', [AdminStafController::class, 'edit'])->name('admin.staf.edit');
    Route::put('/staf/{staf}', [AdminStafController::class, 'update'])->name('admin.staf.update');
    Route::delete('/staf/{staf}', [AdminStafController::class, 'destroy'])->name('admin.staf.destroy');

    // manajemen Ekskul
    Route::get('/ekskul', [AdminEkskulController::class, 'index'])->name('admin.ekskul.index');
    Route::get('/ekskul/create', [AdminEkskulController::class, 'create'])->name('admin.ekskul.create');
    Route::post('/ekskul', [AdminEkskulController::class, 'store'])->name('admin.ekskul.store');
    Route::get('/ekskul/{ekskul}/edit', [AdminEkskulController::class, 'edit'])->name('admin.ekskul.edit');
    Route::put('/ekskul/{ekskul}', [AdminEkskulController::class, 'update'])->name('admin.ekskul.update');
    Route::delete('/ekskul/{ekskul}', [AdminEkskulController::class, 'destroy'])->name('admin.ekskul.destroy');

    // manajemen Fasilitas
    Route::get('/fasilitas', [AdminFasilitasController::class, 'index'])->name('admin.fasilitas.index');
    Route::get('/fasilitas/create', [AdminFasilitasController::class, 'create'])->name('admin.fasilitas.create');
    Route::post('/fasilitas', [AdminFasilitasController::class, 'store'])->name('admin.fasilitas.store');
    Route::get('/fasilitas/{fasilita}/edit', [AdminFasilitasController::class, 'edit'])->name('admin.fasilitas.edit');
    Route::put('/fasilitas/{fasilita}', [AdminFasilitasController::class, 'update'])->name('admin.fasilitas.update');
    Route::delete('/fasilitas/{fasilita}', [AdminFasilitasController::class, 'destroy'])->name('admin.fasilitas.destroy');

    // manajemen Pesan
    Route::get('/pesan', [AdminPesanController::class, 'index'])->name('admin.pesan.index');
    Route::get('/pesan/{pesan}', [AdminPesanController::class, 'show'])->name('admin.pesan.show');
    Route::delete('/pesan/{pesan}', [AdminPesanController::class, 'destroy'])->name('admin.pesan.destroy');

    // manajemen Pendaftar
    Route::get('/pendaftar', [AdminPendaftarController::class, 'index'])->name('admin.pendaftar.index');
    Route::get('/pendaftar/{pendaftar}', [AdminPendaftarController::class, 'show'])->name('admin.pendaftar.show');
    Route::put('/pendaftar/{pendaftar}/status', [AdminPendaftarController::class, 'updateStatus'])->name('admin.pendaftar.status');

    // Manajemen akun guru hanya untuk admin.
    Route::middleware('role:admin')->group(function () {
        Route::get('/users', [UserController::class, 'index'])->name('admin.users.index');
        Route::get('/users/create', [UserController::class, 'create'])->name('admin.users.create');
        Route::post('/users', [UserController::class, 'store'])->name('admin.users.store');
        Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('admin.users.edit');
        Route::put('/users/{user}', [UserController::class, 'update'])->name('admin.users.update');
        Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('admin.users.destroy');
    });

    // manajemen Pengaturan
    Route::get('/pengaturan', [AdminSettingController::class, 'index'])->name('admin.pengaturan.index');
    Route::post('/pengaturan', [AdminSettingController::class, 'update'])->name('admin.pengaturan.update');

    // Manajemen Izin Akses Guru
    Route::get('/izin-akses', [PermissionRequestController::class, 'adminIndex'])->name('admin.izin-akses.index');
    Route::put('/izin-akses/{permissionRequest}/approve', [PermissionRequestController::class, 'adminApprove'])->name('admin.izin-akses.approve');
    Route::put('/izin-akses/{permissionRequest}/reject', [PermissionRequestController::class, 'adminReject'])->name('admin.izin-akses.reject');
    Route::put('/izin-akses/{permissionRequest}/revoke', [PermissionRequestController::class, 'adminRevoke'])->name('admin.izin-akses.revoke');
});

// === GURU ROUTES (Dashboard Guru - Actions Gated by Permission) ===
Route::middleware(['auth', 'role:guru', 'module.permission'])->prefix('guru')->group(function () {
    // Dashboard
    Route::get('/dashboard', [GuruController::class, 'dashboard'])->name('guru.dashboard');

    // Berita
    Route::get('/berita', [AdminBeritaController::class, 'index'])->name('guru.berita.index');
    Route::get('/berita/create', [AdminBeritaController::class, 'create'])->name('guru.berita.create');
    Route::post('/berita', [AdminBeritaController::class, 'store'])->name('guru.berita.store');
    Route::get('/berita/{beritum}', [AdminBeritaController::class, 'show'])->name('guru.berita.show');
    Route::get('/berita/{beritum}/edit', [AdminBeritaController::class, 'edit'])->name('guru.berita.edit');
    Route::put('/berita/{beritum}', [AdminBeritaController::class, 'update'])->name('guru.berita.update');
    Route::delete('/berita/{beritum}', [AdminBeritaController::class, 'destroy'])->name('guru.berita.destroy');

    // Galeri
    Route::get('/galeri', [AdminGaleriController::class, 'index'])->name('guru.galeri.index');
    Route::get('/galeri/create', [AdminGaleriController::class, 'create'])->name('guru.galeri.create');
    Route::post('/galeri', [AdminGaleriController::class, 'store'])->name('guru.galeri.store');
    Route::get('/galeri/{galeri}', [AdminGaleriController::class, 'show'])->name('guru.galeri.show');
    Route::get('/galeri/{galeri}/edit', [AdminGaleriController::class, 'edit'])->name('guru.galeri.edit');
    Route::put('/galeri/{galeri}', [AdminGaleriController::class, 'update'])->name('guru.galeri.update');
    Route::delete('/galeri/{galeri}', [AdminGaleriController::class, 'destroy'])->name('guru.galeri.destroy');

    // Ekstrakurikuler
    Route::get('/ekskul', [AdminEkskulController::class, 'index'])->name('guru.ekskul.index');
    Route::get('/ekskul/create', [AdminEkskulController::class, 'create'])->name('guru.ekskul.create');
    Route::post('/ekskul', [AdminEkskulController::class, 'store'])->name('guru.ekskul.store');
    Route::get('/ekskul/{ekskul}', [AdminEkskulController::class, 'show'])->name('guru.ekskul.show');
    Route::get('/ekskul/{ekskul}/edit', [AdminEkskulController::class, 'edit'])->name('guru.ekskul.edit');
    Route::put('/ekskul/{ekskul}', [AdminEkskulController::class, 'update'])->name('guru.ekskul.update');
    Route::delete('/ekskul/{ekskul}', [AdminEkskulController::class, 'destroy'])->name('guru.ekskul.destroy');

    // Staf Pengajar
    Route::get('/staf', [AdminStafController::class, 'index'])->name('guru.staf.index');
    Route::get('/staf/create', [AdminStafController::class, 'create'])->name('guru.staf.create');
    Route::post('/staf', [AdminStafController::class, 'store'])->name('guru.staf.store');
    Route::get('/staf/{staf}', [AdminStafController::class, 'show'])->name('guru.staf.show');
    Route::get('/staf/{staf}/edit', [AdminStafController::class, 'edit'])->name('guru.staf.edit');
    Route::put('/staf/{staf}', [AdminStafController::class, 'update'])->name('guru.staf.update');
    Route::delete('/staf/{staf}', [AdminStafController::class, 'destroy'])->name('guru.staf.destroy');

    // Fasilitas
    Route::get('/fasilitas', [AdminFasilitasController::class, 'index'])->name('guru.fasilitas.index');
    Route::get('/fasilitas/create', [AdminFasilitasController::class, 'create'])->name('guru.fasilitas.create');
    Route::post('/fasilitas', [AdminFasilitasController::class, 'store'])->name('guru.fasilitas.store');
    Route::get('/fasilitas/{fasilita}', [AdminFasilitasController::class, 'show'])->name('guru.fasilitas.show');
    Route::get('/fasilitas/{fasilita}/edit', [AdminFasilitasController::class, 'edit'])->name('guru.fasilitas.edit');
    Route::put('/fasilitas/{fasilita}', [AdminFasilitasController::class, 'update'])->name('guru.fasilitas.update');
    Route::delete('/fasilitas/{fasilita}', [AdminFasilitasController::class, 'destroy'])->name('guru.fasilitas.destroy');

    // Pendaftar PPDB
    Route::get('/pendaftar', [AdminPendaftarController::class, 'index'])->name('guru.pendaftar.index');
    Route::get('/pendaftar/{pendaftar}', [AdminPendaftarController::class, 'show'])->name('guru.pendaftar.show');
    Route::put('/pendaftar/{pendaftar}/status', [AdminPendaftarController::class, 'updateStatus'])->name('guru.pendaftar.status');

    // Pesan Masuk
    Route::get('/pesan', [AdminPesanController::class, 'index'])->name('guru.pesan.index');
    Route::get('/pesan/{pesan}', [AdminPesanController::class, 'show'])->name('guru.pesan.show');
    Route::delete('/pesan/{pesan}', [AdminPesanController::class, 'destroy'])->name('guru.pesan.destroy');

    // Izin Akses (Request permission from admin)
    Route::get('/izin-akses', [PermissionRequestController::class, 'create'])->name('guru.izin-akses.create');
    Route::post('/izin-akses', [PermissionRequestController::class, 'store'])->name('guru.izin-akses.store');
    Route::get('/izin-akses/{permissionRequest}', [PermissionRequestController::class, 'show'])->name('guru.izin-akses.show');
});
