<?php

namespace Database\Seeders;

use App\Models\Berita;
use Illuminate\Database\Seeder;

class BeritaSeeder extends Seeder
{
    public function run(): void
    {
        $beritas = [
            [
                'judul' => 'Istighosah Bersama Warga Sekolah',
                'konten' => 'Kegiatan istighosah dilaksanakan secara rutin setiap bulan untuk mempererat ukhuwah islamiyah antar warga sekolah. Kegiatan ini dihadiri oleh seluruh siswa, guru, dan staf tenaga kependidikan. Acara dimulai pukul 07.00 WIB di Masjid Sekolah dengan pembacaan ayat-ayat suci Al-Quran, dzikir, dan doa bersama.',
                'penulis' => 'Humas SMK Raudlatussalam',
                'kategori' => 'Berita',
            ],
            [
                'judul' => 'Peringatan Harlah SMK Raudlatussalam ke-16',
                'konten' => 'SMK Raudlatussalam merayakan Hari Lahir ke-16 dengan rangkaian acara yang meriah. Kegiatan meliputi lomba-lomba antar kelas, pameran karya siswa, dan pentas seni. Acara puncak dihadiri oleh tokoh masyarakat dan alumni sekolah.',
                'penulis' => 'OSIS SMK Raudlatussalam',
                'kategori' => 'Agenda',
            ],
            [
                'judul' => 'Siswa Raih Juara Kompetisi Keahlian LKS',
                'konten' => 'Mengharumkan nama sekolah, siswa SMK Raudlatussalam berhasil meraih Juara 1 dalam Lomba Kompetensi Siswa (LKS) tingkat Kabupaten Banyuwangi tahun ini. Prestasi ini dicapai dalam bidang Teknologi Informasi dan Komunikasi (TIK).',
                'penulis' => 'Bidang Kurikulum',
                'kategori' => 'Prestasi',
            ],
            [
                'judul' => 'Pendaftaran PPDB Tahun Ajaran 2025/2026 Dibuka',
                'konten' => 'Diberitahukan kepada seluruh calon peserta didik baru bahwa Penerimaan Peserta Didik Baru (PPDB) SMK Raudlatussalam tahun ajaran 2025/2026 telah resmi dibuka. Pendaftaran dapat dilakukan secara online melalui website resmi sekolah. Pastikan data yang diisi benar dan lengkap.',
                'penulis' => 'Panitia PPDB',
                'kategori' => 'Pengumuman',
            ],
            [
                'judul' => 'Kunjungan Industri ke Perusahaan Banyuwangi',
                'konten' => 'Sebagai bagian dari kurikulum SMK, siswa kelas XII melakukan kunjungan industri ke beberapa perusahaan di Banyuwangi. Kegiatan ini bertujuan untuk memperkenalkan dunia kerja secara langsung kepada siswa sebelum mereka melaksanakan Praktik Kerja Lapangan (PKL).',
                'penulis' => 'Bidang Humas',
                'kategori' => 'Berita',
            ],
            [
                'judul' => 'Workshop Kewirausahaan untuk Siswa Kelas XII',
                'konten' => 'SMK Raudlatussalam mengadakan workshop kewirausahaan bagi siswa kelas XII. Workshop ini menghadirkan praktisi wirausaha muda sukses asal Banyuwangi sebagai narasumber. Tujuannya untuk menumbuhkan jiwa wirausaha siswa sebelum lulus.',
                'penulis' => 'Bidang Kesiswaan',
                'kategori' => 'Agenda',
            ],
        ];

        foreach ($beritas as $berita) {
            Berita::create($berita);
        }
    }
}
