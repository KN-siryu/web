<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AdminSeeder::class,
            BeritaSeeder::class,
            GaleriSeeder::class,
            StafSeeder::class,
            EkskulSeeder::class,
            FasilitasSeeder::class,
            SettingSeeder::class,
        ]);
    }
}
