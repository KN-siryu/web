<?php

namespace Database\Seeders;

use App\Models\Ekskul;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class EkskulSeeder extends Seeder
{
    public function run(): void
    {
        // Kosongkan tabel dulu agar tidak duplicate
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        Ekskul::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        $ekskuls = [
            [
                'nama' => 'Basket Ball',
                'deskripsi' => 'Ekstrakurikuler bola basket untuk mengasah kemampuan fisik dan kerjasama tim siswa.',
                'pembina' => 'Ahmad Fauzi, S.Kom.',
                'icon' => '🏀',
                'warna' => 'orange',
            ],
            [
                'nama' => 'Volly Ball',
                'deskripsi' => 'Ekstrakurikuler bola voli yang melatih kekompakan dan strategi permainan.',
                'pembina' => 'Drs. Abdul Rohman',
                'icon' => '🏐',
                'warna' => 'blue',
            ],
            [
                'nama' => 'Futsal',
                'deskripsi' => 'Ekstrakurikuler futsal untuk para pecinta sepak bola mini.',
                'pembina' => 'Muhammad Ridwan, S.Pd.',
                'icon' => '⚽',
                'warna' => 'emerald',
            ],
            [
                'nama' => 'Paskibra',
                'deskripsi' => 'Pasukan Pengibar Bendera untuk melatih kedisiplinan dan jiwa nasionalisme.',
                'pembina' => 'Siti Aminah, S.Pd.',
                'icon' => '🚩',
                'warna' => 'red',
            ],
            [
                'nama' => 'Palang Merah Remaja (PMR)',
                'deskripsi' => 'Mengasah jiwa kemanusiaan dan pertolongan pertama pada kecelakaan.',
                'pembina' => 'Nur Hidayah, S.Pd.',
                'icon' => '✚',
                'warna' => 'red',
            ],
            [
                'nama' => 'Computer Fan Club',
                'deskripsi' => 'Ekskul untuk siswa yang tertarik mendalami dunia teknologi dan pemrograman.',
                'pembina' => 'Ahmad Fauzi, S.Kom.',
                'icon' => '💻',
                'warna' => 'purple',
            ],
            [
                'nama' => 'English Club',
                'deskripsi' => 'Meningkatkan kemampuan berbahasa Inggris siswa secara aktif dan interaktif.',
                'pembina' => 'Nur Hidayah, S.Pd.',
                'icon' => '🗣️',
                'warna' => 'blue',
            ],
            [
                'nama' => 'Ikatan Remaja Masjid (IRMASA)',
                'deskripsi' => 'Wadah pembinaan keagamaan dan kegiatan keislaman bagi siswa.',
                'pembina' => 'Muhammad Ridwan, S.Pd.',
                'icon' => '🕌',
                'warna' => 'emerald',
            ],
            [
                'nama' => 'BKC (Barisan Kader Co-Curiculer)',
                'deskripsi' => 'Latihan baris-berbaris dan kepemimpinan ala militer.',
                'pembina' => 'Drs. Abdul Rohman',
                'icon' => '🎖️',
                'warna' => 'slate',
            ],
            [
                'nama' => 'Tenis Meja',
                'deskripsi' => 'Ekstrakurikuler tenis meja untuk mengasah reflek dan konsentrasi.',
                'pembina' => 'Siti Aminah, S.Pd.',
                'icon' => '🏓',
                'warna' => 'yellow',
            ],
            [
                'nama' => 'Renang',
                'deskripsi' => 'Ekstrakurikuler renang untuk melatih kebugaran dan skill berenang siswa.',
                'pembina' => 'Ahmad Fauzi, S.Kom.',
                'icon' => '🏊',
                'warna' => 'cyan',
            ],
        ];

        foreach ($ekskuls as $ekskul) {
            Ekskul::create([
                'nama' => $ekskul['nama'],
                'slug' => Str::slug($ekskul['nama']),
                'deskripsi' => $ekskul['deskripsi'],
                'pembina' => $ekskul['pembina'],
                'icon' => $ekskul['icon'],
                'warna' => $ekskul['warna'],
            ]);
        }
    }
}
