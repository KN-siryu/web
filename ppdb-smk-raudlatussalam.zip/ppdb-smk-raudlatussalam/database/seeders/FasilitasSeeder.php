<?php

namespace Database\Seeders;

use App\Models\Fasilitas;
use Illuminate\Database\Seeder;

class FasilitasSeeder extends Seeder
{
    public function run(): void
    {
        $fasilitas = [
            [
                'nama' => 'Laboratorium Komputer',
                'deskripsi' => 'Ruang praktik yang dilengkapi komputer dan jaringan internet untuk mendukung pembelajaran teknologi informasi.',
                'icon' => '💻',
                'urutan' => 1,
            ],
            [
                'nama' => 'Perpustakaan',
                'deskripsi' => 'Tempat membaca, menelusuri referensi, dan mendukung kegiatan literasi siswa.',
                'icon' => '📚',
                'urutan' => 2,
            ],
            [
                'nama' => 'Ruang Praktik',
                'deskripsi' => 'Ruang belajar yang nyaman untuk kegiatan praktik dan pelatihan keterampilan.',
                'icon' => '🛠️',
                'urutan' => 3,
            ],
            [
                'nama' => 'Lapangan Olahraga',
                'deskripsi' => 'Area berolahraga untuk pembinaan kebugaran jasmani dan kegiatan ekstrakurikuler.',
                'icon' => '🏟️',
                'urutan' => 4,
            ],
        ];

        foreach ($fasilitas as $item) {
            Fasilitas::create($item);
        }
    }
}
