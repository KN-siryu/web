<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            ['key' => 'nama_sekolah', 'value' => 'SMK Raudlatussalam'],
            ['key' => 'telepon', 'value' => '0852-5875-0641'],
            ['key' => 'email', 'value' => 'info@raudlatussalam.sch.id'],
            ['key' => 'alamat', 'value' => 'Jl. Raya Sumbergondo, Glenmore, Banyuwangi, Jawa Timur'],
            ['key' => 'kepala_sekolah', 'value' => 'Misbahul Munir, S.Pd.'],
            ['key' => 'sambutan', 'value' => 'Assalamu\'alaikum Warahmatullahi Wabarakatuh. Puji syukur kita panjatkan kehadirat Allah SWT atas limpahan rahmat dan karunia-Nya sehingga website SMK Raudlatussalam ini dapat hadir sebagai sarana informasi dan komunikasi.'],
            ['key' => 'visi', 'value' => 'Membangun generasi yang berakhlak mulia, cerdas, dan terampil'],
            ['key' => 'misi', 'value' => "Mengembangkan karakter berakhlak mulia\nMeningkatkan kompetensi ilmu dan keterampilan\nMembentuk siswa yang bermanfaat bagi masyarakat"],
            ['key' => 'sejarah', 'value' => 'SMK Raudlatussalam hadir untuk mendukung pendidikan kejuruan yang memadukan budi pekerti, ilmu, dan amal. Sekolah terus berupaya membekali peserta didik dengan pengetahuan, keterampilan, dan nilai-nilai yang berguna bagi masa depan mereka.'],
            ['key' => 'cta_judul', 'value' => 'Siap memulai perjalanan belajarmu?'],
            ['key' => 'cta_deskripsi', 'value' => 'Kenali sekolah kami dan dapatkan informasi pendaftaran peserta didik baru.'],
            ['key' => 'cta_teks_tombol', 'value' => 'Informasi PPDB'],
            ['key' => 'cta_link', 'value' => ''],
        ];

        foreach ($settings as $item) {
            Setting::create($item);
        }
    }
}
