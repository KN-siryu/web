<?php

namespace Database\Seeders;

use App\Models\Staf;
use Illuminate\Database\Seeder;

class StafSeeder extends Seeder
{
    public function run(): void
    {
        $stafs = [
            [
                'nama' => 'Misbahul Munir, S.Pd.',
                'nip' => '197501012005011001',
                'jabatan' => 'Kepala Sekolah',
                'pendidikan' => 'S1 Pendidikan Teknik Informatika',
                'foto' => 'https://ui-avatars.com/api/?name=Misbahul+Munir&background=059669&color=fff&size=400',
                'kategori' => 'Kepala Sekolah',
            ],
            [
                'nama' => 'Ahmad Fauzi, S.Kom.',
                'nip' => '198203152008011002',
                'jabatan' => 'Wakasek Kurikulum',
                'mata_pelajaran' => 'Pemrograman Web',
                'pendidikan' => 'S1 Teknik Informatika',
                'foto' => 'https://ui-avatars.com/api/?name=Ahmad+Fauzi&background=0284c7&color=fff&size=400',
                'kategori' => 'Pengajar',
            ],
            [
                'nama' => 'Siti Aminah, S.Pd.',
                'nip' => '198505202010012003',
                'jabatan' => 'Wakasek Kesiswaan',
                'mata_pelajaran' => 'Matematika',
                'pendidikan' => 'S1 Pendidikan Matematika',
                'foto' => 'https://ui-avatars.com/api/?name=Siti+Aminah&background=db2777&color=fff&size=400',
                'kategori' => 'Pengajar',
            ],
            [
                'nama' => 'Drs. Abdul Rohman',
                'nip' => '196807101995031004',
                'jabatan' => 'Wakasek Sarpras',
                'mata_pelajaran' => 'Bahasa Indonesia',
                'pendidikan' => 'S1 Pendidikan Bahasa',
                'foto' => 'https://ui-avatars.com/api/?name=Abdul+Rohman&background=7c3aed&color=fff&size=400',
                'kategori' => 'Pengajar',
            ],
            [
                'nama' => 'Nur Hidayah, S.Pd.',
                'nip' => '199001252015022005',
                'jabatan' => 'Guru Produktif',
                'mata_pelajaran' => 'Basis Data',
                'pendidikan' => 'S1 Sistem Informasi',
                'foto' => 'https://ui-avatars.com/api/?name=Nur+Hidayah&background=f59e0b&color=fff&size=400',
                'kategori' => 'Pengajar',
            ],
            [
                'nama' => 'Muhammad Ridwan, S.Pd.',
                'nip' => '199207152016031006',
                'jabatan' => 'Guru Normatif',
                'mata_pelajaran' => 'Aqidah Akhlak',
                'pendidikan' => 'S1 Pendidikan Agama Islam',
                'foto' => 'https://ui-avatars.com/api/?name=Muhammad+Ridwan&background=059669&color=fff&size=400',
                'kategori' => 'Pengajar',
            ],
            [
                'nama' => 'Fatimah Zahra',
                'nip' => null,
                'jabatan' => 'Tata Usaha',
                'pendidikan' => 'D3 Administrasi',
                'foto' => 'https://ui-avatars.com/api/?name=Fatimah+Zahra&background=0284c7&color=fff&size=400',
                'kategori' => 'Tenaga Kependidikan',
            ],
            [
                'nama' => 'Budi Santoso',
                'nip' => null,
                'jabatan' => 'Laboran',
                'pendidikan' => 'D3 Teknik Komputer',
                'foto' => 'https://ui-avatars.com/api/?name=Budi+Santoso&background=7c3aed&color=fff&size=400',
                'kategori' => 'Tenaga Kependidikan',
            ],
        ];

        foreach ($stafs as $staf) {
            Staf::create($staf);
        }
    }
}
