<?php

namespace Database\Seeders;

use App\Models\Galeri;
use Illuminate\Database\Seeder;

class GaleriSeeder extends Seeder
{
    public function run(): void
    {
        $galeris = [
            [
                'judul' => 'Istighosah Bulanan',
                'deskripsi' => 'Kegiatan istighosah bersama seluruh warga sekolah di Masjid.',
                'foto' => 'https://images.unsplash.com/photo-1591456983933-0c772d4f4a3f?w=800',
                'kategori' => 'Kegiatan',
            ],
            [
                'judul' => 'Upacara Bendera',
                'deskripsi' => 'Upacara bendera rutin setiap hari Senin.',
                'foto' => 'https://images.unsplash.com/photo-1564419041741-58b69c4f90f9?w=800',
                'kategori' => 'Upacara',
            ],
            [
                'judul' => 'Praktik Komputer',
                'deskripsi' => 'Siswa praktik di Laboratorium Komputer.',
                'foto' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800',
                'kategori' => 'Pembelajaran',
            ],
            [
                'judul' => 'Lomba 17 Agustus',
                'deskripsi' => 'Berbagai lomba menarik dalam rangka HUT RI.',
                'foto' => 'https://images.unsplash.com/photo-1530541930197-ff16ac917b0f?w=800',
                'kategori' => 'Lomba',
            ],
            [
                'judul' => 'Kegiatan OSIS',
                'deskripsi' => 'Rapat koordinasi pengurus OSIS.',
                'foto' => 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800',
                'kategori' => 'Kegiatan',
            ],
            [
                'judul' => 'Wisuda Sekolah',
                'deskripsi' => 'Acara wisuda siswa kelas XII tahun ajaran 2024/2025.',
                'foto' => 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800',
                'kategori' => 'Wisuda',
            ],
            [
                'judul' => 'Kunjungan Industri',
                'deskripsi' => 'Siswa berkunjung ke perusahaan untuk studi tour.',
                'foto' => 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800',
                'kategori' => 'Kunjungan',
            ],
            [
                'judul' => 'Pentas Seni',
                'deskripsi' => 'Penampilan siswa dalam acara pentas seni sekolah.',
                'foto' => 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800',
                'kategori' => 'Seni',
            ],
            [
                'judul' => 'Bakti Sosial',
                'deskripsi' => 'Kegiatan bakti sosial ke masyarakat sekitar.',
                'foto' => 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800',
                'kategori' => 'Sosial',
            ],
        ];

        foreach ($galeris as $galeri) {
            Galeri::create($galeri);
        }
    }
}
