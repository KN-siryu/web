<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pendaftars', function (Blueprint $table) {
            $table->id();
            $table->string('kode_pendaftaran')->unique();
            $table->string('nama_lengkap');
            $table->string('nisn')->nullable();
            $table->string('nik')->nullable();
            $table->string('jenis_kelamin');
            $table->string('tempat_lahir')->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->string('agama')->nullable();
            $table->string('alamat')->nullable();
            $table->string('asal_sekolah')->nullable();

            // Data Ayah
            $table->string('nama_ayah')->nullable();
            $table->string('pekerjaan_ayah')->nullable();
            $table->string('telepon_ayah')->nullable();

            // Data Ibu
            $table->string('nama_ibu')->nullable();
            $table->string('pekerjaan_ibu')->nullable();
            $table->string('telepon_ibu')->nullable();

            // Data Kontak Wali
            $table->string('nama_wali')->nullable();
            $table->string('telepon_wali')->nullable();
            $table->string('email_wali')->nullable();
            $table->text('alamat_wali')->nullable();

            // Jenis & Jalur
            $table->enum('jenis_pendaftaran', ['Baru', 'Pindahan'])->default('Baru');
            $table->enum('jalur_pendaftaran', ['Umum', 'Prestasi'])->default('Umum');

            // Dokumen
            $table->string('path_foto')->nullable();
            $table->string('path_kk')->nullable();
            $table->string('path_akta')->nullable();
            $table->string('path_ijazah')->nullable();

            $table->enum('status', ['Pending', 'Diterima', 'Ditolak'])->default('Pending');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pendaftars');
    }
};
