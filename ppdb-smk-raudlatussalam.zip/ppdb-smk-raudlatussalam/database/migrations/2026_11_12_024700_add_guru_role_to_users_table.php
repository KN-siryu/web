<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['admin', 'panitia', 'guru'])->default('admin')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (DB::table('users')->where('role', 'guru')->exists()) {
            throw new RuntimeException('Hapus seluruh akun guru sebelum mengembalikan daftar role users.');
        }

        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['admin', 'panitia'])->default('admin')->change();
        });
    }
};
