<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stafs', function (Blueprint $table) {
            $table->id();
            $table->string('nama');
            $table->string('nip')->nullable();
            $table->string('jabatan'); // contoh: Kepala Sekolah, Guru, Wakasek
            $table->string('mata_pelajaran')->nullable();
            $table->text('pendidikan')->nullable();
            $table->string('foto')->nullable();
            $table->enum('kategori', ['Pengajar', 'Tenaga Kependidikan', 'Kepala Sekolah'])->default('Pengajar');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stafs');
    }
};
