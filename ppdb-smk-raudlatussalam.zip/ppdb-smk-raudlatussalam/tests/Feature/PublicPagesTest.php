<?php

namespace Tests\Feature;

use App\Models\Berita;
use App\Models\Ekskul;
use App\Models\Galeri;
use App\Models\Staf;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class PublicPagesTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_information_pages_render_successfully(): void
    {
        foreach (['/', '/profil-sekolah', '/visi-misi', '/sejarah', '/fasilitas', '/berita'] as $url) {
            $this->get($url)->assertOk();
        }
    }

    public function test_news_details_render_successfully(): void
    {
        $berita = Berita::create([
            'judul' => 'Berita Sekolah',
            'konten' => 'Isi berita untuk pengujian.',
            'penulis' => 'Admin',
            'kategori' => 'Berita',
        ]);

        $this->get(route('berita.show', $berita))
            ->assertOk()
            ->assertSee('Berita Sekolah')
            ->assertSee('Isi berita untuk pengujian.');
    }

    public function test_uploaded_staff_and_gallery_images_use_public_storage_urls(): void
    {
        Storage::fake('public');

        Galeri::create([
            'judul' => 'Kegiatan Sekolah',
            'foto' => 'galeri/kegiatan.jpg',
            'kategori' => 'Kegiatan',
        ]);
        Staf::create([
            'nama' => 'Guru Sekolah',
            'jabatan' => 'Guru',
            'kategori' => 'Pengajar',
            'foto' => 'staf/guru.jpg',
        ]);

        $this->get(route('galeri.index'))
            ->assertOk()
            ->assertSee(Storage::disk('public')->url('galeri/kegiatan.jpg'), false);

        $this->get(route('staf.index'))
            ->assertOk()
            ->assertSee(Storage::disk('public')->url('staf/guru.jpg'), false);
    }

    public function test_homepage_shows_school_statistics_staff_activities_and_animations(): void
    {
        Staf::create([
            'nama' => 'Kepala Contoh',
            'jabatan' => 'Kepala Sekolah',
            'kategori' => 'Kepala Sekolah',
        ]);
        Ekskul::create([
            'nama' => 'Klub Sains',
            'slug' => 'klub-sains',
            'icon' => '✦',
            'warna' => 'emerald',
        ]);

        $this->get(route('home'))
            ->assertOk()
            ->assertSee('Kepala Contoh')
            ->assertSee('Klub Sains')
            ->assertSee('Foto Kegiatan')
            ->assertSee('IntersectionObserver')
            ->assertSee('prefers-reduced-motion');
    }
}
