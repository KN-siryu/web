<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FasilitasManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_create_and_show_facility_in_public_page(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)
            ->post(route('admin.fasilitas.store'), [
                'nama' => 'Laboratorium Komputer',
                'deskripsi' => 'Ruang komputer untuk pembelajaran praktik.',
                'icon' => '💻',
                'urutan' => 1,
            ])
            ->assertRedirectToRoute('admin.fasilitas.index');

        $this->assertDatabaseHas('fasilitas', [
            'nama' => 'Laboratorium Komputer',
            'icon' => '💻',
        ]);

        $this->get(route('profil.fasilitas'))
            ->assertOk()
            ->assertSee('Laboratorium Komputer')
            ->assertSee('Ruang komputer untuk pembelajaran praktik.');
    }

    public function test_guest_is_redirected_from_facility_management(): void
    {
        $this->get(route('admin.fasilitas.index'))
            ->assertRedirectToRoute('login');
    }
}
