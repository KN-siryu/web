<?php

namespace Tests\Feature;

use App\Models\Pendaftar;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class PpdbRegistrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_applicant_can_submit_registration_and_open_the_printable_form(): void
    {
        Storage::fake('public');

        $this->post(route('ppdb.store'), [
            'jenis_pendaftaran' => 'Baru',
            'jalur_pendaftaran' => 'Umum',
            'nama_lengkap' => 'Calon Siswa',
            'jenis_kelamin' => 'L',
            'nama_wali' => 'Orang Tua',
            'telepon_wali' => '08123456789',
            'email_wali' => 'wali@example.test',
            'alamat_wali' => 'Alamat rumah',
            'foto' => UploadedFile::fake()->image('foto.jpg'),
        ])->assertRedirect();

        $pendaftar = Pendaftar::firstOrFail();

        $this->assertMatchesRegularExpression('/^PPDB-\d{4}-[A-Z0-9]{8}$/', $pendaftar->kode_pendaftaran);
        $this->assertDatabaseHas('pendaftars', [
            'nama_lengkap' => 'Calon Siswa',
            'status' => 'Pending',
        ]);
        Storage::disk('public')->assertExists($pendaftar->path_foto);

        $this->get(route('ppdb.success', $pendaftar->kode_pendaftaran))
            ->assertOk()
            ->assertSee($pendaftar->kode_pendaftaran);

        $this->get(route('ppdb.cetak', $pendaftar->kode_pendaftaran))
            ->assertOk()
            ->assertSee('Calon Siswa');
    }

    public function test_invalid_registration_is_rejected_without_creating_a_record(): void
    {
        $this->from(route('ppdb.index'))
            ->post(route('ppdb.store'), [
                'jenis_pendaftaran' => 'Baru',
                'jalur_pendaftaran' => 'Umum',
                'nama_lengkap' => 'Calon Siswa',
                'jenis_kelamin' => 'L',
                'nama_wali' => 'Orang Tua',
                'telepon_wali' => '08123456789',
                'email_wali' => 'not-an-email',
                'alamat_wali' => 'Alamat rumah',
            ])
            ->assertRedirectToRoute('ppdb.index')
            ->assertSessionHasErrors('email_wali');

        $this->assertDatabaseCount('pendaftars', 0);
    }
}
