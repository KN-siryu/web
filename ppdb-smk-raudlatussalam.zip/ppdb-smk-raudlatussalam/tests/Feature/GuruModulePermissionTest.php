<?php

namespace Tests\Feature;

use App\Models\Berita;
use App\Models\PermissionRequest;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class GuruModulePermissionTest extends TestCase
{
    use RefreshDatabase;

    private function request(array $attributes = []): PermissionRequest
    {
        return PermissionRequest::create(array_merge([
            'user_id' => User::factory()->create(['role' => 'guru'])->id,
            'module' => 'berita',
            'action_type' => 'all',
            'reason' => 'Perlu mengelola data berita.',
            'status' => 'approved',
            'start_at' => now()->subHour(),
            'end_at' => now()->addDays(7),
        ], $attributes));
    }

    public function test_guru_without_approved_request_is_blocked_from_module(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);

        $this->actingAs($guru)
            ->get(route('guru.staf.index'))
            ->assertForbidden();
    }

    public function test_guru_with_approved_request_can_access_module(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);

        $this->request(['user_id' => $guru->id, 'module' => 'staf']);

        $this->actingAs($guru)
            ->get(route('guru.staf.index'))
            ->assertOk();
    }

    public function test_pending_or_rejected_request_does_not_grant_access(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);

        $this->request(['user_id' => $guru->id, 'module' => 'staf', 'status' => 'pending']);

        $this->actingAs($guru)
            ->get(route('guru.staf.index'))
            ->assertForbidden();
    }

    public function test_approved_module_is_listed_for_guru(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request(['user_id' => $guru->id]);

        $this->assertSame(['berita'], $guru->fresh()->approvedModules());
    }

    public function test_create_action_is_allowed_when_approved(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request(['user_id' => $guru->id, 'action_type' => 'create']);

        $this->actingAs($guru)
            ->get(route('guru.berita.create'))
            ->assertOk();
    }

    public function test_edit_action_is_forbidden_when_only_create_approved(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request(['user_id' => $guru->id, 'action_type' => 'create']);

        $berita = Berita::create([
            'judul' => 'Test',
            'slug' => 'test',
            'konten' => 'Konten',
            'kategori' => 'Berita',
            'penulis' => 'Admin',
        ]);

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertOk();

        $this->actingAs($guru)
            ->get(route('guru.berita.edit', $berita))
            ->assertForbidden();
    }

    public function test_all_action_type_grants_edit(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request(['user_id' => $guru->id, 'action_type' => 'all']);

        $this->assertTrue($guru->fresh()->canDo('create', 'berita'));
        $this->assertTrue($guru->fresh()->canDo('edit', 'berita'));
        $this->assertTrue($guru->fresh()->canDo('delete', 'berita'));
    }

    public function test_access_is_blocked_before_window_starts(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request([
            'user_id' => $guru->id,
            'start_at' => now()->addDay(),
            'end_at' => now()->addDays(2),
        ]);

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertForbidden();

        $this->assertSame([], $guru->fresh()->approvedModules());
    }

    public function test_access_is_blocked_after_window_ends(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request([
            'user_id' => $guru->id,
            'start_at' => now()->subDays(2),
            'end_at' => now()->subDay(),
        ]);

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertForbidden();
    }

    public function test_access_is_allowed_inside_window(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $this->request([
            'user_id' => $guru->id,
            'start_at' => now()->subHour(),
            'end_at' => now()->addHour(),
        ]);

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertOk();
    }

    public function test_guru_request_requires_valid_time_window(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);

        $this->actingAs($guru)
            ->post(route('guru.izin-akses.store'), [
                'module' => 'berita',
                'action_type' => 'create',
                'start_at' => now()->addDay()->format('Y-m-d\TH:i'),
                'end_at' => now()->subDay()->format('Y-m-d\TH:i'),
                'reason' => 'Perlu menambah berita baru.',
            ])
            ->assertSessionHasErrors(['end_at']);
    }

    public function test_admin_can_adjust_window_when_approving(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $guru = User::factory()->create(['role' => 'guru']);
        $request = $this->request([
            'user_id' => $guru->id,
            'status' => 'pending',
            'start_at' => now()->addDay(),
            'end_at' => now()->addDays(2),
        ]);

        $this->actingAs($admin)
            ->put(route('admin.izin-akses.approve', $request), [
                'start_at' => now()->subHour()->format('Y-m-d\TH:i'),
                'end_at' => now()->addDays(3)->format('Y-m-d\TH:i'),
                'admin_note' => 'Disetujui untuk semester ganjil.',
            ])
            ->assertRedirect(route('admin.izin-akses.index'));

        $request->refresh();

        $this->assertSame('approved', $request->status);
        $this->assertTrue($request->isWithinWindow());
    }

    public function test_admin_can_revoke_approved_access(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $guru = User::factory()->create(['role' => 'guru']);
        $request = $this->request([
            'user_id' => $guru->id,
            'start_at' => now()->subHour(),
            'end_at' => null,
        ]);

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertOk();

        $this->actingAs($admin)
            ->put(route('admin.izin-akses.revoke', $request))
            ->assertRedirect(route('admin.izin-akses.index'));

        $request->refresh();

        $this->assertSame('revoked', $request->status);
        $this->assertFalse($request->isWithinWindow());

        $this->actingAs($guru)
            ->get(route('guru.berita.index'))
            ->assertForbidden();
    }
}
