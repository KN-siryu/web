<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminDashboardQuickActionsTest extends TestCase
{
    use RefreshDatabase;

    public function test_dashboard_quick_actions_open_their_admin_pages(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)
            ->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee('href="'.route('admin.berita.create').'"', false)
            ->assertSee('href="'.route('admin.galeri.create').'"', false)
            ->assertSee('href="'.route('admin.staf.create').'"', false)
            ->assertSee('href="'.route('admin.pesan.index').'"', false)
            ->assertSee('href="'.route('admin.berita.index').'"', false);
    }
}
