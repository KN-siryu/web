<?php

namespace Tests\Feature\Admin;

use App\Models\Setting;
use App\Models\Staf;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class SettingLogoTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_upload_site_logo_and_favicon(): void
    {
        Storage::fake('public');

        $admin = User::factory()->create(['role' => 'admin']);
        $oldLogoPath = UploadedFile::fake()->image('old-logo.png')->store('site', 'public');

        Setting::create(['key' => 'logo', 'value' => $oldLogoPath]);

        $this->actingAs($admin)
            ->post(route('admin.pengaturan.update'), [
                'nama_sekolah' => 'Sekolah Baru',
                'logo' => UploadedFile::fake()->image('logo.png'),
                'favicon' => UploadedFile::fake()->image('favicon.png'),
            ])
            ->assertRedirectToRoute('admin.pengaturan.index');

        $logoPath = Setting::get('logo');
        $faviconPath = Setting::get('favicon');

        $this->assertIsString($logoPath);
        $this->assertIsString($faviconPath);
        Storage::disk('public')->assertExists($logoPath);
        Storage::disk('public')->assertExists($faviconPath);
        Storage::disk('public')->assertMissing($oldLogoPath);
        $this->assertDatabaseHas('settings', ['key' => 'nama_sekolah', 'value' => 'Sekolah Baru']);

        $this->get(route('home'))
            ->assertOk()
            ->assertSee('Sekolah Baru')
            ->assertSee('storage/'.$logoPath, false)
            ->assertSee('storage/'.$faviconPath, false);
    }

    public function test_admin_can_upload_hero_image_and_it_appears_in_the_animated_home_banner(): void
    {
        Storage::fake('public');

        $admin = User::factory()->create(['role' => 'admin']);
        $oldHeroPath = UploadedFile::fake()->image('old-hero.png')->store('site', 'public');
        Setting::create(['key' => 'hero_image', 'value' => $oldHeroPath]);

        $this->actingAs($admin)
            ->post(route('admin.pengaturan.update'), [
                'hero_image' => UploadedFile::fake()->image('hero.png'),
            ])
            ->assertRedirectToRoute('admin.pengaturan.index');

        $heroImagePath = Setting::get('hero_image');

        $this->assertIsString($heroImagePath);
        Storage::disk('public')->assertExists($heroImagePath);
        Storage::disk('public')->assertMissing($oldHeroPath);

        $this->get(route('home'))
            ->assertOk()
            ->assertSee('storage/'.$heroImagePath, false)
            ->assertSee('class="hero-image absolute', false)
            ->assertSee('hero-zoom 18s', false);
    }

    public function test_admin_can_update_headmaster_name_and_profile_photo_on_homepage(): void
    {
        Storage::fake('public');

        $admin = User::factory()->create(['role' => 'admin']);
        $oldPhotoPath = UploadedFile::fake()->image('old-headmaster.png')->store('site', 'public');

        Setting::create(['key' => 'foto_kepala_sekolah', 'value' => $oldPhotoPath]);
        Staf::create([
            'nama' => 'Nama Lama dari Data Staf',
            'jabatan' => 'Kepala Sekolah',
            'kategori' => 'Kepala Sekolah',
        ]);

        $this->actingAs($admin)
            ->post(route('admin.pengaturan.update'), [
                'kepala_sekolah' => 'Nama Baru Kepala Sekolah',
                'foto_kepala_sekolah' => UploadedFile::fake()->image('headmaster.png'),
            ])
            ->assertRedirectToRoute('admin.pengaturan.index');

        $photoPath = Setting::get('foto_kepala_sekolah');

        $this->assertIsString($photoPath);
        $this->assertDatabaseHas('settings', [
            'key' => 'kepala_sekolah',
            'value' => 'Nama Baru Kepala Sekolah',
        ]);
        Storage::disk('public')->assertExists($photoPath);
        Storage::disk('public')->assertMissing($oldPhotoPath);

        $this->get(route('home'))
            ->assertOk()
            ->assertSee('Nama Baru Kepala Sekolah')
            ->assertDontSee('Nama Lama dari Data Staf')
            ->assertSee('storage/'.$photoPath, false);
    }

    public function test_invalid_site_logo_is_rejected_without_saving_it(): void
    {
        Storage::fake('public');

        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)
            ->from(route('admin.pengaturan.index'))
            ->post(route('admin.pengaturan.update'), [
                'logo' => UploadedFile::fake()->create('logo.txt', 10, 'text/plain'),
            ])
            ->assertRedirectToRoute('admin.pengaturan.index')
            ->assertSessionHasErrors('logo');

        $this->assertDatabaseMissing('settings', ['key' => 'logo']);
        $this->assertSame([], Storage::disk('public')->allFiles());
    }

    public function test_invalid_hero_image_is_rejected_without_saving_it(): void
    {
        Storage::fake('public');

        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)
            ->from(route('admin.pengaturan.index'))
            ->post(route('admin.pengaturan.update'), [
                'hero_image' => UploadedFile::fake()->create('banner.txt', 10, 'text/plain'),
            ])
            ->assertRedirectToRoute('admin.pengaturan.index')
            ->assertSessionHasErrors('hero_image');

        $this->assertDatabaseMissing('settings', ['key' => 'hero_image']);
        $this->assertSame([], Storage::disk('public')->allFiles());
    }

    public function test_guest_is_redirected_from_logo_settings(): void
    {
        $this->get(route('admin.pengaturan.index'))
            ->assertRedirectToRoute('login');
    }

    public function test_unknown_setting_keys_are_not_saved(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)
            ->post(route('admin.pengaturan.update'), ['unexpected_setting' => 'value'])
            ->assertRedirectToRoute('admin.pengaturan.index');

        $this->assertDatabaseMissing('settings', ['key' => 'unexpected_setting']);
    }
}
