<?php

namespace Tests\Feature;

use App\Models\Pesan;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class KontakMessageTest extends TestCase
{
    use RefreshDatabase;

    public function test_valid_contact_message_is_saved_for_admin_follow_up(): void
    {
        $this->post(route('kontak.store'), [
            'nama' => 'Nama Pengirim',
            'email' => 'pengirim@example.test',
            'subjek' => 'Pertanyaan sekolah',
            'pesan' => 'Mohon informasi pendaftaran sekolah.',
        ])
            ->assertRedirect()
            ->assertSessionHas('success', 'Pesan Anda berhasil dikirim dan akan ditindaklanjuti oleh pihak sekolah.');

        $this->assertDatabaseHas('pesans', [
            'nama' => 'Nama Pengirim',
            'email' => 'pengirim@example.test',
            'status' => 'baru',
        ]);

        $this->assertSame('Pertanyaan sekolah', Pesan::firstOrFail()->subjek);
    }

    public function test_short_contact_message_is_rejected(): void
    {
        $this->from(route('kontak.index'))
            ->post(route('kontak.store'), [
                'nama' => 'Nama Pengirim',
                'email' => 'pengirim@example.test',
                'subjek' => 'Pertanyaan',
                'pesan' => 'Pendek',
            ])
            ->assertRedirectToRoute('kontak.index')
            ->assertSessionHasErrors('pesan');

        $this->assertDatabaseCount('pesans', 0);
    }
}
