<?php $__env->startSection('title', 'Dashboard Guru'); ?>
<?php $__env->startSection('header_title', 'Dashboard Guru'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $guruApproved = auth()->user()->approvedModules();
?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 shadow-sm animate-[slideIn_.4s_ease-out]">
            <svg class="mt-0.5 h-5 w-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-700 p-6 shadow-lg shadow-emerald-200/60 sm:p-8 animate-fade-in-up">
        <div class="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/10 blur-2xl"></div>
        <div class="pointer-events-none absolute -bottom-20 left-10 h-48 w-48 rounded-full bg-emerald-300/20 blur-3xl"></div>
        <div class="relative flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
            <div>
                <p class="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-emerald-100">
                    <span class="inline-block h-2 w-2 animate-pulse rounded-full bg-emerald-300"></span>
                    Dashboard Guru
                </p>
                <h2 class="mt-2 text-2xl font-extrabold text-white sm:text-3xl">
                    Selamat datang, <?php echo e(auth()->user()->name); ?>

                </h2>
                <p class="mt-1 max-w-xl text-sm text-emerald-50">
                    Kelola informasi sekolah sesuai izin akses yang telah disetujui admin.
                    Izin Anda saat ini aktif untuk
                    <span class="font-semibold text-white">
                        <?php echo e(count($guruApproved) ? implode(', ', array_map('ucfirst', $guruApproved)) : 'belum ada modul'); ?>

                    </span>.
                </p>
            </div>
            <a href="<?php echo e(route('guru.izin-akses.create')); ?>"
               class="group inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-white/15 px-5 py-3 text-sm font-semibold text-white ring-1 ring-white/30 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/25">
                <svg class="h-5 w-5 transition-transform duration-300 group-hover:rotate-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h7z"></path>
                </svg>
                Ajukan Izin Akses
            </a>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php
            $stats = [
                ['label' => 'Total Pendaftar', 'value' => $totalPendaftar, 'tint' => 'from-emerald-500 to-teal-600', 'ring' => 'ring-emerald-100', 'text' => 'text-emerald-600', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'],
                ['label' => 'Diterima', 'value' => $totalPendaftarDiterima, 'tint' => 'from-emerald-500 to-green-600', 'ring' => 'ring-emerald-100', 'text' => 'text-emerald-600', 'icon' => 'M5 13l4 4L19 7'],
                ['label' => 'Pending', 'value' => $totalPendaftarPending, 'tint' => 'from-amber-400 to-orange-500', 'ring' => 'ring-amber-100', 'text' => 'text-amber-600', 'icon' => 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'],
                ['label' => 'Ditolak', 'value' => $totalPendaftarDitolak, 'tint' => 'from-rose-400 to-red-500', 'ring' => 'ring-rose-100', 'text' => 'text-rose-600', 'icon' => 'M6 18L18 6M6 6l12 12'],
            ];
        ?>
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg animate-fade-in-up delay-<?php echo e($i + 1); ?>">
                <div class="absolute inset-x-0 top-0 h-1 bg-gradient-to-r <?php echo e($stat['tint']); ?>"></div>
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-sm text-slate-500"><?php echo e($stat['label']); ?></p>
                        <p class="mt-1 text-3xl font-extrabold <?php echo e($stat['text']); ?>"><?php echo e($stat['value']); ?></p>
                    </div>
                    <span class="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br <?php echo e($stat['tint']); ?> text-white shadow-md transition-transform duration-300 group-hover:scale-110">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($stat['icon']); ?>"></path>
                        </svg>
                    </span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-5">
        
        <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-md lg:col-span-3 animate-fade-in-up delay-2">
            <h3 class="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-900">
                <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path>
                    </svg>
                </span>
                Berita Terbaru
            </h3>
            <div class="divide-y divide-slate-50">
                <?php $__empty_1 = true; $__currentLoopData = $recentBeritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('berita.show', $berita->slug)); ?>" target="_blank"
                       class="group flex items-center gap-3 rounded-xl py-3 transition hover:bg-slate-50">
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500 transition group-hover:bg-emerald-100 group-hover:text-emerald-600">
                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2-5 5z"></path>
                            </svg>
                        </div>
                        <div class="min-w-0">
                            <h4 class="truncate text-sm font-medium text-slate-900 group-hover:text-emerald-700"><?php echo e($berita->judul); ?></h4>
                            <p class="text-xs text-slate-500"><?php echo e($berita->created_at->format('d M Y')); ?></p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="py-6 text-center text-xs text-slate-400">Belum ada berita.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-md lg:col-span-2 animate-fade-in-up delay-3">
            <h3 class="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-900">
                <span class="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h7z"></path>
                    </svg>
                </span>
                Akses Cepat
            </h3>
            <div class="space-y-2">
                <?php $__currentLoopData = [
                    ['route' => 'account.edit', 'label' => 'Pengaturan Akun Saya', 'icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z'],
                    ['route' => 'ppdb.index', 'label' => 'PPDB Online', 'icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4'],
                    ['route' => 'berita.index', 'label' => 'Berita & Artikel', 'icon' => 'M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z'],
                    ['route' => 'ekskul.index', 'label' => 'Ekstrakurikuler', 'icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'],
                    ['route' => 'staf.index', 'label' => 'Staf Pengajar', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route($quick['route'])); ?>"
                       class="group flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium text-slate-700 transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-200 hover:bg-emerald-50 hover:text-emerald-700">
                        <svg class="h-4 w-4 shrink-0 text-slate-400 transition group-hover:text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($quick['icon']); ?>"></path>
                        </svg>
                        <?php echo e($quick['label']); ?>

                        <svg class="ml-auto h-4 w-4 -translate-x-1 opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm animate-fade-in-up delay-4">
        <h3 class="mb-4 text-sm font-semibold text-slate-900">Informasi Sekolah</h3>
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div class="group flex items-center gap-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 p-5 ring-1 ring-emerald-100 transition hover:-translate-y-0.5 hover:shadow-md">
                <span class="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-emerald-600 shadow-sm transition-transform group-hover:scale-110">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </span>
                <div>
                    <p class="text-2xl font-extrabold text-slate-900"><?php echo e($stafCount); ?></p>
                    <p class="text-xs text-slate-500">Staf Pengajar</p>
                </div>
            </div>
            <div class="group flex items-center gap-4 rounded-2xl bg-gradient-to-br from-teal-50 to-emerald-50 p-5 ring-1 ring-teal-100 transition hover:-translate-y-0.5 hover:shadow-md">
                <span class="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-teal-600 shadow-sm transition-transform group-hover:scale-110">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>
                </span>
                <div>
                    <p class="text-2xl font-extrabold text-slate-900"><?php echo e($ekskulCount); ?></p>
                    <p class="text-xs text-slate-500">Ekstrakurikuler</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\guru\dashboard.blade.php ENDPATH**/ ?>