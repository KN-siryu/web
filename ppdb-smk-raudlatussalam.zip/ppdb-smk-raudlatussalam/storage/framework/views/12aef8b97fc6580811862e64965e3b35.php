

<?php $__env->startSection('title', 'Pendaftaran Berhasil'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative isolate flex min-h-screen items-center overflow-hidden bg-slate-50 py-20">
    <div class="absolute -left-20 top-10 -z-10 h-72 w-72 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="float-slow absolute right-10 top-20 -z-10 hidden h-40 w-40 rounded-full bg-emerald-300/20 blur-2xl lg:block"></div>
    <div class="mx-auto w-full max-w-2xl px-4">
        <div class="reveal bg-white border border-slate-100 rounded-3xl shadow-xl shadow-slate-900/5 p-8 md:p-12 text-center">
            <div class="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg">
                <svg class="h-10 w-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>
            </div>
            <h1 class="text-3xl font-extrabold text-slate-900 mb-3">Pendaftaran Berhasil!</h1>
            <p class="text-slate-600 mb-8">Selamat <strong><?php echo e($pendaftar->nama_lengkap); ?></strong>, pendaftaran Anda telah kami terima. Simpan kode pendaftaran Anda untuk mencetak formulir di kemudian hari.</p>

            <div class="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-6 mb-8">
                <p class="text-xs text-emerald-600 uppercase font-semibold tracking-wider">Kode Pendaftaran Anda</p>
                <p class="text-3xl font-extrabold text-emerald-700 mt-2 tracking-wider"><?php echo e($pendaftar->kode_pendaftaran); ?></p>
            </div>

            <div class="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="<?php echo e(route('ppdb.cetak', $pendaftar->kode_pendaftaran)); ?>" target="_blank" class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200 transition hover:-translate-y-0.5">Cetak Formulir</a>
                <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 text-slate-700 font-semibold rounded-xl hover:bg-slate-200 transition hover:-translate-y-0.5">Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views/ppdb/success.blade.php ENDPATH**/ ?>