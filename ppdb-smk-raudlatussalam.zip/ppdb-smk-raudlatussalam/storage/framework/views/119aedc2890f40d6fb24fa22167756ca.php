

<?php $__env->startSection('title', 'Staf Pengajar'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h1 class="reveal text-4xl font-extrabold">Staf Pengajar</h1>
        <p class="reveal text-emerald-100 mt-2" style="--reveal-delay: 120ms">Tenaga pendidik profesional SMK Raudlatussalam</p>
    </div>
</section>

<!-- Content -->
<section class="py-16">
    <div class="max-w-7xl mx-auto px-4">
        
        <!-- Filter Kategori -->
        <div class="reveal flex flex-wrap gap-2 mb-10 justify-center">
            <?php
                $filterOptions = [
                    'all' => 'Semua',
                    'Kepala Sekolah' => 'Kepala Sekolah',
                    'Pengajar' => 'Guru Pengajar',
                    'Tenaga Kependidikan' => 'Tenaga Kependidikan',
                    'Wakasek Kurikulum' => 'Wakasek Kurikulum',
                    'Wakasek Kesiswaan' => 'Wakasek Kesiswaan',
                    'Wakasek Sarpras' => 'Wakasek Sarpras',
                    'Wali Kelas' => 'Wali Kelas',
                ];
            ?>

            <?php $__currentLoopData = $filterOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($value === 'all' ? route('staf.index') : route('staf.index', ['kategori' => $value])); ?>" class="px-4 py-2 text-sm font-medium rounded-lg transition-colors <?php echo e($kategori == $value ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50'); ?>"><?php echo e($label); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Grid Staf -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $stafs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="reveal group bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-xl" style="--reveal-delay: <?php echo e($loop->index * 70); ?>ms">
                <div class="aspect-square overflow-hidden bg-slate-100">
                    <img src="<?php echo e($staf->foto_url ?? 'https://ui-avatars.com/api/?name='.urlencode($staf->nama).'&background=f1f5f9&color=0f172a'); ?>" alt="<?php echo e($staf->nama); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                </div>
                <div class="p-5 text-center">
                    <span class="inline-block px-2.5 py-1 text-xs font-semibold rounded-lg 
                        <?php echo e($staf->kategori == 'Kepala Sekolah' ? 'bg-emerald-50 text-emerald-600' : ''); ?>

                        <?php echo e($staf->kategori == 'Pengajar' ? 'bg-blue-50 text-blue-600' : ''); ?>

                        <?php echo e($staf->kategori == 'Tenaga Kependidikan' ? 'bg-purple-50 text-purple-600' : ''); ?>

                        mb-2"><?php echo e($staf->kategori); ?></span>
                    <h3 class="font-bold text-slate-900"><?php echo e($staf->nama); ?></h3>
                    <p class="text-sm text-emerald-600 font-medium mt-1"><?php echo e($staf->jabatan); ?></p>
                    <?php if($staf->mata_pelajaran): ?>
                    <p class="text-xs text-slate-500 mt-1"><?php echo e($staf->mata_pelajaran); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-16">
                <p class="text-slate-500">Belum ada data staf.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\staf\index.blade.php ENDPATH**/ ?>