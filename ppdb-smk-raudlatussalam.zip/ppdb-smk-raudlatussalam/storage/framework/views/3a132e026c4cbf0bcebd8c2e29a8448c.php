

<?php $__env->startSection('title', 'Pendaftaran PPDB Online'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="relative isolate overflow-hidden bg-emerald-950 text-white py-16">
    <?php if(!empty($siteSettings['hero_image'])): ?>
    <img src="<?php echo e(asset('storage/'.$siteSettings['hero_image'])); ?>" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-25" loading="lazy">
    <?php endif; ?>
    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/40"></div>
    <div class="float-slow absolute -left-16 top-10 -z-10 h-64 w-64 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="mx-auto max-w-4xl px-4 text-center">
        <h1 class="reveal text-3xl font-extrabold">Formulir Pendaftaran Peserta Didik Baru</h1>
        <p class="reveal text-emerald-100 mt-2" style="--reveal-delay: 120ms">Pendaftaran online <?php echo e($siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam'); ?></p>
    </div>
</section>

<!-- Form Multi-Step -->
<section class="py-12 bg-slate-50 min-h-screen">
    <div class="max-w-3xl mx-auto px-4">
        
        <?php if($errors->any()): ?>
        <div class="reveal bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl mb-6">
            <p class="font-bold mb-2">Terdapat kesalahan input:</p>
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <div x-data="{ step: 1 }" class="reveal bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <form action="<?php echo e(route('ppdb.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <!-- Progress Bar -->
                <div class="bg-slate-50 border-b border-slate-100 p-6">
                    <div class="w-full flex items-center justify-between text-[10px] md:text-xs font-medium mb-4">
                        <span :class="step >= 1 ? 'text-emerald-600 font-bold' : 'text-slate-400'">1. Pendaftaran</span>
                        <span :class="step >= 2 ? 'text-emerald-600 font-bold' : 'text-slate-400'">2. Data Diri</span>
                        <span :class="step >= 3 ? 'text-emerald-600 font-bold' : 'text-slate-400'">3. Data Ayah</span>
                        <span :class="step >= 4 ? 'text-emerald-600 font-bold' : 'text-slate-400'">4. Data Ibu</span>
                        <span :class="step >= 5 ? 'text-emerald-600 font-bold' : 'text-slate-400'">5. Kontak</span>
                        <span :class="step >= 6 ? 'text-emerald-600 font-bold' : 'text-slate-400'">6. Dokumen</span>
                        <span :class="step >= 7 ? 'text-emerald-600 font-bold' : 'text-slate-400'">7. Konfirmasi</span>
                    </div>
                    <div class="w-full bg-slate-200 rounded-full h-2">
                        <div class="bg-emerald-600 h-2 rounded-full transition-all duration-300" :style="`width: ${(step / 7) * 100}%`"></div>
                    </div>
                </div>

                <div class="p-6 md:p-8">
                    
                    <!-- STEP 1: Pendaftaran -->
                    <div x-show="step === 1" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 1: Jenis & Jalur Pendaftaran</h2>
                            <p class="text-sm text-slate-500 mt-1">Pilih jenis dan jalur pendaftaran Anda.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Jenis Pendaftaran *</label>
                                <select name="jenis_pendaftaran" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                                    <option value="Baru">Baru</option>
                                    <option value="Pindahan">Pindahan</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Jalur Pendaftaran *</label>
                                <select name="jalur_pendaftaran" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                                    <option value="Umum">Umum</option>
                                    <option value="Prestasi">Prestasi</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 2: Data Pribadi -->
                    <div x-show="step === 2" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 2: Data Pribadi Siswa</h2>
                            <p class="text-sm text-slate-500 mt-1">Isi data pribadi calon siswa sesuai dokumen resmi.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Nama Lengkap *</label>
                                <input type="text" name="nama_lengkap" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">NISN</label>
                                <input type="text" name="nisn" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">NIK</label>
                                <input type="text" name="nik" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Jenis Kelamin *</label>
                                <select name="jenis_kelamin" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                                    <option value="L">Laki-laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Agama</label>
                                <input type="text" name="agama" value="Islam" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Tanggal Lahir</label>
                                <input type="date" name="tanggal_lahir" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Asal Sekolah</label>
                                <input type="text" name="asal_sekolah" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Alamat Tempat Tinggal</label>
                                <textarea name="alamat" rows="2" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 3: Data Ayah -->
                    <div x-show="step === 3" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 3: Data Ayah</h2>
                            <p class="text-sm text-slate-500 mt-1">Isi data lengkap ayah kandung.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Nama Lengkap Ayah</label>
                                <input type="text" name="nama_ayah" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Pekerjaan</label>
                                <input type="text" name="pekerjaan_ayah" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">No. Telepon / WhatsApp</label>
                                <input type="text" name="telepon_ayah" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                        </div>
                    </div>

                    <!-- STEP 4: Data Ibu -->
                    <div x-show="step === 4" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 4: Data Ibu</h2>
                            <p class="text-sm text-slate-500 mt-1">Isi data lengkap ibu kandung.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Nama Lengkap Ibu</label>
                                <input type="text" name="nama_ibu" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Pekerjaan</label>
                                <input type="text" name="pekerjaan_ibu" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">No. Telepon / WhatsApp</label>
                                <input type="text" name="telepon_ibu" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                        </div>
                    </div>

                    <!-- STEP 5: Kontak Wali -->
                    <div x-show="step === 5" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 5: Data Kontak Wali</h2>
                            <p class="text-sm text-slate-500 mt-1">Kontak yang bisa dihubungi untuk proses seleksi.</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Nama Wali *</label>
                                <input type="text" name="nama_wali" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">No. Telepon Wali *</label>
                                <input type="text" name="telepon_wali" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Email Wali *</label>
                                <input type="email" name="email_wali" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-slate-700 mb-2">Alamat Wali *</label>
                                <textarea name="alamat_wali" rows="2" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 6: Dokumen -->
                    <div x-show="step === 6" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 6: Upload Dokumen</h2>
                            <p class="text-sm text-slate-500 mt-1">Upload dokumen pendukung (Format: JPG/PNG, Max 2MB).</p>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Pas Foto 3x4</label>
                                <input type="file" name="foto" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Kartu Keluarga (KK)</label>
                                <input type="file" name="kk" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Akta Kelahiran</label>
                                <input type="file" name="akta" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-2">Ijazah / SKL</label>
                                <input type="file" name="ijazah" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700">
                            </div>
                        </div>
                    </div>

                    <!-- STEP 7: Konfirmasi -->
                    <div x-show="step === 7" style="display: none;" class="space-y-6">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900">Tahap 7: Konfirmasi Data</h2>
                            <p class="text-sm text-slate-500 mt-1">Pastikan data yang Anda masukkan sudah benar sebelum submit.</p>
                        </div>
                        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
                            <p>Dengan menekan tombol "Kirim Pendaftaran", saya menyatakan bahwa data yang diisi adalah benar dan dapat dipertanggungjawabkan.</p>
                        </div>
                    </div>

                    <!-- Tombol Navigasi -->
                    <div class="flex justify-between pt-6 mt-6 border-t border-slate-100">
                        <button type="button" x-show="step > 1" @click="step--" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">
                            ← Kembali
                        </button>
                        <div></div>
                        <button type="button" x-show="step < 7" @click="step++" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700">
                            Lanjut →
                        </button>
                        <button type="submit" x-show="step === 7" style="display: none;" class="px-6 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700">
                            Kirim Pendaftaran
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- Script untuk menampilkan Step 1 secara default -->
<script>
    // Tampilkan step 1 saat halaman dimuat
    document.addEventListener('DOMContentLoaded', function() {
        var step1 = document.querySelector('[x-show="step === 1"]');
        if (step1) {
            step1.style.display = 'block';
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\ppdb\index.blade.php ENDPATH**/ ?>