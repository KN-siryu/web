

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
?>

<?php $__env->startSection('title', 'Edit Foto'); ?>
<?php $__env->startSection('header_title', 'Edit Data Foto Galeri'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="<?php echo e(route($prefix.'galeri.update', $galeri)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            
            <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Judul Foto *</label>
                <input type="text" name="judul" value="<?php echo e(old('judul', $galeri->judul)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Kategori *</label>
                <input type="text" name="kategori" value="<?php echo e(old('kategori', $galeri->kategori)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Deskripsi (Opsional)</label>
                <textarea name="deskripsi" rows="3" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"><?php echo e(old('deskripsi', $galeri->deskripsi)); ?></textarea>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Foto Saat Ini</label>
                <img src="<?php echo e(asset('storage/' . $galeri->foto)); ?>" class="w-32 h-32 object-cover rounded-xl mb-2 border border-slate-100">
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2 mt-3">Ganti Foto (Opsional)</label>
                <input type="file" name="foto" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="<?php echo e(route($prefix.'galeri.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Update Foto</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\galeri\edit.blade.php ENDPATH**/ ?>