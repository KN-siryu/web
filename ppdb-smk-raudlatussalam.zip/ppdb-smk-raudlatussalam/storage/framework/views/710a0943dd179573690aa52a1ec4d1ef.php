

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative isolate flex min-h-[480px] items-center overflow-hidden bg-emerald-950 text-white md:min-h-[560px]">
    <?php
        $heroImageUrl = !empty($siteSettings['hero_image'])
            ? asset('storage/'.$siteSettings['hero_image'])
            : $heroPhoto?->foto_url;
    ?>
    <?php if($heroImageUrl): ?>
    <div class="absolute inset-0 -z-20 overflow-hidden" data-parallax="0.05">
        <img src="<?php echo e($heroImageUrl); ?>" alt="" class="hero-image h-full w-full object-cover" fetchpriority="high">
    </div>
    <?php endif; ?>
    <div class="animate-gradient absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/95 via-emerald-900/80 to-emerald-950/35"></div>
    <div class="float-slow absolute -left-20 top-10 -z-10 h-72 w-72 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="float-slower absolute right-10 top-20 -z-10 hidden h-40 w-40 rounded-full bg-emerald-300/20 blur-2xl lg:block"></div>

    <div class="mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div class="max-w-3xl">
            <span class="reveal inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 py-2 text-sm font-semibold text-emerald-50 backdrop-blur">
                <span class="h-2 w-2 animate-pulse rounded-full bg-emerald-300"></span>
                Budi Pekerti · Ilmu · Amal
            </span>
            <h1 class="reveal mt-6 text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl" style="--reveal-delay: 120ms">
                Selamat Datang di<br>
                <span class="bg-gradient-to-r from-emerald-200 to-teal-200 bg-clip-text text-transparent"><?php echo e($siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam'); ?></span>
            </h1>
            <p class="reveal mt-6 max-w-2xl text-base leading-7 text-emerald-50/90 sm:text-lg" style="--reveal-delay: 240ms">
                Membangun generasi yang berakhlak mulia, cerdas, dan terampil untuk menyiapkan masa depan yang gemilang.
            </p>
            <div class="reveal mt-8 flex flex-col gap-3 sm:flex-row" style="--reveal-delay: 360ms">
                <a href="<?php echo e(route('ppdb.index')); ?>" class="shine inline-flex items-center justify-center rounded-xl bg-white px-6 py-3.5 font-bold text-emerald-800 shadow-lg transition hover:-translate-y-0.5 hover:bg-emerald-50">
                    Daftar PPDB
                    <span aria-hidden="true" class="ml-2">→</span>
                </a>
                <a href="<?php echo e(route('profil.sekolah')); ?>" class="inline-flex items-center justify-center rounded-xl border border-white/40 px-6 py-3.5 font-bold text-white transition hover:-translate-y-0.5 hover:bg-white/10">
                    Jelajahi Sekolah
                </a>
            </div>
        </div>
    </div>

    <div class="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-slate-50 to-transparent"></div>

    <div class="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-emerald-100/70 md:flex">
        <span class="text-[11px] font-semibold uppercase tracking-widest">Scroll</span>
        <span class="flex h-9 w-5 justify-center rounded-full border border-white/30 p-1">
            <span class="h-2 w-1 animate-bounce rounded-full bg-emerald-200"></span>
        </span>
    </div>
</section>

<section class="relative z-10 -mt-8 px-4 sm:px-6 lg:px-8">
    <div class="reveal mx-auto grid max-w-7xl gap-8 rounded-3xl border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5 md:p-9 lg:grid-cols-5 lg:items-center">
        <div class="flex flex-col gap-6 sm:flex-row lg:col-span-3">
            <?php
                $kepalaSekolahNama = filled($siteSettings['kepala_sekolah'] ?? null)
                    ? $siteSettings['kepala_sekolah']
                    : ($kepalaSekolah?->nama ?? 'Kepala Sekolah');
                $kepalaSekolahFotoUrl = !empty($siteSettings['foto_kepala_sekolah'])
                    ? asset('storage/'.$siteSettings['foto_kepala_sekolah'])
                    : $kepalaSekolah?->foto_url;
            ?>
            <?php if($kepalaSekolahFotoUrl): ?>
            <img src="<?php echo e($kepalaSekolahFotoUrl); ?>" alt="Kepala sekolah <?php echo e($kepalaSekolahNama); ?>" class="h-36 w-36 shrink-0 rounded-2xl object-cover shadow-md ring-4 ring-emerald-50 sm:h-40 sm:w-40" loading="lazy">
            <?php else: ?>
            <div class="flex h-36 w-36 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-4xl font-extrabold text-emerald-700 sm:h-40 sm:w-40">
                <?php echo e(mb_substr($kepalaSekolahNama, 0, 1)); ?>

            </div>
            <?php endif; ?>
            <div>
                <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">Sambutan Kepala Sekolah</span>
                <h2 class="mt-2 text-2xl font-extrabold text-slate-900"><?php echo e($kepalaSekolahNama); ?></h2>
                <p class="mt-3 line-clamp-4 whitespace-pre-line text-sm leading-6 text-slate-600"><?php echo e($siteSettings['sambutan'] ?? 'Selamat datang di website resmi sekolah kami.'); ?></p>
                <a href="<?php echo e(route('profil.sekolah')); ?>" class="mt-4 inline-flex items-center gap-2 font-bold text-emerald-700 transition hover:gap-3 hover:text-emerald-900">
                    Profil sekolah <span aria-hidden="true">→</span>
                </a>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3 sm:gap-4 lg:col-span-2">
            <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-50 to-emerald-50/60 p-4 text-center ring-1 ring-slate-100 transition duration-300 hover:-translate-y-1 hover:shadow-lg hover:ring-emerald-200 sm:p-5" style="--reveal-delay: <?php echo e($index * 80); ?>ms">
                <div class="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-600 opacity-0 transition group-hover:opacity-100"></div>
                <p class="text-3xl font-extrabold tracking-tight text-emerald-800 sm:text-4xl">
                    <span class="count-up" data-target="<?php echo e($statistic['count']); ?>">0</span>
                </p>
                <p class="mt-1 text-xs font-semibold uppercase tracking-wide text-slate-500 sm:text-sm"><?php echo e($statistic['label']); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="px-4 pb-4 sm:px-6 lg:px-8">
    <div class="mx-auto grid max-w-7xl gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <?php $__currentLoopData = [
            ['icon' => 'M12 14l9-5-9-5-9 5 9 5z', 'title' => 'Akreditasi Unggul', 'desc' => 'Standar mutu pendidikan terjamin.'],
            ['icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M15 7a3 3 0 11-6 0 3 3 0 016 0z', 'title' => 'Tenaga Pendidik', 'desc' => 'Guru profesional & berpengalaman.'],
            ['icon' => 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253', 'title' => 'Fasilitas Lengkap', 'desc' => 'Sarana belajar modern & nyaman.'],
            ['icon' => 'M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z', 'title' => 'Lulusan Siap Kerja', 'desc' => 'Kompetensi sesuai kebutuhan industri.'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="reveal group flex items-center gap-4 rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-emerald-200 hover:shadow-lg" style="--reveal-delay: <?php echo e($i * 90); ?>ms">
            <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md transition-transform duration-300 group-hover:scale-110">
                <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="<?php echo e($item['icon']); ?>"></path>
                </svg>
            </span>
            <div>
                <h3 class="font-bold text-slate-900"><?php echo e($item['title']); ?></h3>
                <p class="mt-0.5 text-sm text-slate-500"><?php echo e($item['desc']); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="py-20 sm:py-24">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div class="reveal-left">
                <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">Kabar Sekolah</span>
                <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">Berita & informasi</h2>
                <p class="mt-3 max-w-2xl text-slate-600">Ikuti kabar terbaru, agenda, pengumuman, dan prestasi siswa.</p>
            </div>
            <a href="<?php echo e(route('berita.index')); ?>" class="reveal-right inline-flex items-center gap-2 font-bold text-emerald-700 hover:text-emerald-900">
                Semua berita <span aria-hidden="true">→</span>
            </a>
        </div>

        <div class="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="reveal group overflow-hidden rounded-2xl border border-slate-200 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-xl" style="--reveal-delay: <?php echo e($loop->index * 100); ?>ms">
                <a href="<?php echo e(route('berita.show', $berita)); ?>" class="block aspect-[16/10] overflow-hidden bg-gradient-to-br from-emerald-100 to-emerald-200">
                    <?php if($berita->gambar): ?>
                    <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
                    <?php else: ?>
                    <div class="flex h-full items-center justify-center text-5xl font-extrabold text-emerald-700/40"><?php echo e(mb_substr($berita->kategori, 0, 1)); ?></div>
                    <?php endif; ?>
                </a>
                <div class="p-6">
                    <div class="flex items-center gap-2 text-xs font-semibold text-slate-500">
                        <span class="text-emerald-700"><?php echo e($berita->kategori); ?></span>
                        <span aria-hidden="true">·</span>
                        <time datetime="<?php echo e($berita->created_at->toDateString()); ?>"><?php echo e($berita->created_at->format('d M Y')); ?></time>
                    </div>
                    <h3 class="mt-3 line-clamp-2 text-lg font-bold text-slate-900 group-hover:text-emerald-800">
                        <a href="<?php echo e(route('berita.show', $berita)); ?>"><?php echo e($berita->judul); ?></a>
                    </h3>
                    <p class="mt-2 line-clamp-2 text-sm leading-6 text-slate-600"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($berita->konten), 130)); ?></p>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="reveal rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500 md:col-span-2 lg:col-span-3">
                Berita sekolah akan ditampilkan di sini.
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="bg-slate-50 py-20 sm:py-24">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="reveal text-center">
            <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">Para pendidik</span>
            <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">Staf pengajar</h2>
            <p class="mx-auto mt-3 max-w-2xl text-slate-600">Tenaga pendidik yang mendampingi siswa dalam belajar dan mengembangkan potensi.</p>
        </div>
        <div class="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-4">
            <?php $__empty_1 = true; $__currentLoopData = $stafs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="reveal rounded-2xl border border-slate-100 bg-white p-5 text-center shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg" style="--reveal-delay: <?php echo e($loop->index * 70); ?>ms">
                <?php if($staf->foto_url): ?>
                <img src="<?php echo e($staf->foto_url); ?>" alt="<?php echo e($staf->nama); ?>" class="mx-auto h-20 w-20 rounded-full object-cover ring-4 ring-emerald-50" loading="lazy">
                <?php else: ?>
                <div class="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-2xl font-bold text-emerald-700 ring-4 ring-emerald-50"><?php echo e(mb_substr($staf->nama, 0, 1)); ?></div>
                <?php endif; ?>
                <h3 class="mt-4 line-clamp-2 font-bold text-slate-900"><?php echo e($staf->nama); ?></h3>
                <p class="mt-1 line-clamp-2 text-sm text-slate-500"><?php echo e($staf->jabatan); ?></p>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="reveal text-center text-slate-500 sm:col-span-4">Informasi staf pengajar akan segera tersedia.</p>
            <?php endif; ?>
        </div>
        <div class="reveal mt-8 text-center">
            <a href="<?php echo e(route('staf.index')); ?>" class="inline-flex items-center gap-2 rounded-xl border border-emerald-700 px-5 py-3 font-bold text-emerald-800 transition hover:bg-emerald-700 hover:text-white">
                Lihat semua staf <span aria-hidden="true">→</span>
            </a>
        </div>
    </div>
</section>

<section class="py-20 sm:py-24">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div class="reveal-left">
                <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">Cerita kegiatan</span>
                <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">Galeri sekolah</h2>
            </div>
            <div class="reveal-right flex items-center gap-3">
                <div class="hidden items-center gap-2 sm:flex">
                    <button type="button" data-gallery-prev aria-label="Sebelumnya"
                            class="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:text-emerald-700">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                    </button>
                    <button type="button" data-gallery-next aria-label="Berikutnya"
                            class="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:text-emerald-700">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </button>
                </div>
                <a href="<?php echo e(route('galeri.index')); ?>" class="inline-flex items-center gap-2 font-bold text-emerald-700 hover:text-emerald-900">
                    Lihat galeri <span aria-hidden="true">→</span>
                </a>
            </div>
        </div>

        <div class="relative mt-8">
            <div data-gallery-track class="flex snap-x snap-mandatory gap-5 sm:gap-6 overflow-x-auto scroll-smooth px-1 pb-6 pt-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                <?php $__empty_1 = true; $__currentLoopData = $galeris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('galeri.index')); ?>" class="reveal group relative aspect-square w-full shrink-0 snap-start overflow-hidden rounded-2xl bg-emerald-100 sm:w-[calc((100%-4.5rem)/4)]" style="--reveal-delay: <?php echo e($loop->index * 90); ?>ms">
                    <?php if($galeri->foto_url): ?>
                    <img src="<?php echo e($galeri->foto_url); ?>" alt="<?php echo e($galeri->judul); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
                    <?php else: ?>
                    <div class="flex h-full items-center justify-center text-emerald-700">Foto sekolah</div>
                    <?php endif; ?>
                    <div class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/80 to-transparent p-4 pt-12">
                        <p class="line-clamp-1 font-bold text-white"><?php echo e($galeri->judul); ?></p>
                        <p class="mt-1 text-xs text-emerald-100"><?php echo e($galeri->kategori); ?></p>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="reveal w-full text-slate-500">Foto kegiatan sekolah akan ditampilkan di sini.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="bg-emerald-950 py-20 text-white sm:py-24">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="reveal flex flex-col gap-10 lg:flex-row lg:items-center lg:justify-between">
            <div class="max-w-2xl">
                <span class="text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">Belajar bersama kami</span>
                <h2 class="mt-3 text-3xl font-extrabold sm:text-4xl">Kembangkan bakat dan minatmu</h2>
                <p class="mt-4 leading-7 text-emerald-100">Beragam kegiatan ekstrakurikuler menjadi ruang bagi siswa untuk belajar, berkarya, dan tumbuh bersama.</p>
            </div>
            <a href="<?php echo e(route('ekskul.index')); ?>" class="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-white px-6 py-3.5 font-bold text-emerald-900 transition hover:-translate-y-0.5 hover:bg-emerald-50">
                Jelajahi ekstrakurikuler <span aria-hidden="true">→</span>
            </a>
        </div>
        <div class="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="reveal rounded-2xl border border-white/10 bg-white/5 p-5 transition hover:bg-white/10" style="--reveal-delay: <?php echo e($loop->index * 80); ?>ms">
                <div class="flex items-center gap-4">
                    <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-400/15 text-2xl" aria-hidden="true"><?php echo e($ekskul->icon ?: '✦'); ?></span>
                    <div>
                        <h3 class="font-bold"><?php echo e($ekskul->nama); ?></h3>
                        <?php if($ekskul->pembina): ?>
                        <p class="mt-1 text-sm text-emerald-200">Pembina: <?php echo e($ekskul->pembina); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="reveal text-emerald-100 lg:col-span-3">Informasi ekstrakurikuler akan segera tersedia.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="px-4 py-16 sm:px-6 lg:px-8">
    <div class="reveal mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 rounded-3xl bg-gradient-to-r from-emerald-700 to-emerald-900 p-8 text-white sm:p-12 lg:flex-row lg:items-center">
        <div>
            <h2 class="text-2xl font-extrabold sm:text-3xl"><?php echo e(($siteSettings['cta_judul'] ?? '') ?: 'Siap memulai perjalanan belajarmu?'); ?></h2>
            <p class="mt-3 max-w-2xl text-emerald-100"><?php echo e(($siteSettings['cta_deskripsi'] ?? '') ?: 'Kenali sekolah kami dan dapatkan informasi pendaftaran peserta didik baru.'); ?></p>
        </div>
        <a href="<?php echo e(($siteSettings['cta_link'] ?? '') ?: route('ppdb.index')); ?>" class="inline-flex shrink-0 items-center gap-2 rounded-xl bg-white px-6 py-3.5 font-bold text-emerald-800 transition hover:-translate-y-0.5 hover:bg-emerald-50">
            <?php echo e(($siteSettings['cta_teks_tombol'] ?? '') ?: 'Informasi PPDB'); ?> <span aria-hidden="true">→</span>
        </a>
    </div>
</section>

<script>
    (function () {
        const track = document.querySelector('[data-gallery-track]');
        if (!track) {
            return;
        }
        const prev = document.querySelector('[data-gallery-prev]');
        const next = document.querySelector('[data-gallery-next]');

        function step() {
            const first = track.firstElementChild;
            if (!first) {
                return 300;
            }
            const gap = parseFloat(getComputedStyle(track).gap) || 16;
            return first.getBoundingClientRect().width + gap;
        }

        prev?.addEventListener('click', () => track.scrollBy({ left: -step(), behavior: 'smooth' }));
        next?.addEventListener('click', () => track.scrollBy({ left: step(), behavior: 'smooth' }));

        let autoTimer = null;
        const speed = 3500;

        function startAuto() {
            stopAuto();
            autoTimer = setInterval(() => {
                if (track.scrollLeft + track.clientWidth >= track.scrollWidth - 4) {
                    track.scrollTo({ left: 0, behavior: 'smooth' });
                } else {
                    track.scrollBy({ left: step(), behavior: 'smooth' });
                }
            }, speed);
        }

        function stopAuto() {
            if (autoTimer) {
                clearInterval(autoTimer);
                autoTimer = null;
            }
        }

        track.addEventListener('mouseenter', stopAuto);
        track.addEventListener('mouseleave', startAuto);
        track.addEventListener('touchstart', stopAuto, { passive: true });
        track.addEventListener('touchend', startAuto, { passive: true });

        startAuto();
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\home.blade.php ENDPATH**/ ?>