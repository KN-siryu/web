

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
?>

<?php $__env->startSection('title', 'Edit Staf'); ?>
<?php $__env->startSection('header_title', 'Edit Data Staf'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="<?php echo e(route($prefix.'staf.update', $staf)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            
            <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Lengkap *</label>
                    <input type="text" name="nama" value="<?php echo e(old('nama', $staf->nama)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">NIP (Opsional)</label>
                    <input type="text" name="nip" value="<?php echo e(old('nip', $staf->nip)); ?>" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Jabatan *</label>
                    <input type="text" name="jabatan" value="<?php echo e(old('jabatan', $staf->jabatan)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Kategori *</label>
                    <select name="kategori" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                        <option value="Pengajar" <?php echo e(old('kategori', $staf->kategori) == 'Pengajar' ? 'selected' : ''); ?>>Guru Pengajar</option>
                        <option value="Kepala Sekolah" <?php echo e(old('kategori', $staf->kategori) == 'Kepala Sekolah' ? 'selected' : ''); ?>>Kepala Sekolah</option>
                        <option value="Tenaga Kependidikan" <?php echo e(old('kategori', $staf->kategori) == 'Tenaga Kependidikan' ? 'selected' : ''); ?>>Tenaga Kependidikan</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Mata Pelajaran (Opsional)</label>
                    <input type="text" name="mata_pelajaran" value="<?php echo e(old('mata_pelajaran', $staf->mata_pelajaran)); ?>" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Pendidikan (Opsional)</label>
                    <input type="text" name="pendidikan" value="<?php echo e(old('pendidikan', $staf->pendidikan)); ?>" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Foto Saat Ini</label>
                <img src="<?php echo e($staf->foto ? asset('storage/' . $staf->foto) : 'https://ui-avatars.com/api/?name='.urlencode($staf->nama).'&background=f1f5f9&color=0f172a'); ?>" class="w-24 h-24 rounded-full object-cover mb-2 border border-slate-100">
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2 mt-3">Ganti Foto (Opsional)</label>
                <input type="file" name="foto" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="<?php echo e(route($prefix.'staf.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Update Staf</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\staf\edit.blade.php ENDPATH**/ ?>