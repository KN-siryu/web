

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
?>

<?php $__env->startSection('title', 'Pendaftar PPDB'); ?>
<?php $__env->startSection('header_title', 'Data Pendaftar PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Statistik Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white p-5 border border-slate-100 rounded-2xl shadow-sm">
            <p class="text-sm text-slate-500">Pending</p>
            <p class="text-2xl font-bold text-amber-600 mt-1"><?php echo e($totalPending); ?></p>
        </div>
        <div class="bg-white p-5 border border-slate-100 rounded-2xl shadow-sm">
            <p class="text-sm text-slate-500">Diterima</p>
            <p class="text-2xl font-bold text-emerald-600 mt-1"><?php echo e($totalDiterima); ?></p>
        </div>
        <div class="bg-white p-5 border border-slate-100 rounded-2xl shadow-sm">
            <p class="text-sm text-slate-500">Ditolak</p>
            <p class="text-2xl font-bold text-red-600 mt-1"><?php echo e($totalDitolak); ?></p>
        </div>
    </div>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari nama/kode..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <div class="flex flex-wrap gap-2">
                <a href="<?php echo e(route($prefix.'pendaftar.index')); ?>" class="px-3 py-1.5 text-xs font-medium rounded-lg <?php echo e($status == 'all' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'); ?>">Semua</a>
                <a href="<?php echo e(route($prefix.'pendaftar.index', ['status' => 'Pending'])); ?>" class="px-3 py-1.5 text-xs font-medium rounded-lg <?php echo e($status == 'Pending' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'); ?>">Pending</a>
                <a href="<?php echo e(route($prefix.'pendaftar.index', ['status' => 'Diterima'])); ?>" class="px-3 py-1.5 text-xs font-medium rounded-lg <?php echo e($status == 'Diterima' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'); ?>">Diterima</a>
                <a href="<?php echo e(route($prefix.'pendaftar.index', ['status' => 'Ditolak'])); ?>" class="px-3 py-1.5 text-xs font-medium rounded-lg <?php echo e($status == 'Ditolak' ? 'bg-red-500 text-white' : 'bg-slate-100 text-slate-600'); ?>">Ditolak</a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Kode</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama Siswa</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Asal Sekolah</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Jalur</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4 text-sm font-medium text-slate-900"><?php echo e($p->kode_pendaftaran); ?></td>
                        <td class="px-6 py-4">
                            <p class="text-sm font-medium text-slate-900"><?php echo e($p->nama_lengkap); ?></p>
                            <p class="text-xs text-slate-400"><?php echo e($p->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></p>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($p->asal_sekolah ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-slate-100 text-slate-600"><?php echo e($p->jalur_pendaftaran); ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <?php if($p->status == 'Pending'): ?>
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-amber-50 text-amber-600">Pending</span>
                            <?php elseif($p->status == 'Diterima'): ?>
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-600">Diterima</span>
                            <?php else: ?>
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-red-50 text-red-600">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="<?php echo e(route($prefix.'pendaftar.show', $p)); ?>" class="text-slate-500 hover:text-emerald-600 font-medium">Detail</a>
                            <a href="<?php echo e(route('ppdb.cetak', $p->kode_pendaftaran)); ?>" target="_blank" class="text-slate-500 hover:text-blue-600 font-medium">Cetak</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada pendaftar.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($pendaftars->appends(request()->query())->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\pendaftar\index.blade.php ENDPATH**/ ?>