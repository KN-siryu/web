

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'pesan');
?>

<?php $__env->startSection('title', 'Pesan Masuk'); ?>
<?php $__env->startSection('header_title', 'Pesan & Saran Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Info Pesan Baru -->
    <?php if($pesanBaru > 0): ?>
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center">
        <div class="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
        </div>
        <div>
            <p class="text-sm font-semibold text-blue-900">Ada <?php echo e($pesanBaru); ?> pesan baru yang belum dibaca!</p>
            <p class="text-xs text-blue-700 mt-0.5">Klik pada pesan untuk membaca detailnya.</p>
        </div>
    </div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari pesan..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <span class="text-sm text-slate-500">Total: <?php echo e($pesans->total()); ?> pesan</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Pengirim</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Subjek</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php $__empty_1 = true; $__currentLoopData = $pesans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 <?php echo e($pesan->status == 'baru' ? 'bg-blue-50/30' : ''); ?>">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center text-xs font-bold text-slate-600 uppercase">
                                    <?php echo e(substr($pesan->nama, 0, 1)); ?>

                                </div>
                                <div>
                                    <p class="text-sm font-medium text-slate-900"><?php echo e($pesan->nama); ?></p>
                                    <p class="text-xs text-slate-400"><?php echo e($pesan->email); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600 max-w-xs truncate"><?php echo e($pesan->subjek); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($pesan->created_at->format('d M Y, H:i')); ?></td>
                        <td class="px-6 py-4">
                            <?php if($pesan->status == 'baru'): ?>
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-red-50 text-red-600">Baru</span>
                            <?php else: ?>
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-slate-100 text-slate-500">Dibaca</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="<?php echo e(route($prefix.'pesan.show', $pesan)); ?>" class="text-slate-500 hover:text-emerald-600 font-medium">Baca</a>
                            <?php if($canDelete): ?>
                            <form action="<?php echo e(route($prefix.'pesan.destroy', $pesan)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Hapus pesan ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada pesan masuk.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($pesans->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\pesan\index.blade.php ENDPATH**/ ?>