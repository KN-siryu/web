

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'ekskul');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'ekskul');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'ekskul');
?>

<?php $__env->startSection('title', 'Kelola Ekskul'); ?>
<?php $__env->startSection('header_title', 'Kelola Ekstrakurikuler'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari ekskul..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <?php if($canCreate): ?>
            <a href="<?php echo e(route($prefix.'ekskul.create')); ?>" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Ekskul
            </a>
            <?php endif; ?>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama Ekskul</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Pembina</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Warna</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php $__empty_1 = true; $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-xl flex items-center justify-center text-xl 
                                    <?php echo e($ekskul->warna == 'emerald' ? 'bg-emerald-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'blue' ? 'bg-blue-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'orange' ? 'bg-orange-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'red' ? 'bg-red-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'purple' ? 'bg-purple-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'yellow' ? 'bg-yellow-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'cyan' ? 'bg-cyan-50' : ''); ?>

                                    <?php echo e($ekskul->warna == 'slate' ? 'bg-slate-100' : ''); ?>

                                "><?php echo e($ekskul->icon); ?></div>
                                <p class="text-sm font-medium text-slate-900"><?php echo e($ekskul->nama); ?></p>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($ekskul->pembina ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg capitalize bg-slate-100 text-slate-600"><?php echo e($ekskul->warna); ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <?php if($canEdit): ?>
                            <a href="<?php echo e(route($prefix.'ekskul.edit', $ekskul)); ?>" class="text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            <?php endif; ?>
                            <?php if($canDelete): ?>
                            <form action="<?php echo e(route($prefix.'ekskul.destroy', $ekskul)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Hapus data ekskul ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada data ekskul.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($ekskuls->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\ekskul\index.blade.php ENDPATH**/ ?>