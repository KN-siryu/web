<?php $__env->startSection('title', 'Visi & Misi'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative isolate overflow-hidden bg-emerald-950 text-white py-20">
    <?php if(!empty($siteSettings['hero_image'])): ?>
    <img src="<?php echo e(asset('storage/'.$siteSettings['hero_image'])); ?>" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-30" loading="lazy">
    <?php endif; ?>
    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/40"></div>
    <div class="float-slow absolute -left-16 top-10 -z-10 h-64 w-64 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="mx-auto max-w-7xl px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Arah Pendidikan</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">Visi & Misi</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms"><?php echo e($siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam'); ?></p>
    </div>
</section>

<section class="py-16">
    <div class="mx-auto max-w-5xl px-4 space-y-8">
        <article class="reveal-left group relative overflow-hidden rounded-3xl border border-slate-100 bg-white p-8 md:p-10 shadow-sm transition hover:shadow-xl">
            <div class="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-emerald-100/60 blur-2xl"></div>
            <div class="relative flex items-start gap-5">
                <span class="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg">
                    <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                </span>
                <div>
                    <span class="text-sm font-bold uppercase tracking-wider text-emerald-600">Visi</span>
                    <h2 class="mt-2 text-2xl font-extrabold text-slate-900"><?php echo e(($siteSettings['visi'] ?? '') ?: 'Membangun generasi yang berakhlak mulia, cerdas, dan terampil'); ?></h2>
                    <p class="mt-4 leading-relaxed text-slate-600">Menyiapkan peserta didik agar mampu mempersiapkan masa depan yang gemilang dengan fondasi karakter yang kuat.</p>
                </div>
            </div>
        </article>

        <article class="reveal-right group relative overflow-hidden rounded-3xl border border-slate-100 bg-white p-8 md:p-10 shadow-sm transition hover:shadow-xl">
            <div class="absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-teal-100/60 blur-2xl"></div>
            <div class="relative flex items-start gap-5">
                <span class="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-lg">
                    <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
                </span>
                <div>
                    <span class="text-sm font-bold uppercase tracking-wider text-emerald-600">Misi</span>
                    <h2 class="mt-2 text-2xl font-extrabold text-slate-900">Budi Pekerti - Ilmu - Amal</h2>
                    <p class="mt-4 leading-relaxed text-slate-600">Menyelenggarakan pendidikan yang mengembangkan ilmu, keterampilan, dan akhlak mulia peserta didik.</p>
                    <?php
                        $misiText = trim($siteSettings['misi'] ?? '');
                        $misiLines = $misiText !== '' ? preg_split('/\r?\n/', $misiText) : ['Mengembangkan karakter berakhlak mulia', 'Meningkatkan kompetensi ilmu dan keterampilan', 'Membentuk siswa yang bermanfaat bagi masyarakat'];
                    ?>
                    <ul class="mt-5 space-y-2 text-sm text-slate-600">
                        <?php $__currentLoopData = $misiLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(trim($line) !== ''): ?>
                            <li class="flex items-center gap-2"><span class="h-2 w-2 rounded-full bg-emerald-500"></span><?php echo e(trim($line)); ?></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\profile\visi-misi.blade.php ENDPATH**/ ?>