<?php $__env->startSection('title', 'Fasilitas'); ?>

<?php $__env->startSection('content'); ?>
<section class="relative isolate overflow-hidden bg-emerald-950 text-white py-20">
    <?php if(!empty($siteSettings['hero_image'])): ?>
    <img src="<?php echo e(asset('storage/'.$siteSettings['hero_image'])); ?>" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-30" loading="lazy">
    <?php endif; ?>
    <div class="absolute inset-0 -z-10 bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/40"></div>
    <div class="float-slow absolute -left-16 top-10 -z-10 h-64 w-64 rounded-full bg-emerald-400/20 blur-3xl"></div>
    <div class="mx-auto max-w-7xl px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Dukungan Pembelajaran</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">Fasilitas Sekolah</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms"><?php echo e($siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam'); ?></p>
    </div>
</section>

<section class="py-16">
    <div class="max-w-6xl mx-auto px-4">
        <?php if($fasilitas->isEmpty()): ?>
            <article class="reveal bg-white rounded-3xl border border-slate-100 shadow-sm p-8 md:p-10">
                <h2 class="text-2xl font-extrabold text-slate-900 mb-4">Informasi Fasilitas</h2>
                <p class="text-slate-600 leading-relaxed">Saat ini belum ada data fasilitas yang tersedia. Silakan hubungi pihak sekolah untuk informasi lebih lanjut.</p>
                <div class="mt-8">
                    <a href="<?php echo e(route('kontak.index')); ?>" class="inline-flex items-center px-5 py-3 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700">Hubungi Sekolah</a>
                </div>
            </article>
        <?php else: ?>
            <div class="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                <?php $__currentLoopData = $fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="reveal group relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg" style="--reveal-delay: <?php echo e($loop->index * 80); ?>ms">
                        <div class="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-emerald-100/60 blur-2xl transition group-hover:bg-emerald-200/60"></div>
                        <div class="relative mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-3xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110">
                            <?php echo e($item->icon ?: '✓'); ?>

                        </div>
                        <h2 class="text-xl font-bold text-slate-900"><?php echo e($item->nama); ?></h2>
                        <p class="mt-3 text-sm leading-6 text-slate-600"><?php echo e($item->deskripsi ?: 'Fasilitas sekolah yang tersedia untuk mendukung proses belajar mengajar.'); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\profile\fasilitas.blade.php ENDPATH**/ ?>