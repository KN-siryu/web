

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
?>

<?php $__env->startSection('title', 'Tambah Fasilitas'); ?>
<?php $__env->startSection('header_title', 'Tambah Fasilitas Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="<?php echo e(route($prefix.'fasilitas.store')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>

            <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Fasilitas *</label>
                    <input type="text" name="nama" value="<?php echo e(old('nama')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: Laboratorium Komputer">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Icon</label>
                    <input type="text" name="icon" value="<?php echo e(old('icon')); ?>" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Contoh: 💻 atau ✓">
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Urutan Tampilan</label>
                <input type="number" name="urutan" value="<?php echo e(old('urutan', 0)); ?>" min="0" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Deskripsi</label>
                <textarea name="deskripsi" rows="6" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none" placeholder="Jelaskan fasilitas ini..."><?php echo e(old('deskripsi')); ?></textarea>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="<?php echo e(route($prefix.'fasilitas.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Simpan Fasilitas</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\fasilitas\create.blade.php ENDPATH**/ ?>