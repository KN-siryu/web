<?php $__env->startSection('title', 'Tambah User'); ?>
<?php $__env->startSection('header_title', 'Buat Akun Guru Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>

            <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Nama Lengkap *</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Masukkan nama lengkap">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Email *</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="contoh@sekolah.sch.id">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Password *</label>
                <input type="password" name="password" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Minimal 8 karakter">
                <p class="text-[11px] text-slate-400 mt-1">Minimal 8 karakter</p>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Konfirmasi Password *</label>
                <input type="password" name="password_confirmation" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent" placeholder="Masukkan ulang password">
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Simpan User</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\users\create.blade.php ENDPATH**/ ?>