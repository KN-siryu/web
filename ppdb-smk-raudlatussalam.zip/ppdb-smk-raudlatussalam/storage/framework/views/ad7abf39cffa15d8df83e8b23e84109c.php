<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Formulir - <?php echo e($pendaftar->kode_pendaftaran); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
        }
    </style>
</head>
<body class="bg-gray-100 p-8">

    <div class="max-w-4xl mx-auto bg-white p-8 md:p-12 shadow-lg rounded-lg">
        
        <!-- Header Cetak -->
        <div class="text-center border-b-2 border-slate-800 pb-4 mb-6">
            <h1 class="text-2xl font-bold">FORMULIR PENDAFTARAN PESERTA DIDIK BARU</h1>
            <h2 class="text-lg"><?php echo e(strtoupper($siteSettings['nama_sekolah'] ?? 'SMK RAUDLATUSSALAM')); ?></h2>
            <p class="text-sm text-slate-500"><?php echo e($siteSettings['alamat'] ?? ''); ?></p>
        </div>

        <div class="flex justify-between mb-6">
            <div>
                <p class="text-sm"><span class="font-semibold">Kode Pendaftaran:</span> <?php echo e($pendaftar->kode_pendaftaran); ?></p>
                <p class="text-sm"><span class="font-semibold">Tanggal Daftar:</span> <?php echo e($pendaftar->created_at->format('d M Y')); ?></p>
                <p class="text-sm"><span class="font-semibold">Status:</span> <?php echo e($pendaftar->status); ?></p>
            </div>
            <div class="text-right">
                <?php if($pendaftar->path_foto): ?>
                <img src="<?php echo e(asset('storage/' . $pendaftar->path_foto)); ?>" class="w-24 h-32 object-cover border">
                <?php endif; ?>
            </div>
        </div>

        <!-- Data Detail -->
        <table class="w-full text-sm mb-6">
            <tbody class="divide-y divide-gray-100">
                <tr><td class="py-2 w-1/3 font-semibold">Jenis Pendaftaran</td><td class="py-2">: <?php echo e($pendaftar->jenis_pendaftaran); ?></td></tr>
                <tr><td class="py-2 font-semibold">Jalur Pendaftaran</td><td class="py-2">: <?php echo e($pendaftar->jalur_pendaftaran); ?></td></tr>
                <tr><td class="py-2 font-semibold">Nama Lengkap</td><td class="py-2">: <?php echo e($pendaftar->nama_lengkap); ?></td></tr>
                <tr><td class="py-2 font-semibold">NISN / NIK</td><td class="py-2">: <?php echo e($pendaftar->nisn); ?> / <?php echo e($pendaftar->nik); ?></td></tr>
                <tr><td class="py-2 font-semibold">Jenis Kelamin</td><td class="py-2">: <?php echo e($pendaftar->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td></tr>
                <tr><td class="py-2 font-semibold">TTL</td><td class="py-2">: <?php echo e($pendaftar->tempat_lahir); ?>, <?php echo e($pendaftar->tanggal_lahir ? \Carbon\Carbon::parse($pendaftar->tanggal_lahir)->format('d M Y') : '-'); ?></td></tr>
                <tr><td class="py-2 font-semibold">Asal Sekolah</td><td class="py-2">: <?php echo e($pendaftar->asal_sekolah); ?></td></tr>
                <tr><td class="py-2 font-semibold">Alamat</td><td class="py-2">: <?php echo e($pendaftar->alamat); ?></td></tr>
                <tr><td class="py-2 font-semibold">Nama Ayah</td><td class="py-2">: <?php echo e($pendaftar->nama_ayah); ?> (<?php echo e($pendaftar->pekerjaan_ayah); ?>)</td></tr>
                <tr><td class="py-2 font-semibold">Nama Ibu</td><td class="py-2">: <?php echo e($pendaftar->nama_ibu); ?> (<?php echo e($pendaftar->pekerjaan_ibu); ?>)</td></tr>
                <tr><td class="py-2 font-semibold">Kontak Wali</td><td class="py-2">: <?php echo e($pendaftar->nama_wali); ?> - <?php echo e($pendaftar->telepon_wali); ?></td></tr>
            </tbody>
        </table>

        <!-- Tombol Cetak -->
        <div class="text-center mt-8 no-print">
            <button onclick="window.print()" class="px-6 py-3 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700">Cetak Formulir (PDF)</button>
            <a href="<?php echo e(route('home')); ?>" class="px-6 py-3 bg-slate-100 text-slate-700 font-semibold rounded-xl hover:bg-slate-200 ml-2">Kembali</a>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\ppdb\cetak.blade.php ENDPATH**/ ?>