

<?php $__env->startSection('title', 'Ekstrakurikuler'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h1 class="reveal text-4xl font-extrabold">Ekstrakurikuler</h1>
        <p class="reveal text-emerald-100 mt-2" style="--reveal-delay: 120ms">Wadah penyaluran minat dan bakat siswa SMK Raudlatussalam</p>
    </div>
</section>

<!-- Content -->
<section class="py-16">
    <div class="max-w-7xl mx-auto px-4">
        <div class="reveal text-center mb-12 max-w-2xl mx-auto">
            <p class="text-slate-600">SMK Raudlatussalam menyediakan berbagai kegiatan ekstrakurikuler untuk mengembangkan potensi siswa di luar jam pelajaran reguler. Pilih ekskul sesuai minat dan bakatmu!</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="reveal group bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-xl" style="--reveal-delay: <?php echo e($loop->index * 80); ?>ms">
                <div class="p-6 flex items-start space-x-4">
                    <div class="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0
                        <?php echo e($ekskul->warna == 'emerald' ? 'bg-emerald-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'blue' ? 'bg-blue-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'orange' ? 'bg-orange-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'red' ? 'bg-red-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'purple' ? 'bg-purple-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'yellow' ? 'bg-yellow-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'cyan' ? 'bg-cyan-50' : ''); ?>

                        <?php echo e($ekskul->warna == 'slate' ? 'bg-slate-100' : ''); ?>

                    ">
                        <?php echo e($ekskul->icon); ?>

                    </div>
                    <div class="flex-1">
                        <h3 class="font-bold text-slate-900 text-lg"><?php echo e($ekskul->nama); ?></h3>
                        <p class="text-xs text-slate-500 mt-0.5 flex items-center">
                            <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                            Pembina: <?php echo e($ekskul->pembina); ?>

                        </p>
                        <p class="text-sm text-slate-600 mt-2 line-clamp-3"><?php echo e($ekskul->deskripsi); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-16">
                <p class="text-slate-500">Belum ada data ekstrakurikuler.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\ekskul\index.blade.php ENDPATH**/ ?>