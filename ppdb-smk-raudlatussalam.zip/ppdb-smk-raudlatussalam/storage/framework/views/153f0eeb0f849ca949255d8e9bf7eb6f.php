

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'pendaftar');
?>

<?php $__env->startSection('title', 'Detail Pendaftar'); ?>
<?php $__env->startSection('header_title', 'Detail Data Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl mb-6"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        
        <!-- Header -->
        <div class="flex flex-col md:flex-row justify-between items-start border-b border-slate-100 pb-6 mb-6">
            <div class="flex items-center space-x-4 mb-4 md:mb-0">
                <?php if($pendaftar->path_foto): ?>
                <img src="<?php echo e(asset('storage/' . $pendaftar->path_foto)); ?>" class="w-20 h-24 object-cover rounded-xl border">
                <?php else: ?>
                <div class="w-20 h-24 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <?php endif; ?>
                <div>
                    <h3 class="text-xl font-bold text-slate-900"><?php echo e($pendaftar->nama_lengkap); ?></h3>
                    <p class="text-sm text-slate-500"><?php echo e($pendaftar->kode_pendaftaran); ?></p>
                    <p class="text-sm text-slate-500 mt-1"><?php echo e($pendaftar->asal_sekolah ?? '-'); ?></p>
                </div>
            </div>

            <!-- Form Update Status -->
            <?php if($canEdit): ?>
            <div class="w-full md:w-auto">
                <form action="<?php echo e(route($prefix.'pendaftar.status', $pendaftar)); ?>" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Ubah Status</label>
                    <div class="flex space-x-2">
                        <select name="status" class="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500">
                            <option value="Pending" <?php echo e($pendaftar->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="Diterima" <?php echo e($pendaftar->status == 'Diterima' ? 'selected' : ''); ?>>Diterima</option>
                            <option value="Ditolak" <?php echo e($pendaftar->status == 'Ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                        <button type="submit" class="px-4 py-2 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700">Update</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <!-- Grid Data -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <!-- Data Pribadi -->
            <div>
                <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Data Pribadi</h4>
                <div class="space-y-3 text-sm">
                    <p><span class="text-slate-500">NISN:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->nisn ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">NIK:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->nik ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">Jenis Kelamin:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></span></p>
                    <p><span class="text-slate-500">TTL:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->tempat_lahir ?? '-'); ?>, <?php echo e($pendaftar->tanggal_lahir ? \Carbon\Carbon::parse($pendaftar->tanggal_lahir)->format('d M Y') : '-'); ?></span></p>
                    <p><span class="text-slate-500">Agama:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->agama ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">Alamat:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->alamat ?? '-'); ?></span></p>
                </div>
            </div>

            <!-- Data Orang Tua -->
            <div>
                <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Data Orang Tua</h4>
                <div class="space-y-3 text-sm">
                    <p><span class="text-slate-500">Ayah:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->nama_ayah ?? '-'); ?> (<?php echo e($pendaftar->pekerjaan_ayah ?? '-'); ?>)</span></p>
                    <p><span class="text-slate-500">Telepon Ayah:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->telepon_ayah ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">Ibu:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->nama_ibu ?? '-'); ?> (<?php echo e($pendaftar->pekerjaan_ibu ?? '-'); ?>)</span></p>
                    <p><span class="text-slate-500">Telepon Ibu:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->telepon_ibu ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">Wali:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->nama_wali ?? '-'); ?></span></p>
                    <p><span class="text-slate-500">Kontak Wali:</span> <span class="font-medium text-slate-900"><?php echo e($pendaftar->telepon_wali ?? '-'); ?> / <?php echo e($pendaftar->email_wali ?? '-'); ?></span></p>
                </div>
            </div>
        </div>

        <!-- Dokumen -->
        <div class="mb-8">
            <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Dokumen Upload</h4>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php if($pendaftar->path_foto): ?>
                <a href="<?php echo e(asset('storage/' . $pendaftar->path_foto)); ?>" target="_blank" class="block group">
                    <div class="aspect-square bg-slate-100 rounded-xl overflow-hidden">
                        <img src="<?php echo e(asset('storage/' . $pendaftar->path_foto)); ?>" class="w-full h-full object-cover group-hover:opacity-80">
                    </div>
                    <p class="text-xs text-center text-slate-500 mt-1">Pas Foto</p>
                </a>
                <?php endif; ?>
                <?php if($pendaftar->path_kk): ?>
                <a href="<?php echo e(asset('storage/' . $pendaftar->path_kk)); ?>" target="_blank" class="block group">
                    <div class="aspect-square bg-slate-100 rounded-xl overflow-hidden">
                        <img src="<?php echo e(asset('storage/' . $pendaftar->path_kk)); ?>" class="w-full h-full object-cover group-hover:opacity-80">
                    </div>
                    <p class="text-xs text-center text-slate-500 mt-1">Kartu Keluarga</p>
                </a>
                <?php endif; ?>
                <?php if($pendaftar->path_akta): ?>
                <a href="<?php echo e(asset('storage/' . $pendaftar->path_akta)); ?>" target="_blank" class="block group">
                    <div class="aspect-square bg-slate-100 rounded-xl overflow-hidden">
                        <img src="<?php echo e(asset('storage/' . $pendaftar->path_akta)); ?>" class="w-full h-full object-cover group-hover:opacity-80">
                    </div>
                    <p class="text-xs text-center text-slate-500 mt-1">Akta</p>
                </a>
                <?php endif; ?>
                <?php if($pendaftar->path_ijazah): ?>
                <a href="<?php echo e(asset('storage/' . $pendaftar->path_ijazah)); ?>" target="_blank" class="block group">
                    <div class="aspect-square bg-slate-100 rounded-xl overflow-hidden">
                        <img src="<?php echo e(asset('storage/' . $pendaftar->path_ijazah)); ?>" class="w-full h-full object-cover group-hover:opacity-80">
                    </div>
                    <p class="text-xs text-center text-slate-500 mt-1">Ijazah</p>
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="flex justify-between pt-6 border-t border-slate-100">
            <a href="<?php echo e(route($prefix.'pendaftar.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">← Kembali</a>
            <a href="<?php echo e(route('ppdb.cetak', $pendaftar->kode_pendaftaran)); ?>" target="_blank" class="px-6 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700">Cetak Formulir</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views/admin/pendaftar/show.blade.php ENDPATH**/ ?>