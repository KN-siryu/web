

<?php $__env->startSection('title', $kategori ? $kategori : 'Berita & Artikel'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <p class="reveal text-emerald-100 font-semibold mb-2">Informasi Terkini</p>
        <h1 class="reveal text-4xl font-extrabold" style="--reveal-delay: 100ms">Berita & Artikel</h1>
        <p class="reveal text-emerald-100 mt-3" style="--reveal-delay: 200ms">Informasi dan kegiatan <?php echo e($siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam'); ?></p>
    </div>
</section>

<section class="py-16 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4">
        <nav class="reveal flex flex-wrap gap-2 justify-center mb-10" aria-label="Filter kategori berita">
            <a href="<?php echo e(route('berita.index')); ?>" class="px-4 py-2 text-sm font-semibold rounded-lg <?php echo e(!$kategori ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50'); ?>">Semua</a>
            <?php $__currentLoopData = ['Berita', 'Pengumuman', 'Agenda', 'Prestasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('berita.index', ['kategori' => $category])); ?>" class="px-4 py-2 text-sm font-semibold rounded-lg <?php echo e($kategori === $category ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50'); ?>"><?php echo e($category); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="reveal group bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-xl" style="--reveal-delay: <?php echo e($loop->index * 90); ?>ms">
                <a href="<?php echo e(route('berita.show', $berita)); ?>" class="block aspect-video bg-emerald-50 overflow-hidden">
                    <?php if($berita->gambar): ?>
                    <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full h-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
                    <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-emerald-700 font-semibold">Berita <?php echo e($berita->kategori); ?></div>
                    <?php endif; ?>
                </a>
                <div class="p-6">
                    <div class="flex gap-2 text-xs text-slate-500 mb-3">
                        <span class="font-semibold text-emerald-700"><?php echo e($berita->kategori); ?></span>
                        <span aria-hidden="true">·</span>
                        <time datetime="<?php echo e($berita->created_at->toDateString()); ?>"><?php echo e($berita->created_at->format('d M Y')); ?></time>
                    </div>
                    <h2 class="text-lg font-bold text-slate-900">
                        <a href="<?php echo e(route('berita.show', $berita)); ?>" class="hover:text-emerald-700"><?php echo e($berita->judul); ?></a>
                    </h2>
                    <p class="text-sm text-slate-600 mt-3"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($berita->konten), 150)); ?></p>
                    <a href="<?php echo e(route('berita.show', $berita)); ?>" class="inline-block text-sm font-semibold text-emerald-700 mt-4">Baca selengkapnya</a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="sm:col-span-2 lg:col-span-3 text-center text-slate-500 py-16">Belum ada berita untuk kategori ini.</p>
            <?php endif; ?>
        </div>

        <?php if($beritas->hasPages()): ?>
        <div class="mt-10"><?php echo e($beritas->withQueryString()->links()); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\berita\index.blade.php ENDPATH**/ ?>