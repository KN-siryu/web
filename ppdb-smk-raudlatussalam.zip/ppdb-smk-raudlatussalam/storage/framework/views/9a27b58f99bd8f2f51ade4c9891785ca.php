<!DOCTYPE html>
<html lang="id">
<?php
    $siteName = $siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam';
    $siteLogo = $siteSettings['logo'] ?? null;
    $siteFavicon = $siteSettings['favicon'] ?? null;
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> - <?php echo e($siteName); ?></title>
    <link rel="icon" href="<?php echo e($siteFavicon ? asset('storage/'.$siteFavicon) : asset('favicon.ico')); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; overflow-x: hidden; }
        html { scroll-behavior: smooth; }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #059669; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #047857; }
        .hero-image { animation: hero-zoom 18s ease-in-out infinite alternate; }

        /* Scroll reveal base + directional variants */
        .js-reveal .reveal,
        .js-reveal .reveal-left,
        .js-reveal .reveal-right,
        .js-reveal .reveal-zoom {
            opacity: 0;
            transition: opacity 700ms cubic-bezier(.22, .61, .36, 1), transform 700ms cubic-bezier(.22, .61, .36, 1);
            transition-delay: var(--reveal-delay, 0ms);
            will-change: opacity, transform;
        }
        .js-reveal .reveal { transform: translateY(30px); }
        .js-reveal .reveal-left { transform: translateX(-52px); }
        .js-reveal .reveal-right { transform: translateX(52px); }
        .js-reveal .reveal-zoom { transform: scale(.94); }
        .js-reveal .reveal.is-visible,
        .js-reveal .reveal-left.is-visible,
        .js-reveal .reveal-right.is-visible,
        .js-reveal .reveal-zoom.is-visible { opacity: 1; transform: none; }

        @keyframes hero-zoom { from { transform: scale(1.12); } to { transform: scale(1.18); } }
        @keyframes float-slow { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-14px); } }
        @keyframes float-slower { 0%, 100% { transform: translate3d(0, 0, 0); } 50% { transform: translate3d(0, -24px, 0); } }
        @keyframes shine { 0% { transform: translateX(-120%) skewX(-20deg); } 100% { transform: translateX(220%) skewX(-20deg); } }
        @keyframes gradient-pan { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .float-slow { animation: float-slow 6s ease-in-out infinite; }
        .float-slower { animation: float-slower 12s ease-in-out infinite; }
        .animate-gradient { background-size: 200% 200%; animation: gradient-pan 16s ease infinite; }
        .shine { position: relative; overflow: hidden; }
        .shine::after { content: ''; position: absolute; inset: 0; background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .35), transparent); transform: translateX(-120%) skewX(-20deg); }
        .shine:hover::after { animation: shine 1.1s ease; }

        /* Sticky navbar scroll state */
        .site-nav { transition: box-shadow 350ms ease, background-color 350ms ease, backdrop-filter 350ms ease; }
        .site-nav.is-scrolled { box-shadow: 0 12px 32px -14px rgba(15, 23, 42, .28); background-color: rgba(255, 255, 255, .82); backdrop-filter: saturate(160%) blur(12px); }

        /* Animated underline for nav links */
        .nav-link { position: relative; }
        .nav-link::after { content: ''; position: absolute; left: .75rem; right: .75rem; bottom: .35rem; height: 2px; border-radius: 2px; background-color: #059669; transform: scaleX(0); transform-origin: left center; transition: transform 320ms cubic-bezier(.22, .61, .36, 1); }
        .nav-link:hover::after, .nav-link.is-active::after { transform: scaleX(1); }

        /* Parallax-friendly elements */
        [data-parallax] { will-change: transform; }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { scroll-behavior: auto !important; animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; }
            .js-reveal .reveal,
            .js-reveal .reveal-left,
            .js-reveal .reveal-right,
            .js-reveal .reveal-zoom { opacity: 1; transform: none; }
            .float-slow, .float-slower, .animate-gradient { animation: none; }
            [data-parallax] { transform: none !important; }
        }
    </style>
</head>
<body class="bg-white text-slate-900 antialiased">

    <!-- Top Bar (Info Kontak) -->
    <div class="bg-emerald-800 text-white text-xs py-2 hidden md:block">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center gap-6">
                <span class="flex items-center">
                    <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    <?php echo e($siteSettings['telepon'] ?? ''); ?>

                </span>
                <span class="flex items-center">
                    <svg class="w-3.5 h-3.5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    <?php echo e($siteSettings['email'] ?? ''); ?>

                </span>
            </div>
            <div class="flex items-center gap-4">
                <a href="#" class="hover:text-emerald-200 transition-colors">Facebook</a>
                <a href="#" class="hover:text-emerald-200 transition-colors">Instagram</a>
                <a href="#" class="hover:text-emerald-200 transition-colors">YouTube</a>
            </div>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="site-nav bg-white shadow-md sticky top-0 z-50" x-data="{ mobileOpen: false }">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center h-20">
                
                <!-- Logo -->
                <a href="<?php echo e(route('home')); ?>" class="flex items-center space-x-3 flex-shrink-0">
                    <?php if($siteLogo): ?>
                    <img src="<?php echo e(asset('storage/'.$siteLogo)); ?>" alt="Logo <?php echo e($siteName); ?>" class="w-12 h-12 object-contain">
                    <?php else: ?>
                    <div class="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center shadow-md">
                        <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path></svg>
                    </div>
                    <?php endif; ?>
                    <div>
                        <span class="text-base lg:text-lg font-extrabold text-slate-900 block leading-tight"><?php echo e($siteName); ?></span>
                        <span class="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider">Budi Pekerti - Ilmu - Amal</span>
                    </div>
                </a>

                <!-- Menu Desktop -->
                <div class="hidden lg:flex items-center space-x-1">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link px-3 py-2 text-sm font-medium text-slate-700 hover:text-emerald-600 transition-colors <?php echo e(request()->routeIs('home') ? 'text-emerald-600 is-active' : ''); ?>">Beranda</a>
                    
                    <!-- Dropdown Profil -->
                    <div class="relative" x-data="{ open: false }" @mouseenter="open = true" @mouseleave="open = false">
                        <button class="nav-link px-3 py-2 text-sm font-medium text-slate-700 hover:text-emerald-600 transition-colors flex items-center">
                            Profil
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                        </button>
                        <div x-show="open" x-cloak class="absolute left-0 top-full pt-2 w-56">
                            <div class="bg-white rounded-xl shadow-xl border border-slate-100 py-2">
                                <a href="<?php echo e(route('profil.sekolah')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Profil Sekolah</a>
                                <a href="<?php echo e(route('profil.visi-misi')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Visi & Misi</a>
                                <a href="<?php echo e(route('profil.sejarah')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Sejarah Singkat</a>
                                <a href="<?php echo e(route('profil.fasilitas')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Fasilitas</a>
                                <a href="<?php echo e(route('staf.index')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Staf Pengajar</a>
                                <div class="border-t border-slate-100 my-2"></div>
                                <p class="px-4 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Unit Kerja</p>
                                <a href="<?php echo e(route('staf.index', ['kategori' => 'Wakasek Kurikulum'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Wakasek Kurikulum</a>
                                <a href="<?php echo e(route('staf.index', ['kategori' => 'Wakasek Kesiswaan'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Wakasek Kesiswaan</a>
                                <a href="<?php echo e(route('staf.index', ['kategori' => 'Wakasek Sarpras'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Wakasek Sarpras</a>
                                <a href="<?php echo e(route('staf.index', ['kategori' => 'Wali Kelas'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Wali Kelas</a>
                            </div>
                        </div>
                    </div>

                    <a href="<?php echo e(route('ekskul.index')); ?>" class="nav-link px-3 py-2 text-sm font-medium text-slate-700 hover:text-emerald-600 transition-colors <?php echo e(request()->routeIs('ekskul.index') ? 'text-emerald-600 is-active' : ''); ?>">Ekstrakurikuler</a>
                    
                    <!-- Dropdown Informasi -->
                    <div class="relative" x-data="{ open: false }" @mouseenter="open = true" @mouseleave="open = false">
                        <button class="nav-link px-3 py-2 text-sm font-medium text-slate-700 hover:text-emerald-600 transition-colors flex items-center">
                            Informasi
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                        </button>
                        <div x-show="open" x-cloak class="absolute left-0 top-full pt-2 w-52">
                            <div class="bg-white rounded-xl shadow-xl border border-slate-100 py-2">
                                <a href="<?php echo e(route('berita.index')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Berita & Artikel</a>
                                <a href="<?php echo e(route('berita.index', ['kategori' => 'Pengumuman'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Pengumuman</a>
                                <a href="<?php echo e(route('berita.index', ['kategori' => 'Agenda'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Agenda</a>
                                <a href="<?php echo e(route('berita.index', ['kategori' => 'Prestasi'])); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Prestasi</a>
                                <div class="border-t border-slate-100 my-2"></div>
                                <a href="<?php echo e(route('galeri.index')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Galeri Foto</a>
                                <a href="<?php echo e(route('kontak.index')); ?>" class="block px-4 py-2 text-sm text-slate-700 hover:bg-emerald-50 hover:text-emerald-600">Masukan & Saran</a>
                            </div>
                        </div>
                    </div>

                    <a href="<?php echo e(route('kontak.index')); ?>" class="nav-link px-3 py-2 text-sm font-medium text-slate-700 hover:text-emerald-600 transition-colors <?php echo e(request()->routeIs('kontak.index') ? 'text-emerald-600 is-active' : ''); ?>">Kontak</a>
                </div>

                <!-- Tombol Login & Daftar PPDB -->
                <div class="flex items-center space-x-3">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('account.edit')); ?>" class="hidden md:inline-block px-4 py-2.5 text-sm font-semibold text-emerald-700 hover:text-emerald-800 transition-colors">
                        Akun Saya
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="hidden md:inline-block px-4 py-2.5 text-sm font-semibold text-emerald-700 hover:text-emerald-800 transition-colors">
                        Login
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('ppdb.index')); ?>" class="hidden md:inline-block px-5 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 transition-colors shadow-sm whitespace-nowrap">
                        Daftar PPDB
                    </a>
                    
                    <button @click="mobileOpen = !mobileOpen" class="lg:hidden p-2 text-slate-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div x-show="mobileOpen" x-cloak class="lg:hidden bg-white border-t border-slate-100">
            <div class="px-4 py-4 space-y-1 max-h-96 overflow-y-auto">
                <a href="<?php echo e(route('home')); ?>" class="block px-3 py-2 text-sm font-medium text-slate-700 hover:bg-emerald-50 rounded-lg">Beranda</a>
                
                <div x-data="{ profilOpen: false }">
                    <button @click="profilOpen = !profilOpen" class="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-slate-700 hover:bg-emerald-50 rounded-lg">
                        Profil
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                    </button>
                    <div x-show="profilOpen" x-cloak class="pl-4 mt-1 space-y-1">
                        <a href="<?php echo e(route('profil.sekolah')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Profil Sekolah</a>
                        <a href="<?php echo e(route('profil.visi-misi')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Visi & Misi</a>
                        <a href="<?php echo e(route('profil.sejarah')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Sejarah Singkat</a>
                        <a href="<?php echo e(route('profil.fasilitas')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Fasilitas</a>
                        <a href="<?php echo e(route('staf.index')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Staf Pengajar</a>
                    </div>
                </div>

                <a href="<?php echo e(route('ekskul.index')); ?>" class="block px-3 py-2 text-sm font-medium text-slate-700 hover:bg-emerald-50 rounded-lg">Ekstrakurikuler</a>

                <div x-data="{ infoOpen: false }">
                    <button @click="infoOpen = !infoOpen" class="w-full flex items-center justify-between px-3 py-2 text-sm font-medium text-slate-700 hover:bg-emerald-50 rounded-lg">
                        Informasi
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                    </button>
                    <div x-show="infoOpen" x-cloak class="pl-4 mt-1 space-y-1">
                        <a href="<?php echo e(route('berita.index')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Berita & Artikel</a>
                        <a href="<?php echo e(route('berita.index', ['kategori' => 'Pengumuman'])); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Pengumuman</a>
                        <a href="<?php echo e(route('berita.index', ['kategori' => 'Agenda'])); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Agenda</a>
                        <a href="<?php echo e(route('berita.index', ['kategori' => 'Prestasi'])); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Prestasi</a>
                        <a href="<?php echo e(route('galeri.index')); ?>" class="block px-3 py-2 text-sm text-slate-600 hover:bg-emerald-50 rounded-lg">Galeri Foto</a>
                    </div>
                </div>

                <a href="<?php echo e(route('kontak.index')); ?>" class="block px-3 py-2 text-sm font-medium text-slate-700 hover:bg-emerald-50 rounded-lg">Kontak</a>
                
                <div class="border-t border-slate-100 pt-3 mt-2 space-y-2">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('account.edit')); ?>" class="block w-full text-center px-3 py-2.5 text-sm font-semibold text-emerald-700 border border-emerald-600 rounded-lg hover:bg-emerald-50">Akun Saya</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="block w-full text-center px-3 py-2.5 text-sm font-semibold text-emerald-700 border border-emerald-600 rounded-lg hover:bg-emerald-50">Login</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('ppdb.index')); ?>" class="block w-full text-center px-3 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700">Daftar PPDB</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <footer class="bg-slate-900 text-slate-300 pt-16 pb-8">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                
                <div class="md:col-span-1">
                    <div class="flex items-center space-x-3 mb-4">
                        <?php if($siteLogo): ?>
                        <img src="<?php echo e(asset('storage/'.$siteLogo)); ?>" alt="Logo <?php echo e($siteName); ?>" class="w-12 h-12 object-contain">
                        <?php else: ?>
                        <div class="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                            <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path></svg>
                        </div>
                        <?php endif; ?>
                        <span class="text-lg font-extrabold text-white"><?php echo e($siteName); ?></span>
                    </div>
                    <p class="text-sm leading-relaxed">Membangun generasi yang berakhlak mulia, cerdas, dan terampil dalam mempersiapkan masa depan yang gemilang.</p>
                    <div class="flex space-x-3 mt-4">
                        <a href="#" class="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-emerald-600 transition-colors">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        </a>
                        <a href="#" class="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-emerald-600 transition-colors">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                        </a>
                        <a href="#" class="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-emerald-600 transition-colors">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                        </a>
                    </div>
                </div>

                <div>
                    <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider">Profil Sekolah</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo e(route('profil.sekolah')); ?>" class="hover:text-emerald-400 transition-colors">Profil Sekolah</a></li>
                        <li><a href="<?php echo e(route('profil.visi-misi')); ?>" class="hover:text-emerald-400 transition-colors">Visi & Misi</a></li>
                        <li><a href="<?php echo e(route('profil.sejarah')); ?>" class="hover:text-emerald-400 transition-colors">Sejarah Singkat</a></li>
                        <li><a href="<?php echo e(route('profil.fasilitas')); ?>" class="hover:text-emerald-400 transition-colors">Fasilitas</a></li>
                        <li><a href="<?php echo e(route('staf.index')); ?>" class="hover:text-emerald-400 transition-colors">Staf Pengajar</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider">Link Penting</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo e(route('ppdb.index')); ?>" class="hover:text-emerald-400 transition-colors">PPDB Online</a></li>
                        <li><a href="<?php echo e(route('berita.index')); ?>" class="hover:text-emerald-400 transition-colors">Berita & Artikel</a></li>
                        <li><a href="<?php echo e(route('galeri.index')); ?>" class="hover:text-emerald-400 transition-colors">Galeri Foto</a></li>
                        <li><a href="<?php echo e(route('kontak.index')); ?>" class="hover:text-emerald-400 transition-colors">Kontak & Saran</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider">Kontak Kami</h4>
                    <ul class="space-y-3 text-sm">
                        <li class="flex items-start">
                            <svg class="w-5 h-5 mr-3 text-emerald-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                            <span><?php echo e($siteSettings['alamat'] ?? ''); ?></span>
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-3 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                            <span><?php echo e($siteSettings['telepon'] ?? ''); ?></span>
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-3 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                            <span><?php echo e($siteSettings['email'] ?? ''); ?></span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center text-sm">
                <p>&copy; <?php echo e(date('Y')); ?> <?php echo e($siteName); ?>. All rights reserved.</p>
                <p class="mt-2 md:mt-0">Designed with ❤️ for Education</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var nav = document.querySelector('.site-nav');
            if (nav) {
                var syncNav = function () {
                    nav.classList.toggle('is-scrolled', window.scrollY > 8);
                };
                syncNav();
                window.addEventListener('scroll', syncNav, { passive: true });
            }

            var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            if ('IntersectionObserver' in window && !reduceMotion) {
                document.body.classList.add('js-reveal');

                var revealObserver = new IntersectionObserver(function (entries, observer) {
                    entries.forEach(function (entry) {
                        if (entry.isIntersecting) {
                            entry.target.classList.add('is-visible');
                            observer.unobserve(entry.target);
                        }
                    });
                }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

                document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-zoom')
                    .forEach(function (el) { revealObserver.observe(el); });

                var countEls = document.querySelectorAll('.count-up');
                if (countEls.length) {
                    var countObserver = new IntersectionObserver(function (entries, observer) {
                        entries.forEach(function (entry) {
                            if (entry.isIntersecting) {
                                animateCount(entry.target);
                                observer.unobserve(entry.target);
                            }
                        });
                    }, { threshold: 0.5 });
                    countEls.forEach(function (el) { countObserver.observe(el); });
                }
            } else {
                document.querySelectorAll('.count-up').forEach(function (el) {
                    el.textContent = Number(el.dataset.target).toLocaleString('id-ID');
                });
            }

            function animateCount(el) {
                var target = Number(el.dataset.target) || 0;
                var duration = 1400;
                var start = performance.now();
                function frame(now) {
                    var progress = Math.min((now - start) / duration, 1);
                    var eased = 1 - Math.pow(1 - progress, 3);
                    el.textContent = Math.round(target * eased).toLocaleString('id-ID');
                    if (progress < 1) {
                        requestAnimationFrame(frame);
                    }
                }
                requestAnimationFrame(frame);
            }

            if (!reduceMotion) {
                var parallaxEls = Array.prototype.slice.call(document.querySelectorAll('[data-parallax]'));
                if (parallaxEls.length) {
                    var ticking = false;
                    var renderParallax = function () {
                        var vh = window.innerHeight;
                        parallaxEls.forEach(function (el) {
                            var rect = el.getBoundingClientRect();
                            if (rect.bottom < 0 || rect.top > vh) {
                                return;
                            }
                            var speed = parseFloat(el.dataset.parallax) || 0.08;
                            var offset = (rect.top + rect.height / 2 - vh / 2) * speed;
                            el.style.transform = 'translate3d(0, ' + offset.toFixed(2) + 'px, 0)';
                        });
                        ticking = false;
                    };
                    var requestParallax = function () {
                        if (!ticking) {
                            ticking = true;
                            requestAnimationFrame(renderParallax);
                        }
                    };
                    renderParallax();
                    window.addEventListener('scroll', requestParallax, { passive: true });
                    window.addEventListener('resize', requestParallax);
                }
            }
        });
    </script>

</body>
</html><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views/layouts/public.blade.php ENDPATH**/ ?>