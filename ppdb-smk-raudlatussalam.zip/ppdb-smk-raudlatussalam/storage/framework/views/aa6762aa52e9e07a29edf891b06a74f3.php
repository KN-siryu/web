

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'pesan');
?>

<?php $__env->startSection('title', 'Detail Pesan'); ?>
<?php $__env->startSection('header_title', 'Detail Pesan Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl mb-6"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        
        <!-- Header Pesan -->
        <div class="border-b border-slate-100 pb-6 mb-6">
            <div class="flex items-start justify-between">
                <div class="flex items-center space-x-4">
                    <div class="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-lg font-bold text-emerald-600 uppercase">
                        <?php echo e(substr($pesan->nama, 0, 1)); ?>

                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-slate-900"><?php echo e($pesan->nama); ?></h3>
                        <p class="text-sm text-slate-500"><?php echo e($pesan->email); ?></p>
                    </div>
                </div>
                <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg 
                    <?php echo e($pesan->status == 'baru' ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-500'); ?>

                "><?php echo e($pesan->status == 'baru' ? 'Baru' : 'Dibaca'); ?></span>
            </div>
        </div>

        <!-- Info Pesan -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div class="bg-slate-50 rounded-xl p-4">
                <p class="text-xs text-slate-400 uppercase font-semibold mb-1">Subjek</p>
                <p class="text-sm font-medium text-slate-900"><?php echo e($pesan->subjek); ?></p>
            </div>
            <div class="bg-slate-50 rounded-xl p-4">
                <p class="text-xs text-slate-400 uppercase font-semibold mb-1">Tanggal Kirim</p>
                <p class="text-sm font-medium text-slate-900"><?php echo e($pesan->created_at->format('d F Y, H:i')); ?> WIB</p>
            </div>
        </div>

        <!-- Isi Pesan -->
        <div class="mb-8">
            <p class="text-xs text-slate-400 uppercase font-semibold mb-3">Isi Pesan</p>
            <div class="bg-slate-50 rounded-xl p-6">
                <p class="text-sm text-slate-700 leading-relaxed whitespace-pre-line"><?php echo e($pesan->pesan); ?></p>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="flex flex-col sm:flex-row justify-between items-center gap-4 pt-6 border-t border-slate-100">
            <a href="mailto:<?php echo e($pesan->email); ?>?subject=Re: <?php echo e($pesan->subjek); ?>" class="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 text-center">
                Balas via Email
            </a>
            <div class="flex space-x-3 w-full sm:w-auto">
                <a href="<?php echo e(route($prefix.'pesan.index')); ?>" class="flex-1 sm:flex-none px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200 text-center">Kembali</a>
                <?php if($canDelete): ?>
                <form action="<?php echo e(route($prefix.'pesan.destroy', $pesan)); ?>" method="POST" onsubmit="return confirm('Hapus pesan ini?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="w-full px-6 py-2.5 bg-red-50 text-red-600 text-sm font-semibold rounded-xl hover:bg-red-100">Hapus</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\pesan\show.blade.php ENDPATH**/ ?>