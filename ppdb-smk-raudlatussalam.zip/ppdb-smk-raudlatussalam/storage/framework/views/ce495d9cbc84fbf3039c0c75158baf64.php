

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'galeri');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'galeri');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'galeri');
?>

<?php $__env->startSection('title', 'Kelola Galeri'); ?>
<?php $__env->startSection('header_title', 'Kelola Galeri Foto'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari foto..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <?php if($canCreate): ?>
            <a href="<?php echo e(route($prefix.'galeri.create')); ?>" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Foto
            </a>
            <?php endif; ?>
        </div>
        
        <div class="p-6">
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $galeris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white rounded-xl border border-slate-100 overflow-hidden hover:shadow-md transition-shadow">
                    <div class="aspect-square overflow-hidden bg-slate-100">
                        <img src="<?php echo e(asset('storage/' . $galeri->foto)); ?>" alt="<?php echo e($galeri->judul); ?>" class="w-full h-full object-cover hover:scale-105 transition-transform duration-500">
                    </div>
                    <div class="p-3">
                        <p class="text-sm font-semibold text-slate-900 truncate"><?php echo e($galeri->judul); ?></p>
                        <p class="text-xs text-slate-400 mt-0.5"><?php echo e($galeri->kategori); ?></p>
                        <div class="flex items-center justify-between mt-3">
                            <?php if($canEdit): ?>
                            <a href="<?php echo e(route($prefix.'galeri.edit', $galeri)); ?>" class="text-xs text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            <?php endif; ?>
                            <?php if($canDelete): ?>
                            <form action="<?php echo e(route($prefix.'galeri.destroy', $galeri)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Hapus foto ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-xs text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center py-12">
                    <p class="text-sm text-slate-400">Belum ada foto.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($galeris->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views/admin/galeri/index.blade.php ENDPATH**/ ?>