<?php $__env->startSection('title', 'Manajemen User'); ?>
<?php $__env->startSection('header_title', 'Data Akun Guru'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
                <a href="<?php echo e(route('admin.users.create')); ?>" class="inline-flex items-center px-4 py-2 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-800 transition-colors">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    Tambah User
                </a>
            </div>

            <form action="" method="GET" class="w-full sm:w-64">
                <div class="relative">
                    <input type="text" name="search" placeholder="Cari nama atau email..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent pl-10">
                    <div class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                </div>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Nama</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Email</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Role</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4 text-sm font-medium text-slate-900"><?php echo e($user->name); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($user->email); ?></td>
                        <td class="px-6 py-4 text-sm">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg bg-slate-100 text-slate-600 capitalize"><?php echo e($user->role); ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="text-slate-500 hover:text-emerald-600 font-medium">Edit</a>
                            <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-slate-500 hover:text-red-600 font-medium" onclick="return confirm('Yakin ingin menghapus akun ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada akun guru.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($users->appends(request()->query())->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\users\index.blade.php ENDPATH**/ ?>