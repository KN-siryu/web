

<?php $__env->startSection('title', 'Kontak'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<section class="bg-emerald-700 text-white py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h1 class="reveal text-4xl font-extrabold">Kontak Kami</h1>
        <p class="reveal text-emerald-100 mt-2" style="--reveal-delay: 120ms">Hubungi SMK Raudlatussalam</p>
    </div>
</section>

<!-- Content -->
<section class="py-16">
    <div class="max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            <!-- Info Kontak -->
            <div class="reveal-left">
                <h2 class="text-2xl font-extrabold text-slate-900 mb-6">Informasi Kontak</h2>
                <p class="text-slate-600 mb-8">Jika Anda memiliki pertanyaan, saran, atau ingin mengetahui lebih lanjut tentang SMK Raudlatussalam, jangan ragu untuk menghubungi kami melalui informasi di bawah ini.</p>
                
                <div class="space-y-6">
                    <!-- Alamat -->
                    <div class="flex items-start">
                        <div class="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900">Alamat</h3>
                            <p class="text-sm text-slate-600 mt-1"><?php echo e($siteSettings['alamat'] ?? ''); ?></p>
                        </div>
                    </div>

                    <!-- Telepon -->
                    <div class="flex items-start">
                        <div class="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900">Telepon / WhatsApp</h3>
                            <p class="text-sm text-slate-600 mt-1"><?php echo e($siteSettings['telepon'] ?? ''); ?></p>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="flex items-start">
                        <div class="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900">Email</h3>
                            <p class="text-sm text-slate-600 mt-1"><?php echo e($siteSettings['email'] ?? ''); ?></p>
                        </div>
                    </div>

                    <!-- Jam Operasional -->
                    <div class="flex items-start">
                        <div class="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        </div>
                        <div>
                            <h3 class="font-bold text-slate-900">Jam Operasional</h3>
                            <p class="text-sm text-slate-600 mt-1">Senin - Jumat: 07.00 - 15.00 WIB<br>Sabtu - Minggu: Libur</p>
                        </div>
                    </div>
                </div>

                <!-- Peta Lokasi -->
                <div class="mt-8">
                    <h3 class="font-bold text-slate-900 mb-4">Lokasi Sekolah</h3>
                    <div class="aspect-video bg-slate-200 rounded-2xl overflow-hidden shadow-sm border border-slate-100">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3948.6837635965447!2d114.2734!3d-8.2756!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zOMKwMTYnMzIuMiJTIDExNMKwMTYnMjQuMiJF!5e0!3m2!1sen!2sid!4v1635000000000!5m2!1sen!2sid" 
                            width="100%" 
                            height="100%" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy"
                            class="rounded-2xl">
                        </iframe>
                    </div>
                </div>
            </div>

            <!-- Form Kontak -->
            <div class="reveal-right">
                <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
                    <h2 class="text-2xl font-extrabold text-slate-900 mb-2">Kirim Pesan</h2>
                    <p class="text-slate-500 text-sm mb-6">Sampaikan pertanyaan atau saran Anda kepada kami.</p>

                    <?php if(session('success')): ?>
                    <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-emerald-600 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
                            <p class="text-sm text-emerald-800 font-medium"><?php echo e(session('success')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                    <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
                        <p class="text-sm text-red-800 font-medium mb-2">Terdapat kesalahan pada input:</p>
                        <ul class="text-sm text-red-600 list-disc list-inside">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('kontak.store')); ?>" method="POST" class="space-y-5">
                        <?php echo csrf_field(); ?>

                        <div>
                            <label for="nama" class="block text-sm font-semibold text-slate-700 mb-2">Nama Lengkap *</label>
                            <input type="text" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-colors" placeholder="Masukkan nama Anda">
                        </div>

                        <div>
                            <label for="email" class="block text-sm font-semibold text-slate-700 mb-2">Email *</label>
                            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-colors" placeholder="email@contoh.com">
                        </div>

                        <div>
                            <label for="subjek" class="block text-sm font-semibold text-slate-700 mb-2">Subjek *</label>
                            <input type="text" id="subjek" name="subjek" value="<?php echo e(old('subjek')); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-colors" placeholder="Topik pesan Anda">
                        </div>

                        <div>
                            <label for="pesan" class="block text-sm font-semibold text-slate-700 mb-2">Pesan *</label>
                            <textarea id="pesan" name="pesan" rows="5" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-colors resize-none" placeholder="Tulis pesan Anda di sini..."><?php echo e(old('pesan')); ?></textarea>
                        </div>

                        <button type="submit" class="w-full py-3.5 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200">
                            Kirim Pesan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\kontak\index.blade.php ENDPATH**/ ?>