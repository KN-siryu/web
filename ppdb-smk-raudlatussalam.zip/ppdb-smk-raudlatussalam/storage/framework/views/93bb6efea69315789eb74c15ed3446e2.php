<!DOCTYPE html>
<html lang="id">
<?php
    $siteName = $siteSettings['nama_sekolah'] ?? 'SMK Raudlatussalam';
    $siteLogo = $siteSettings['logo'] ?? null;
    $siteFavicon = $siteSettings['favicon'] ?? null;
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e(auth()->user()->role === 'guru' ? 'Guru' : 'Admin'); ?> <?php echo e($siteName); ?></title>
    <link rel="icon" href="<?php echo e($siteFavicon ? asset('storage/'.$siteFavicon) : asset('favicon.ico')); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        [x-cloak] {
            display: none !important;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-6px); }
            75% { transform: translateX(6px); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(14px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes popIn {
            0% { opacity: 0; transform: scale(.94); }
            60% { opacity: 1; transform: scale(1.02); }
            100% { transform: scale(1); }
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        .animate-fade-in-up {
            animation: fadeInUp .5s cubic-bezier(.16, 1, .3, 1) both;
        }

        .animate-pop-in {
            animation: popIn .45s cubic-bezier(.16, 1, .3, 1) both;
        }

        .delay-1 { animation-delay: .06s; }
        .delay-2 { animation-delay: .12s; }
        .delay-3 { animation-delay: .18s; }
        .delay-4 { animation-delay: .24s; }
    </style>
</head>

<body class="bg-slate-100 text-slate-900 antialiased">
    <div class="flex h-screen overflow-hidden">

        <!-- Mobile backdrop -->
        <div x-data="{}" x-show="false"></div>
        <div id="sidebarBackdrop" class="fixed inset-0 z-40 hidden bg-slate-900/50 backdrop-blur-sm md:hidden"
             onclick="document.getElementById('sidebar').classList.add('-translate-x-full'); this.classList.add('hidden')"></div>

        <!-- Sidebar -->
        <aside id="sidebar" class="fixed z-50 flex h-full w-64 -translate-x-full flex-col border-r border-slate-800 bg-slate-900 text-slate-300 transition-transform duration-300 md:flex md:translate-x-0">
            <div class="flex h-16 items-center px-6 border-b border-slate-800">
                <?php if($siteLogo): ?>
                <img src="<?php echo e(asset('storage/'.$siteLogo)); ?>" alt="Logo <?php echo e($siteName); ?>" class="w-9 h-9 object-contain mr-3">
                <?php else: ?>
                <div class="w-9 h-9 bg-emerald-600 rounded-xl flex items-center justify-center mr-3 shadow-lg shadow-emerald-900/50">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path>
                    </svg>
                </div>
                <?php endif; ?>
                <div>
                    <span class="text-sm font-extrabold tracking-tight text-white block leading-tight"><?php echo e($siteName); ?></span>
                    <span class="text-[10px] text-slate-500 uppercase tracking-wider"><?php echo e(auth()->user()->role === 'guru' ? 'Panel Guru' : 'Admin Panel'); ?></span>
                </div>
            </div>

            <?php if(auth()->user()->role !== 'guru'): ?>
            <nav class="flex-1 overflow-y-auto p-4 space-y-1">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                    </svg>
                    Dashboard
                </a>

                <!-- TAMBAHKAN MENU INI -->
                <a href="<?php echo e(route('admin.pendaftar.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.pendaftar.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?> relative">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                    </svg>
                    Pendaftar PPDB
                    <?php if(\App\Models\Pendaftar::where('status', 'Pending')->count() > 0): ?>
                    <span class="absolute top-2 right-3 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center"><?php echo e(\App\Models\Pendaftar::where('status', 'Pending')->count()); ?></span>
                    <?php endif; ?>
                </a>

                <div class="pt-5 pb-2"><span class="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Manajemen Konten</span></div>

                <!-- LINK BERITA DIPERBAIKI -->
                <a href="<?php echo e(route('admin.berita.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.berita.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path>
                    </svg>
                    Berita & Artikel
                </a>

                <!-- LINK GALERI DIPERBAIKI -->
                <a href="<?php echo e(route('admin.galeri.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.galeri.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                    Galeri Foto
                </a>

                <!-- LINK STAF DIPERBAIKI -->
                <a href="<?php echo e(route('admin.staf.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.staf.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    Staf Pengajar
                </a>

                <!-- LINK EKSKUL (akan dibuat di bagian 3) -->
                <a href="<?php echo e(route('admin.ekskul.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.ekskul.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                    </svg>
                    Ekstrakurikuler
                </a>

                <a href="<?php echo e(route('admin.fasilitas.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.fasilitas.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14M5 6h14M5 18h14"></path>
                    </svg>
                    Fasilitas
                </a>

                <?php if(auth()->user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.users.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2m6-10a4 4 0 100-8 4 4 0 000 8zm14 10v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"></path>
                    </svg>
                    Akun Guru
                </a>
                <?php endif; ?>

                <div class="pt-5 pb-2"><span class="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sistem</span></div>
                <a href="<?php echo e(route('admin.pesan.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.pesan.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?> relative">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                    Pesan Masuk
                    <?php if(\App\Models\Pesan::where('status', 'baru')->count() > 0): ?>
                    <span class="absolute top-2 right-3 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center"><?php echo e(\App\Models\Pesan::where('status', 'baru')->count()); ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?php echo e(route('admin.pengaturan.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.pengaturan.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                    Pengaturan
                </a>

                <?php if(auth()->user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.izin-akses.index')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('admin.izin-akses.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                    </svg>
                    Izin Akses Guru
                </a>
                <?php endif; ?>
            </nav>
            <?php else: ?>
            <?php
                $guruModules = auth()->user()->approvedModules();
                $guruNavItems = [
                    ['route' => 'guru.berita.*', 'url' => route('guru.berita.index'), 'module' => 'berita', 'label' => 'Berita & Artikel', 'icon' => 'M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z'],
                    ['route' => 'guru.galeri.*', 'url' => route('guru.galeri.index'), 'module' => 'galeri', 'label' => 'Galeri Foto', 'icon' => 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z'],
                    ['route' => 'guru.ekskul.*', 'url' => route('guru.ekskul.index'), 'module' => 'ekskul', 'label' => 'Ekstrakurikuler', 'icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'],
                    ['route' => 'guru.staf.*', 'url' => route('guru.staf.index'), 'module' => 'staf', 'label' => 'Staf Pengajar', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 004 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'],
                    ['route' => 'guru.fasilitas.*', 'url' => route('guru.fasilitas.index'), 'module' => 'fasilitas', 'label' => 'Fasilitas', 'icon' => 'M5 12h14M5 6h14M5 18h14'],
                    ['route' => 'guru.pendaftar.*', 'url' => route('guru.pendaftar.index'), 'module' => 'pendaftar', 'label' => 'PPDB Online', 'icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4'],
                ];
            ?>
            <nav class="flex-1 overflow-y-auto p-4 space-y-1">
                <a href="<?php echo e(route('guru.dashboard')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('guru.dashboard') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                    </svg>
                    Dashboard Guru
                </a>

                <div class="pt-5 pb-2"><span class="px-4 text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Informasi</span></div>

                <?php $__currentLoopData = $guruNavItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($item['module'], $guruModules, true)): ?>
                    <a href="<?php echo e($item['url']); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs($item['route']) ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($item['icon']); ?>"></path>
                        </svg>
                        <?php echo e($item['label']); ?>

                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('guru.izin-akses.create', ['module' => $item['module']])); ?>" title="Ajukan izin akses untuk modul ini" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all text-slate-500 hover:text-emerald-300 hover:bg-slate-800/70">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                        </svg>
                        <?php echo e($item['label']); ?>

                        <svg class="w-4 h-4 ml-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0v4m-8 0h8m-8 0v6h8v-6"></path>
                        </svg>
                    </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('guru.izin-akses.create')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('guru.izin-akses.*') ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 018.618 3.078A6.002 6.002 0 0022 5.396v.001A6.002 6.002 0 0120.803 12c0 1.363-.475 2.61-1.218 3.556m-5.945-3.556a6.002 6.002 0 01-1.218-3.556c0-.772.132-1.523.38-2.22m-2.645 7.743c.636.412 1.293.79 1.977 1.097 1.328.616 2.784.91 4.302.91 1.518 0 2.974-.294 4.302-.91.684-.307 1.341-.685 1.977-1.097m-9.743-1.097c.636-.412 1.293-.79 1.977-1.097 1.328-.616 2.784-.91 4.302-.91 1.518 0 2.974.294 4.302.91.684.307 1.341.685 1.977 1.097m4.302-1.097a6.002 6.002 0 00-1.218 3.556c0 1.363.475 2.61 1.218 3.556m-5.945-3.556a6.002 6.002 0 01-1.218-3.556c0-.772.132-1.523.38-2.22m-2.645 7.743c.636.412 1.293.79 1.977 1.097 1.328.616 2.784.91 4.302.91 1.518 0 2.974-.294 4.302-.91.684-.307 1.341-.685 1.977-1.097m-9.743-1.097c.636-.412 1.293-.79 1.977-1.097 1.328-.616 2.784-.91 4.302-.91 1.518 0 2.974.294 4.302.91.684.307 1.341.685 1.977 1.097"></path>
                    </svg>
                    Izin Akses
                </a>

                <a href="<?php echo e(route('account.edit')); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all <?php echo e(request()->routeIs('account.edit') ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'); ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2-5 5z"></path>
                    </svg>
                    Akun Saya
                </a>
            </nav>
            <?php endif; ?>

            <!-- Footer Sidebar -->
            <div class="p-4 border-t border-slate-800">
                <a href="<?php echo e(route('home')); ?>" target="_blank" class="flex items-center px-4 py-2 text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                    <svg class="w-4 h-4 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                    </svg>
                    Lihat Website
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden md:ml-64">
            <header class="h-16 bg-white border-b border-slate-100 flex items-center justify-between px-6 sticky top-0 z-40">
                <div class="flex items-center gap-3">
                    <button type="button"
                            onclick="document.getElementById('sidebar').classList.remove('-translate-x-full'); document.getElementById('sidebarBackdrop').classList.remove('hidden')"
                            class="rounded-lg p-2 text-slate-600 transition hover:bg-slate-100 md:hidden"
                            aria-label="Buka menu">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                    <h2 class="text-lg font-bold text-slate-900"><?php echo $__env->yieldContent('header_title', 'Dashboard'); ?></h2>
                </div>

                <div class="flex items-center space-x-4">
                    <?php if(in_array(auth()->user()->role, ['guru', 'admin'])): ?>
                    <div class="relative" x-data="{
                        notifOpen: false,
                        markAllRead() {
                            fetch('<?php echo e(route('notifications.markAsRead')); ?>', {
                                method: 'POST',
                                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json' }
                            }).then(() => {
                                document.querySelectorAll('[data-notif-badge]').forEach(el => el.remove());
                                document.querySelectorAll('[data-notif-unread]').forEach(el => {
                                    el.classList.remove('bg-blue-50');
                                });
                                document.querySelectorAll('[data-notif-dot]').forEach(el => {
                                    el.classList.remove('bg-blue-500');
                                    el.classList.add('bg-slate-300');
                                });
                            });
                        }
                    }">
                        <button @click="notifOpen = !notifOpen; if (notifOpen) markAllRead()" class="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors focus:outline-none">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                            </svg>
                            <?php
                                $unreadCount = auth()->user()->unreadNotifications->count();
                            ?>
                            <?php if($unreadCount > 0): ?>
                            <span data-notif-badge class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center"><?php echo e($unreadCount); ?></span>
                            <?php endif; ?>
                        </button>

                        <div x-show="notifOpen" @click.outside="notifOpen = false" x-cloak class="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg py-1 border border-slate-100 z-50 max-h-96 overflow-y-auto">
                            <div class="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                                <h4 class="font-semibold text-slate-900">Notifikasi</h4>
                                <?php if($unreadCount > 0): ?>
                                <span class="text-xs text-blue-600 font-medium">Tandai dibaca otomatis</span>
                                <?php endif; ?>
                            </div>
                            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications()->latest()->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $notifUrl = '#';
                                    if (isset($notification->data['permission_request_id'])) {
                                        if (auth()->user()->role === 'admin') {
                                            $notifUrl = route('admin.izin-akses.index');
                                        } else {
                                            $notifUrl = route('guru.izin-akses.show', $notification->data['permission_request_id']);
                                        }
                                    }
                                    $markReadUrl = route('notifications.markAsReadSingle', $notification->id);
                                ?>
                                <form method="POST" action="<?php echo e($markReadUrl); ?>" class="block"
                                      <?php if($notifUrl !== '#'): ?>
                                      onsubmit="event.preventDefault(); fetch(this.action, {method: 'POST', headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json'}, body: new FormData(this)}).then(() => window.location.href = '<?php echo e($notifUrl); ?>')"
                                      <?php endif; ?>>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            data-notif-unread
                                            class="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors <?php echo e(!$notification->read_at ? 'bg-blue-50' : ''); ?>">
                                        <div class="flex items-start gap-3">
                                            <div data-notif-dot class="w-2 h-2 mt-2 rounded-full <?php echo e(!$notification->read_at ? 'bg-blue-500' : 'bg-slate-300'); ?>"></div>
                                            <div class="flex-1 min-w-0">
                                                <p class="text-sm font-medium text-slate-900"><?php echo e($notification->data['title'] ?? 'Notifikasi'); ?></p>
                                                <p class="text-xs text-slate-500 mt-1 line-clamp-2"><?php echo $notification->data['message'] ?? ''; ?></p>
                                                <p class="text-[10px] text-slate-400 mt-1"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                                            </div>
                                        </div>
                                    </button>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="px-4 py-8 text-center text-slate-500 text-sm">Tidak ada notifikasi</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-2 focus:outline-none">
                            <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=d1fae5&color=065f46" alt="Avatar" class="w-9 h-9 rounded-xl object-cover border border-slate-100">
                            <div class="text-left hidden sm:block">
                                <p class="text-sm font-semibold leading-none text-slate-900"><?php echo e(auth()->user()->name); ?></p>
                                <p class="text-[11px] text-slate-400 leading-none mt-1 capitalize"><?php echo e(auth()->user()->role); ?></p>
                            </div>
                            <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>

                        <div x-show="open" @click.outside="open = false" x-cloak class="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg py-1 border border-slate-100 z-50">
                            <a href="<?php echo e(route('account.edit')); ?>" class="w-full flex items-center px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 font-medium">
                                Akun Saya
                            </a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full flex items-center px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 font-medium">
                                    <svg class="w-4 h-4 mr-3 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                                    </svg>
                                    Keluar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            <main class="flex-1 overflow-y-auto p-8">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\layouts\admin.blade.php ENDPATH**/ ?>