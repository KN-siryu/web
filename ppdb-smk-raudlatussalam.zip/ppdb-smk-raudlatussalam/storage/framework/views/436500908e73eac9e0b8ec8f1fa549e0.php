<?php $__env->startSection('title', 'Status Izin Akses - Dashboard Guru'); ?>
<?php $__env->startSection('header_title', 'Status Izin Akses'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $pr = $permissionRequest;
    $moduleLabels = ['berita' => 'Berita & Artikel', 'galeri' => 'Galeri Foto', 'ekskul' => 'Ekstrakurikuler', 'staf' => 'Staf Pengajar', 'fasilitas' => 'Fasilitas', 'pendaftar' => 'Pendaftar PPDB', 'pesan' => 'Pesan Masuk'];
    $actionLabels = ['create' => 'Tambah Data', 'edit' => 'Edit Data', 'delete' => 'Hapus Data', 'all' => 'Semua Akses'];
    $active = $pr->status === 'approved' && $pr->isWithinWindow();
    $expired = $pr->status === 'approved' && ! $pr->isWithinWindow();
    $statusMeta = match (true) {
        $pr->status === 'pending' => ['label' => 'Menunggu Persetujuan', 'class' => 'bg-amber-100 text-amber-700', 'ring' => 'ring-amber-200', 'dot' => 'bg-amber-500 animate-pulse'],
        $active => ['label' => 'Sedang Aktif', 'class' => 'bg-emerald-100 text-emerald-700', 'ring' => 'ring-emerald-200', 'dot' => 'bg-emerald-500'],
        $expired => ['label' => 'Kedaluwarsa', 'class' => 'bg-slate-200 text-slate-600', 'ring' => 'ring-slate-300', 'dot' => 'bg-slate-400'],
        $pr->status === 'revoked' => ['label' => 'Dihentikan Admin', 'class' => 'bg-slate-200 text-slate-600', 'ring' => 'ring-slate-300', 'dot' => 'bg-slate-400'],
        default => ['label' => 'Ditolak', 'class' => 'bg-red-100 text-red-700', 'ring' => 'ring-red-200', 'dot' => 'bg-red-500'],
    };
?>

<div class="max-w-2xl mx-auto animate-fade-in-up">
    <div class="overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm">
        
        <div class="relative overflow-hidden bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-600 px-6 py-7 sm:px-8">
            <div class="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl"></div>
            <div class="pointer-events-none absolute -bottom-12 left-6 h-32 w-32 rounded-full bg-emerald-300/20 blur-2xl"></div>
            <div class="relative flex items-start justify-between gap-4">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 text-white ring-1 ring-white/30">
                        <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </span>
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-widest text-emerald-100">Status Permintaan</p>
                        <h3 class="text-lg font-bold text-white sm:text-xl"><?php echo e($statusMeta['label']); ?></h3>
                    </div>
                </div>
                <span class="inline-flex shrink-0 items-center gap-2 rounded-full bg-white/15 px-3 py-1.5 text-xs font-semibold text-white ring-1 ring-white/30">
                    <span class="h-2 w-2 rounded-full <?php echo e($statusMeta['dot']); ?>"></span>
                    <?php echo e(ucfirst($pr->status)); ?>

                </span>
            </div>
        </div>

        <div class="p-6 sm:p-8">
            
            <?php if($active): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 animate-pop-in">
                    <svg class="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <div class="text-sm text-emerald-800">
                        <p class="font-semibold">Izin akses Anda sedang aktif!</p>
                        <p class="mt-0.5 text-emerald-700">Modul <span class="font-semibold"><?php echo e($moduleLabels[$pr->module] ?? $pr->module); ?></span> dapat Anda akses sampai <span class="font-semibold"><?php echo e($pr->end_at?->format('d M Y H:i')); ?></span>.</p>
                    </div>
                </div>
            <?php elseif($expired): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 animate-pop-in">
                    <svg class="mt-0.5 h-5 w-5 shrink-0 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div class="text-sm text-slate-700">
                        <p class="font-semibold">Masa berlaku izin telah berakhir.</p>
                        <p class="mt-0.5">Silakan ajukan perpanjangan izin untuk mengakses modul ini kembali.</p>
                    </div>
                </div>
            <?php elseif($pr->status === 'rejected'): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 animate-pop-in">
                    <svg class="mt-0.5 h-5 w-5 shrink-0 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                    <div class="text-sm text-red-800">
                        <p class="font-semibold">Permintaan ditolak.</p>
                        <?php if($pr->admin_note): ?>
                            <p class="mt-0.5">Alasan: <?php echo e($pr->admin_note); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php elseif($pr->status === 'revoked'): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-slate-300 bg-slate-100 p-4 animate-pop-in">
                    <svg class="mt-0.5 h-5 w-5 shrink-0 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path>
                    </svg>
                    <div class="text-sm text-slate-700">
                        <p class="font-semibold">Izin akses dihentikan oleh admin.</p>
                        <p class="mt-0.5">Akses ke modul <span class="font-semibold"><?php echo e($moduleLabels[$pr->module] ?? $pr->module); ?></span> sekarang dinonaktifkan.</p>
                        <?php if($pr->admin_note): ?>
                            <p class="mt-1 text-slate-600">Catatan: <?php echo e($pr->admin_note); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 animate-pop-in">
                    <svg class="mt-0.5 h-5 w-5 shrink-0 animate-pulse text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div class="text-sm text-amber-800">
                        <p class="font-semibold">Menunggu persetujuan admin.</p>
                        <p class="mt-0.5">Anda akan menerima notifikasi setelah permintaan ini ditinjau.</p>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div class="rounded-2xl bg-slate-50 p-4">
                    <p class="text-xs font-semibold uppercase text-slate-500">Modul</p>
                    <p class="mt-1 font-medium capitalize text-slate-900"><?php echo e($moduleLabels[$pr->module] ?? $pr->module); ?></p>
                </div>
                <div class="rounded-2xl bg-slate-50 p-4">
                    <p class="text-xs font-semibold uppercase text-slate-500">Tipe Akses</p>
                    <p class="mt-1 font-medium text-slate-900"><?php echo e($actionLabels[$pr->action_type] ?? $pr->action_type); ?></p>
                </div>
                <div class="rounded-2xl bg-slate-50 p-4">
                    <p class="text-xs font-semibold uppercase text-slate-500">Mulai Berlaku</p>
                    <p class="mt-1 font-medium text-slate-900"><?php echo e($pr->start_at?->format('d M Y H:i') ?? '-'); ?></p>
                </div>
                <div class="rounded-2xl bg-slate-50 p-4">
                    <p class="text-xs font-semibold uppercase text-slate-500">Berakhir</p>
                    <p class="mt-1 font-medium text-slate-900"><?php echo e($pr->end_at?->format('d M Y H:i') ?? '-'); ?></p>
                </div>
                <div class="rounded-2xl bg-slate-50 p-4 sm:col-span-2">
                    <p class="text-xs font-semibold uppercase text-slate-500">Diajukan Pada</p>
                    <p class="mt-1 font-medium text-slate-900"><?php echo e($pr->created_at->format('d M Y H:i')); ?></p>
                </div>
            </div>

            
            <div class="mt-5">
                <p class="mb-2 text-xs font-semibold uppercase text-slate-500">Alasan</p>
                <div class="rounded-2xl border-l-4 border-emerald-500 bg-slate-50 p-4">
                    <p class="text-sm text-slate-700"><?php echo e($pr->reason); ?></p>
                </div>
            </div>

            
            <?php if($pr->status !== 'pending' && $pr->admin_note): ?>
                <div class="mt-5">
                    <p class="mb-2 text-xs font-semibold uppercase text-slate-500">Catatan Admin</p>
                    <div class="rounded-2xl border-l-4 border-slate-400 bg-slate-50 p-4">
                        <p class="text-sm text-slate-700"><?php echo e($pr->admin_note); ?></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-6 flex flex-col gap-3 sm:flex-row">
        <a href="<?php echo e(route('guru.izin-akses.create')); ?>"
           class="group inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-200 transition hover:-translate-y-0.5 hover:bg-emerald-700">
            <svg class="h-4 w-4 transition-transform group-hover:-translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
            </svg>
            Ajukan Permintaan Baru
        </a>
        <a href="<?php echo e(route('guru.dashboard')); ?>"
           class="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-100 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-200">
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
            </svg>
            Kembali ke Dashboard
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\guru\izin-akses\show.blade.php ENDPATH**/ ?>