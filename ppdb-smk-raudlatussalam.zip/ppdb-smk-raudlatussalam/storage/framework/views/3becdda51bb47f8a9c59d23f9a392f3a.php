

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
    $canCreate = auth()->user()->role !== 'guru' || auth()->user()->canDo('create', 'berita');
    $canEdit = auth()->user()->role !== 'guru' || auth()->user()->canDo('edit', 'berita');
    $canDelete = auth()->user()->role !== 'guru' || auth()->user()->canDo('delete', 'berita');
?>

<?php $__env->startSection('title', 'Kelola Berita'); ?>
<?php $__env->startSection('header_title', 'Kelola Berita & Artikel'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm p-4 rounded-xl"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm">
        <div class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <form action="" method="GET" class="w-full sm:w-64">
                <input type="text" name="search" placeholder="Cari berita..." value="<?php echo e(request('search')); ?>" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </form>
            <?php if($canCreate): ?>
            <a href="<?php echo e(route($prefix.'berita.create')); ?>" class="w-full sm:w-auto flex justify-center py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-sm shadow-emerald-200">
                Tambah Berita
            </a>
            <?php endif; ?>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-100">
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Judul</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Kategori</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Penulis</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                        <th class="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php $__empty_1 = true; $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <?php if($berita->gambar): ?>
                                <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" class="w-10 h-10 rounded-lg object-cover">
                                <?php else: ?>
                                <div class="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                                    <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                </div>
                                <?php endif; ?>
                                <p class="text-sm font-medium text-slate-900 max-w-xs truncate"><?php echo e($berita->judul); ?></p>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 inline-flex text-xs font-semibold rounded-lg 
                                <?php echo e($berita->kategori == 'Berita' ? 'bg-emerald-50 text-emerald-600' : ''); ?>

                                <?php echo e($berita->kategori == 'Pengumuman' ? 'bg-blue-50 text-blue-600' : ''); ?>

                                <?php echo e($berita->kategori == 'Agenda' ? 'bg-purple-50 text-purple-600' : ''); ?>

                                <?php echo e($berita->kategori == 'Prestasi' ? 'bg-orange-50 text-orange-600' : ''); ?>

                            "><?php echo e($berita->kategori); ?></span>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($berita->penulis); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($berita->created_at->format('d M Y')); ?></td>
                        <td class="px-6 py-4 text-sm text-right space-x-3">
                            <a href="<?php echo e(route('berita.show', $berita)); ?>" target="_blank" class="text-slate-500 hover:text-emerald-600 font-medium">Lihat</a>
                            <?php if($canEdit): ?>
                            <a href="<?php echo e(route($prefix.'berita.edit', $berita)); ?>" class="text-slate-500 hover:text-blue-600 font-medium">Edit</a>
                            <?php endif; ?>
                            <?php if($canDelete): ?>
                            <form action="<?php echo e(route($prefix.'berita.destroy', $berita)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Hapus berita ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-400 hover:text-red-600 font-medium">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-sm text-slate-400">Belum ada berita.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-6 py-4 border-t border-slate-100"><?php echo e($beritas->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views/admin/berita/index.blade.php ENDPATH**/ ?>