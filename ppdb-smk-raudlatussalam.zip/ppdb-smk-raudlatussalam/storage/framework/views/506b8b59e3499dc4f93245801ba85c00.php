

<?php $__env->startSection('title', $berita->judul); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-emerald-700 text-white py-12">
    <div class="max-w-5xl mx-auto px-4">
        <a href="<?php echo e(route('berita.index')); ?>" class="reveal text-sm text-emerald-100 hover:text-white">← Kembali ke berita</a>
        <p class="reveal text-emerald-100 font-semibold mt-6" style="--reveal-delay: 100ms"><?php echo e($berita->kategori); ?></p>
        <h1 class="reveal text-3xl md:text-4xl font-extrabold mt-2" style="--reveal-delay: 180ms"><?php echo e($berita->judul); ?></h1>
        <p class="reveal text-sm text-emerald-100 mt-4" style="--reveal-delay: 260ms">Oleh <?php echo e($berita->penulis); ?> · <?php echo e($berita->created_at->format('d M Y')); ?></p>
    </div>
</section>

<section class="py-12">
    <div class="max-w-5xl mx-auto px-4 grid lg:grid-cols-3 gap-10">
        <article class="reveal lg:col-span-2">
            <?php if($berita->gambar): ?>
            <div class="reveal-zoom mb-8 overflow-hidden rounded-2xl">
                <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full max-h-[28rem] object-cover transition duration-700 hover:scale-105">
            </div>
            <?php endif; ?>
            <div class="text-slate-700 leading-8 whitespace-pre-line"><?php echo e($berita->konten); ?></div>
        </article>

        <aside class="reveal-right">
            <h2 class="text-lg font-bold text-slate-900 mb-4">Berita lainnya</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritaLain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('berita.show', $beritaLain)); ?>" class="block p-4 bg-slate-50 rounded-xl transition hover:-translate-y-0.5 hover:bg-emerald-50 hover:shadow-md">
                    <span class="text-xs font-semibold text-emerald-700"><?php echo e($beritaLain->kategori); ?></span>
                    <h3 class="font-semibold text-slate-900 mt-1"><?php echo e($beritaLain->judul); ?></h3>
                    <time datetime="<?php echo e($beritaLain->created_at->toDateString()); ?>" class="text-xs text-slate-500 mt-2 block"><?php echo e($beritaLain->created_at->format('d M Y')); ?></time>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada berita lainnya.</p>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\berita\show.blade.php ENDPATH**/ ?>