

<?php
    $prefix = auth()->user()->role === 'guru' ? 'guru.' : 'admin.';
?>

<?php $__env->startSection('title', 'Edit Berita'); ?>
<?php $__env->startSection('header_title', 'Edit Data Berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <div class="bg-white border border-slate-100 rounded-2xl shadow-sm p-8">
        <form action="<?php echo e(route($prefix.'berita.update', $berita)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            
            <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Judul Berita *</label>
                <input type="text" name="judul" value="<?php echo e(old('judul', $berita->judul)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Kategori *</label>
                    <select name="kategori" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                        <option value="Berita" <?php echo e(old('kategori', $berita->kategori) == 'Berita' ? 'selected' : ''); ?>>Berita</option>
                        <option value="Pengumuman" <?php echo e(old('kategori', $berita->kategori) == 'Pengumuman' ? 'selected' : ''); ?>>Pengumuman</option>
                        <option value="Agenda" <?php echo e(old('kategori', $berita->kategori) == 'Agenda' ? 'selected' : ''); ?>>Agenda</option>
                        <option value="Prestasi" <?php echo e(old('kategori', $berita->kategori) == 'Prestasi' ? 'selected' : ''); ?>>Prestasi</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Penulis *</label>
                    <input type="text" name="penulis" value="<?php echo e(old('penulis', $berita->penulis)); ?>" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent">
                </div>
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Gambar Saat Ini</label>
                <?php if($berita->gambar): ?>
                <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" class="w-32 h-32 object-cover rounded-xl mb-2 border border-slate-100">
                <?php else: ?>
                <p class="text-sm text-slate-400 mb-2">Tidak ada gambar</p>
                <?php endif; ?>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Ganti Gambar (Opsional)</label>
                <input type="file" name="gambar" class="w-full text-sm text-slate-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100">
            </div>

            <div>
                <label class="block text-xs font-semibold text-slate-500 uppercase mb-2">Konten Berita *</label>
                <textarea name="konten" rows="8" required class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"><?php echo e(old('konten', $berita->konten)); ?></textarea>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
                <a href="<?php echo e(route($prefix.'berita.index')); ?>" class="px-6 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-200">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 shadow-sm shadow-emerald-200">Update Berita</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ppdb-smk-raudlatussalam\resources\views\admin\berita\edit.blade.php ENDPATH**/ ?>